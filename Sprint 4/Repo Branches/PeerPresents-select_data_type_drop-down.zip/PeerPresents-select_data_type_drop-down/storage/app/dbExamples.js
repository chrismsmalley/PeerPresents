const {connectToDB, disconnectFromDB, createDB, clearDB, createEntity, readEntity, updateEntity, deleteEntity} = require('./managers/mongodbManager');

var userModel = {
    _id: 10,
    firstName: "Bryan",
    lastName: "Learn",
    roles: ["presenter", "listener"]
}

//clearDB()
//createDB()

//connectToDB()
//.then(() => {
//    writeEntity("user", userModel)
//    .then((res) => {
//        readEntity("user", 10)
//        .then((res) => {
//            console.log("finished")
//        }).catch((err) => {
//            console.error(err);
//        })
//    }).catch((err) => {
//        console.error(err);
//    })
//}).catch((err) => {
//    console.error(err);
//})



function write(){
    createEntity("user", userModel)
    .then((res) => {

    }).catch((err) => {
        console.error(err);
    });
    return;
}

function update(){
    updateEntity("user", userModel)
    .then((res) => {

    }).catch((err) => {
        console.error(err);
    });
    return;
}


function read(){
    readEntity("user", 10)
    .then((res) => {
        console.log(JSON.stringify(res))
    }).catch((err) => {
        console.error(err);
    });
    return;
}

function del() {
    deleteEntity("user", 10)
    .then((res) => {
        //console.log(JSON.stringify(res))
    }).catch((err) => {
        console.error(err);
    });
    return;
}


connectToDB()
.then(() => {
    //write();
    //update();
    read();
    //del();

    //disconnectFromDB()
    //.catch((err) => {
    //    console.error(err);
    //});
    console.log("end")
    return;  
}).catch((err) => {
    console.error(err);
    console.log("example failed");

    //disconnectFromDB()
    //.catch((err) => {
    //    console.error(err);
    //});
    //return;
});

