# Project Management Plan

## Team

Lead Project Manager: [Jessica Hammer](mailto:hammerj@andrew.cmu.edu )

Project Manager: [Amy Cook](mailto:ascook@memphis.edu )

Frontend Developer: [Gal Fleissig](mailto:gfleissi@andrew.cmu.edu)

Backend Developer: TBD

## On-Boarding Plan

All new team members will need access to the resources for the **Communication Plan**, **Software Management Plan**, and **Credentials Management Plan**. Access to these resources can be granted by the "owner" of each resource. The owners are documented in the [Resource section](#resources).

If the new team member also has server admin responsibilities, they will also need access to the **Infrastructure Plan** resources.

## Communication Plan

Project managers and developers will communicate via email for asynchronous communication and schedule in-person or video call meetings for real-time communication. All project management and communication documents will be stored on a Google Drive folder shared with all managers and developers.

See the [Resources](#management-documents) section below for a link to the Drive folder. 

## Software Management Plan

All software and technical design documents will be stored on a Github repository accessible to the project managers and developers. Trello will be used to create, manage, and track development tasks and goals.

See the [Resources](#software-management) section below for a link to the Github repository.

## Credentials Management Plan

All credentials and sensitive configuration files required to run the application on any environment [local, test, production, etc.] will be stored on the Box platform. A folder named “Peer Presents Credentials” has been created. All managers and developers should be given read access to this folder. Anyone in this team can access files containing sensitive credentials and configuration files used by the PeerPresents application.

See the [Resources](#credential-management) section below for a link to the Box folder. 

## Infrastructure Plan

All computing environments used to support the PeerPresents application are hosted by the Campus Cloud service. Project managers and lead technical team members should be on the “responsible parties” list for our Campus Cloud account.

See the [Resources](#infrastructure-information) section below for Campus Cloud information. 

## Resources

### Management Documents

**owner**: [Jessica Hammer](mailto:hammerj@andrew.cmu.edu )

[*Drive Folder*](https://drive.google.com/drive/folders/1hQJEi4TPYUIwRaUkKU7oiezEdbcghkbC?usp=sharing)

-   Project Plan
-   Meeting Notes
-   Open Questions Doc
-   Design Documents Folder

### Software Management

**owner**: [Gal Fleissig](mailto:gfleissi@andrew.cmu.edu)

[*PeerPresents Github Repository*](https://github.com/Ludolab/PeerPresents)

[*Trello*](https://trello.com/b/wLpGWJtl/peerpresents)

### Credential Management

**owner**: [Jessica Hammer](mailto:hammerj@andrew.cmu.edu )

CMU Box folder: [Peer Presents Credentials](https://cmu.box.com/s/hijj6ndc2seg3viexbofdt6msdi477z9)
* Contains sensitive information which should only be shared with management and technical staff.

### Infrastructure Information

**owner**: [Jessica Hammer](mailto:hammerj@andrew.cmu.edu )

All VMs are hosted by CMU [Campus Cloud](https://www.cmu.edu/computing/services/infrastructure/server/campus-cloud/index.html) service.

[User Documentation](https://www.cmu.edu/computing/services/infrastructure/server/campus-cloud/documentation.html)

Contact for technical issues: [Campus-Cloud-Help@cmu.edu](mailto:Campus-Cloud-Help@cmu.edu)


Contact for administrative and billing issues: [Campus-Cloud@cmu.edu](mailto:Campus-Cloud@cmu.edu)

Account Name: HCII-OHLab



