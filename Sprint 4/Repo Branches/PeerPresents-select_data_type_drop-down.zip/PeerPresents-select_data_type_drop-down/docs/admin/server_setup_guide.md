# Server Setup Guide

This guide describes how to do the initial setup for a PeerPresents environment. This guide assumes the machine you are working on matches the environment described in the Administration Guide.

## Table of Contents

1. [Web Server Setup](#web-server-setup)
2. [Node.js Setup](#install-node.js)
3. [Application Database Setup](#mongodb-setup)

## Web Server Setup

First you will need to setup a web server. Follow the install and configuration instructions below.

### 1. Install Software

Update the system before installing any new packages.

Log in as the root user and run the follow command:

```
# dnf update -y
```



#### Enable EPEL

You'll need to enable the EPEL (Extra Packages for Enterprise Linux) repository.

For CentOS 8 you can run the command:

```
# dnf install https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm
```

#### Install git

Git will be used to manage source code.

Run this command to install git:

```
# dnf install git
```

#### Install Nginx

Nginx is the webserver which is used to serve the frontend application.

Run this command to install Nginx:

```
# dnf install nginx
```

After installation is complete, run the following commands to enable and start the server:

```
# systemctl enable nginx
# systemctl start nginx
```

This will make Nginx start at system boot.

#### Install Certbot

Certbot is a tool used for generating SSL certificates. You will need to use the SSL certs created by Certbot to support HTTPS in the PeerPresents App.

Run this command to install Certbot

```
# dnf install certbot python3-certbot-nginx
```



### 2.  Configuration

#### Firewall Rules

First check that the firewall is enabled and running:

```
# systemctl status firewalld
```

If not, run the following commands to enable and start the firewall service:

```
# systemctl enable firewalld
# systemctl start firewalld
```

Next enable HTTP connections by running:

```
# firewall-cmd --permanent --add-service=http
```

Next enable a port used by PeerPresents:

```
# firewall-cmd --permanent --add-port=3010/tcp
```

Next enable a port used by the Application Database:

```
# firewall-cmd --permanent --add-port=30300/tcp
```

Then verify it was added correctly with the command below. You should see `http` listed with "services:"

```
# firewall-cmd --permanent --list-all
```

**Note:** to apply the changes, you'll need to reload the firewall service:

```
# firewall-cmd --reload
```

#### SSL Cert Config

Now you can generate SSL certificates for this machine. Run the following command and follow the prompts:

```
# certbot --nginx
```

That command will save the certificates and key in the `/etc/letsencrypt/live/` directory. However it should automatically config Nginx to use the new certs.

#### Nginx Config

At this point the web server should be accessible via HTTPS to the domain name of the server (E.g. peerpresents-test.andrew.cmu.edu).

Next you need to configure Nginx to serve the frontend component of PeerPresents.

Currently, the configuration is serving files from `/usr/share/nginx/html/` . Instead, we are going to change the config to make it serve from `/usr/share/nginx/html/web-build/`.

To do so you will need to edit the file `/etc/nginx/nginx.conf` as the `root` user. In that file, find the server block "managed by Certbot" and change the value for the "root" field. It should like similar to the text below:

```
    server {
    server_name peerpresents-test.andrew.cmu.edu; # managed by Certbot
        root         /usr/share/nginx/html/web-build;

        # Load configuration files for the default server block.
        include /etc/nginx/default.d/*.conf;

        location / {
        }

        error_page 404 /404.html;
            location = /40x.html {
        }

        error_page 500 502 503 504 /50x.html;
            location = /50x.html {
        }


    listen [::]:443 ssl ipv6only=on; # managed by Certbot
    listen 443 ssl; # managed by Certbot
    ssl_certificate /etc/letsencrypt/live/peerpresents-test.andrew.cmu.edu/fullchain.pem; # managed by Certbot
    ssl_certificate_key /etc/letsencrypt/live/peerpresents-test.andrew.cmu.edu/privkey.pem; # managed by Certbot
    include /etc/letsencrypt/options-ssl-nginx.conf; # managed by Certbot
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem; # managed by Certbot

}
```

Change the config to match:

```
# For more information on configuration, see:
#   * Official English Documentation: http://nginx.org/en/docs/
#   * Official Russian Documentation: http://nginx.org/ru/docs/

user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

# Load dynamic modules. See /usr/share/doc/nginx/README.dynamic.
include /usr/share/nginx/modules/*.conf;

events {
    worker_connections 1024;
}

http {
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    access_log  /var/log/nginx/access.log  main;

    sendfile            on;
    tcp_nopush          on;
    tcp_nodelay         on;
    keepalive_timeout   65;
    types_hash_max_size 2048;

    include             /etc/nginx/mime.types;
    default_type        application/octet-stream;


    server {
        # HTTPS web proxy
        server_name peerpresents-test.andrew.cmu.edu;

        listen [::]:443 ssl ipv6only=on;
        listen 443 ssl;
        ssl_certificate /etc/letsencrypt/live/peerpresents-test.andrew.cmu.edu/fullchain.pem;
        ssl_certificate_key /etc/letsencrypt/live/peerpresents-test.andrew.cmu.edu/privkey.pem;
        include /etc/letsencrypt/options-ssl-nginx.conf;
        ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;

        ## Serves backend api requests to frontend app
        location /api {
            #
            proxy_set_header    Host $host;
            proxy_set_header    X-Real-IP $remote_addr;
            proxy_pass          http://localhost:3010;
        }


        ## Serves static frontend app content
        location / {
            root    /usr/share/nginx/html/web-build;
            index   index.html;
        }
    }

    server {
        # Redirect HTTP to HTTPS
        listen 80;
        listen [::]:80;
        server_name peerpresents-test.andrew.cmu.edu;

        return    301 https://peerpresents-test.andrew.cmu.edu;
    }

}
```





To have the changes take affect run the command:

```
# systemctl reload nginx
```

Now we can deploy PeerPresents build to `/usr/share/nginx/html/web-build/`.

## Install Node.js

PeerPresents uses uses Node.js v12+. 

Download and install the latest LTS version of Node.js. CentOS package mangers do not have the latest version so you will need to download and install it manually.

Find a link to an x64 Linux binary here: https://nodejs.org/en/download/
Copy the link, it should look something like: `https://nodejs.org/dist/v12.17.0/node-v12.17.0-linux-x64.tar.xz`

Run the following commands as the `root` user.

Download the binary onto the server with the command (replace with your link):

```
# wget https://nodejs.org/dist/v12.17.0/node-v12.17.0-linux-x64.tar.xz
```

Then extract it in the `/opt` directory:

```
# tar xf node-v12.17.0-linux-x64.tar.xz -C /opt
```

Now you should be able to see a newly created directory, `node-v12.17.0-linux-x64`,  in `/opt`:

```
# ls /opt
```

Next you have to create a script that automatically adds the Node.js path to the PATH environment variable whenever the machine starts.

Use the script below but **change the version** to match your version.

```
export NODE_VERSION=v12.17.0
export NODE_DISTRO=linux-x64
export NODE_HOME="/opt/node-${NODE_VERSION}-${NODE_DISTRO}"
export PATH="$PATH:${NODE_HOME}/bin"
```

As the `root` user, create the file `/etc/profile.d/node-v12.sh`:

```
# touch /etc/profile.d/node-v12.sh
```

Next use a text editor to copy the script from above into the newly created `node-v12.sh` file. Remember to **check the version** to match your install.

```
# nano /etc/profile.d/node-v12.sh
```

This script won't take affect until the next time the system reboots. You can run it now as the `peerpresents` user. Run the command:

```
$ source /etc/profile.d/node-v12.sh
```

To verify the path is set run the following command:

```
$ echo $PATH
```

The output should contain `/opt/node-v12.17.0-linux-x64/bin` (with your version number), as shown here:

```
/home/peerpresents/.local/bin:/home/peerpresents/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/opt/node-v12.17.0-linux-x64/bin
```

To verify the Node.js environment variables are set:

```
env | grep NODE
```

The output should look like this:

```
NODE_HOME=/opt/node-v12.17.0-linux-x64
NODE_DISTRO=linux-x64
NODE_VERSION=v12.17.0
```

Finally, check you can use `node` and `npm` as the `peerpresents` user:

```
$ node --version
v12.17.0

$ npm --version
6.14.4
```

If the output looks as expected, Node.js v12+ is ready for PeerPresents to use.

## MongoDB Setup

PeerPresents uses MongoDB as its Application Database. You will need to install mongodb version 3.6 or higher.

The follow instructions are based on this [MongoDB documentation](https://docs.mongodb.com/manual/tutorial/install-mongodb-on-red-hat/).

### Configure Package Manager

MongoDB is not present in the CentOS 8 repository by default so you will have to add it manually.

Create a repository file as the `root` user:

```
# nano /etc/yum.repos.d/mongodb.repo
```

Paste the configuration below and save the file:

```
[mongodb-org-4.2]
name=MongoDB Repository
baseurl=https://repo.mongodb.org/yum/redhat/$releasever/mongodb-org/development/x86_64/
gpgcheck=1
enabled=1
gpgkey=https://www.mongodb.org/static/pgp/server-4.2.asc
```

### Install Packages

Now that the MongoDB repo is configured and enabled, you can install the packages with the following command as the `root` user:

```
# dnf install -y mongodb-org
```

### Enable and Run

Next you and start and enable MongoDB to start on system boot by running the following commands as the `root` user:

```
# systemctl start mongod
# sudo sytemctl enable mongod
```

You can check to see if MongoDB is running or not with:

```
# systemctl status mongod
```

### Configure MongoDB for PeerPresents (Production)

Now that MongoDB is installed and running, it is ready to be configured to work with the PeerPresents Application.

The following section will guide you through creating a new database for PeerPresents to use, creating a user with read/write permission on that new database, and configuring MongoDB so it can communicate to PeerPresents over the network. Then you will see how to fill out the database config file used by PeerPresents.

#### 1. Prepare a Password-Protected Database

You can create and configure a new database through the mongo Shell. To start the Shell run the command:

```
$ mongo
```

After running that command you will be in the mongo Shell instead of the normal bash/etc. shell you were using. You can type `help` for information on the commands available:

```
> help
        db.help()                    help on db methods
        db.mycoll.help()             help on collection methods
        sh.help()                    sharding helpers
        rs.help()                    replica set helpers
        help admin                   administrative help
        help connect                 connecting to a db help
        help keys                    key shortcuts
        help misc                    misc things to know
        help mr                      mapreduce

        show dbs                     show database names
        show collections             show collections in current database
        show users                   show users in current database
        show profile                 show most recent system.profile entries with time >= 1ms
        show logs                    show the accessible logger names
        show log [name]              prints out the last segment of log in memory, 'global' is default
        use <db_name>                set current database
        db.foo.find()                list objects in collection foo
        db.foo.find( { a : 1 } )     list objects in foo where a == 1
        it                           result of the last line evaluated; use to further iterate
        DBQuery.shellBatchSize = x   set default number of items to display on shell
        exit                         quit the mongo shell
```

First you need to create a database. To create one named, "peerpresents-test", use the command:

```
> use peerpresents-test
```

This switches you to the database "peerpresents-test", however it won't be saved until you modify it.

Next you can create a password-protected user that has read and write access the new database. The following command in the mongo Shell will create a new user named "appuser" and grant them read/write access to the "peerpresents-test" database:

```
> db.createUser(
  {
    user: "appuser",
    pwd: passwordPrompt(),  // or cleartext password
    roles: [
       { role: "readWrite", db: "peerpresents-test" }
    ]
  }
)
```

This will prompt you to input a password. Generate a secure password and **write it down** then enter it into the prompt.

You will need to keep three pieces of information for the application database config file used by PeerPresents:

1. database name (e.g. "peerpresents-test")
2. user name (e.g. "appuser")
3. user's password (password you entered for "appuser")

#### 2. Configure Networking

With a database ready to go, you just need to make sure mongodb is configured to accept requests over the network. To do so you will need to modify it's config file and restart the mongoDB service.

You need to determine what IP address and which Port number MongoDB should listen on for requests.

You need to check what the server's external IP address is.

Run this command to see:

```
$ ip a
```

The output will look like:

```
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host
       valid_lft forever preferred_lft forever
2: ens160: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
    link/ether 00:50:56:9d:a0:d4 brd ff:ff:ff:ff:ff:ff
    inet 128.2.25.149/22 brd 128.2.27.255 scope global noprefixroute ens160
       valid_lft forever preferred_lft forever
    inet6 fe80::cc78:e548:51ac:ed3a/64 scope link noprefixroute
       valid_lft forever preferred_lft forever
```

The first section to contain `link/ether` should be the server's external network interface. The following line contains the external IP address (following `inet`). In this example the IP address is: `128.2.25.149`

Now that you know the IP you can determine the Port number to use. The default port for PeerPresents is: 30300

You may change the port number if needed, however you will need to modify the [firewall rules](#firewall-rules) accordingly.

Now that you know the IP address and port number, you can change the mongodb config. Open following file as the `root` user:

```
# nano /etc/mongod.conf
```

With the text file open, you will need to modify two lines in the "net" section. By default the net section should look like this:

```
# network interfaces
net:
  port: 27017
  bindIp: 127.0.0.1
```

Modify this to match the IP and port that you need. Note that external IP addresses should be added to the "bindIp:" field as a list (as to listen to both local and external traffic).

Example:

```
# network interfaces
net:
  port: 30300
  bindIp: 127.0.0.1,128.2.25.149
```

With your changes made, save the file. Then you can restart MongoDB:

```
# systemctl restart mongod
```

Double check that MongoDB is still running after your restart:

```
$systemctl status mongod
● mongod.service - MongoDB Database Server
   Loaded: loaded (/usr/lib/systemd/system/mongod.service; enabled; vendor preset: disabled)
   Active: active (running) since Wed 2020-06-10 14:14:10 EDT; 5s ago
```

Keep the IP address and port number close because you will need to store them in the application database config file used by PeerPresents.

#### 3. Create PeerPresents Database Config File

At this point the MongoDB is ready to go for PeerPresents to use. Now you just need to store some config information in a file for PeerPresents to use.

The app database config file should be managed according to the [Credentials Management Plan](../dev/project_management_plan.md#credentials-management-plan).

In the source code, this config file is stored as: `PeerPresents/storage/config/ppdb_conf.js`

Example "dummy" config file:

```
module.exports = {
    mongo: {
        ip: "127.0.0.0",
        port: 55555,
        name: "fakedb",
        user: "fakeuser",
        pwd: "fakepassword"
    }
};
```

Using the examples above, the config file should look something like this:

```
module.exports = {
    mongo: {
        ip: "128.2.25.149",
        port: 30300,
        name: "peerpresents-test",
        user: "appuser",
        pwd: "fakepassword"
    }
};
```

This information should never be stored in the Github repo. Only the "dummy" version of the file should be accessible by anyone outside the PeerPresents team.

This updated config file should be stored on Box or according the to Credentials Management Plan linked above.

### Configure MongoDB for PeerPresents (Local)

There are two main parts for the PeerPresents application - the front and back-end code, and the database.
Once users start using the application, we would like to separate our development and testing application from the production application, and make sure that the entire development is done locally (or not on the server). Once the changes are stable - we can deploy them into the server.

This is currently the practice with the front and back-end code - we develop on the localhost and deploy changes to the server once they are stable. The following section will guide you through creating a local database, creating a user with read/write permission on that new database, and configure MongoDB and the application so they can communicate locally. The new database will be empty and you will not need to configure any collections or tables from scratch.

It is good practice to always work with the local database, so that any changes made to it will not be reflected in the production environment.


#### 1. Install MongoDB on your local machine

You can run the following command to check if it is already installed:

```
$ mongo --version
```
If it is not, follow this link https://docs.mongodb.com/manual/installation/

#### 2. Prepare a Password-Protected Database

You can create and configure a new database through the mongo Shell. To start the Shell run the command:

```
$ mongo
```

After running that command you will be in the mongo Shell instead of the normal bash/etc. shell you were using. You can type `help` for information on the commands available:

```
> help
        db.help()                    help on db methods
        db.mycoll.help()             help on collection methods
        sh.help()                    sharding helpers
        rs.help()                    replica set helpers
        help admin                   administrative help
        help connect                 connecting to a db help
        help keys                    key shortcuts
        help misc                    misc things to know
        help mr                      mapreduce

        show dbs                     show database names
        show collections             show collections in current database
        show users                   show users in current database
        show profile                 show most recent system.profile entries with time >= 1ms
        show logs                    show the accessible logger names
        show log [name]              prints out the last segment of log in memory, 'global' is default
        use <db_name>                set current database
        db.foo.find()                list objects in collection foo
        db.foo.find( { a : 1 } )     list objects in foo where a == 1
        it                           result of the last line evaluated; use to further iterate
        DBQuery.shellBatchSize = x   set default number of items to display on shell
        exit                         quit the mongo shell
```

First you need to create a database. To create one named, "peerpresents-local", use the command:

```
> use peerpresents-local
```

This switches you to the database "peerpresents-local", however it won't be saved until you modify it.

Next you can create a password-protected user that has read and write access the new database. The following command in the mongo Shell will create a new user named "appuser" and grant them read/write access to the "peerpresents-local" database:

```
> db.createUser(
  {
    user: "appuser",
    pwd: passwordPrompt(),  // or cleartext password
    roles: [
       { role: "readWrite", db: "peerpresents-local" }
    ]
  }
)
```

This will prompt you to input a password. Generate a secure password and **write it down** then enter it into the prompt.

You will need to keep three pieces of information for the application database config file used by PeerPresents:

1. database name (e.g. "peerpresents-local")
2. user name (e.g. "appuser")
3. user's password (password you entered for "appuser")

#### 3. Modify the MongoDB configuration file (if needed)

Now you might need to modify the config file. This file determines what IP address and which Port number your local MongoDB should listen on for requests. Then you will need to restart the mongoDB service if it is already running.

Open following file as the `root` user:

```
# nano /etc/mongod.conf
```

With the text file open, you will need to modify two lines in the "net" section. By default the net section should look like this, and for simplicity we want to keep it this way (although you can change the information):

```
# network interfaces
net:
  port: 27017
  bindIp: 127.0.0.1
```

If it does not, make sure to change it so it has this 'port' and 'bindIp'. With your changes made, save the file. Then you can restart MongoDB:

```
# restart mongod
```

or quit the running database and re-run it.

Double check that MongoDB is still running after your restart:

```
$ status mongod
● mongod.service - MongoDB Database Server
   Loaded: loaded (/usr/lib/systemd/system/mongod.service; enabled; vendor preset: disabled)
   Active: active (running) since Wed 2020-06-10 14:14:10 EDT; 5s ago
```

Keep the IP address and port number close because you will need to store them in the application database config file used by PeerPresents.

#### 4. Modify the PeerPresents Database Config File

At this point the local MongoDB database is ready to go for PeerPresents to use. Now you just need to store some config information in a file for PeerPresents to use.

In the source code, this config file is stored as: `PeerPresents/storage/config/ppdb_conf.js`

Example "dummy" config file:

```
module.exports = {
    mongo: {
        ip: "127.0.0.0",
        port: 55555,
        name: "fakedb",
        user: "fakeuser",
        pwd: "fakepassword"
    }
};
```

Using the examples above, the config file should look something like this:

```
module.exports = {
    mongo: {
        ip: "127.0.0.1",
        port: 27017,
        name: "peerpresents-local",
        user: "appuser",
        pwd: "fakepassword"
    }
};
```

This information should never be stored in the Github repo. Only the "dummy" version of the file should be accessible by anyone outside the PeerPresents team.
This information is personal and local. Other developers will create their own local database along with their own user and password.

#### 5. Running the local database

Now that the database is ready to go and all of the configuration files have been modified, you need to make sure that your local database is running while you are using it. To do so, run the following command:

```
$ mongod
```

If you do not have permissions to run this command use:

```
$ sudo mongod
```

If you get an error message stating:

```
"attr":{"error":"NonExistentPath: Data directory /data/db not found. Create the missing directory or specify another path using (1) the --dbpath command line option, or (2) by adding the 'storage.dbPath' option in the configuration file."}
```

then you should specify the database path. You can use the following command:

```
$ sudo mongod --dbpath data/db/
```

and make sure to point to the correct path where the 'db' folder is positioned inside the 'data' folder.

Once the database is up and running, you can run the storage, backend worker and front-end of the app as you normally would, and start using the local database.




