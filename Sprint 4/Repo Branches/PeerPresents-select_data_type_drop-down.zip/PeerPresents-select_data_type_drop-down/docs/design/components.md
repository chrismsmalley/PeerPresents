# Components

Implementation-specific details of the major components are documented here.

## Frontend

User interface that handles all user actions. This component is a web application that sends requests to the Backend API.

**Networking**

Listens on http/https ports (80/443)

## Backend

#### Web Server / HTTP Load Balancer

This component handles all requests from Frontend clients and directs the requests to Worker services.

**Networking**

Listens on ports 80/443

#### Worker Service

This component handles all requests from Frontend clients. Worker services handle the actual request and respond to the Frontend client. Most requests result in the Worker sending one or many requests to the Storage Service. At small scale, only one instance of the Worker service is needed. A Master is only needed to dynamically manage Worker services.

**Networking**

Listens on port range 30200 - 30299

#### Master

When scaling up the application, the Backend Master will monitor the load on Workers. The Master is responsible for starting up new Worker services when the load is too high, and to shutdown Workers when the load is low. It is also responsible for modifying the configuration for the HTTP load balancer to share API request traffic evenly among the available Workers.

**Networking**

Listens on port range 30100 - 30199

## Storage

This component handles all requests from the Worker services for database actions. It offers CRUD operations on all the defined data models for the Application Database.

**Networking**

Listens on port range 30300 - 30399

## Session Store

This component is used when scaling up the application. Its purpose is to store any meta-data that may need to be shared between multiple Workers. This can provide the functionality to "persist session state". At the time of writing this, the PeerPresents application uses a stateless API so it may not be needed. However, portions of the API may be changed to require "session state" information.