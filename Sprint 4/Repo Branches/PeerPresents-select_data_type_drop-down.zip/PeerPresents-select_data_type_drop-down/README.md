# PeerPresents

## Introduction

PeerPresents is a web-based system for in-class peer feedback during student presentations.

Peer feedback systems enable students to get feedback without substantially burdening the instructor. However, current systems typically ask students to provide feedback after class; this introduces challenges for ensuring relevant, timely, diverse, and sufficient amounts of feedback, and reduces the time available for student reflection. PeerPresents is a novel system for in-class peer review where students can quickly exchange feedback on projects without being burdened by additional work outside of class. We found students can receive immediate, copious, and diverse peer feedback through a structured in-class activity. Students also described the feedback they received as helpful and reported that they gave more feedback than without using the system. These early results demonstrate the potential benefits of in-class peer feedback systems.

## Project Documentation

All the information for the PeerPresents source code is documented here.

### Table of Contents


1. Design
   1. [Design Overview](docs/design/design.md)
   2. [Components](docs/design/components.md)
2. Development
   1. [Project Management Plan](docs/dev/project_management_plan.md)
   2. [Local Development Setup Guide](docs/dev/local_dev_guide.md)
   3. [Backend Development Guide](docs/dev/backend_dev_guide.md)
3. Administration
   1. [Application Admin Guide](docs/admin/app_quick_guide.md)
   2. [Server Admin Guide](docs/admin/administration.md)
   3. [Application Setup Guide](docs/admin/application_setup_guide.md)
   4. [Server Setup Guide](docs/admin/server_setup_guide.md)

