import React, { Component } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Colors } from '../global/Constants';
import { Picker } from "@react-native-picker/picker";
import { VictoryBar, VictoryChart, VictoryAxis, VictoryGroup, VictoryTooltip } from "victory";
import window from "../global/Layout";
import GraphsContainer from './GraphsContainer';
import { getAllDatasetIDs, getDataset, getGraph } from '../custom-modules/backendAPI';



export default class Graph extends Component {

  constructor(props) {
    super(props);

    this.state = {
      titleVariable: this.props.item[0],
      totalAverageVariable: this.props.item[1],
      personTeamVariable: this.props.item[2],
      sessionList: this.props.sessionList,
      graphData: this.props.dataset.getQuestions(),
      dataset: this.props.dataset,
    }
  }

  //unused
  componentDidMount() {
    // var data = Object.values(this.state.dataset.sessions).map((session, index) => { // data is a new array resulting from mapping over the values of the sessionsData object in the this.state object. Each element in the new data array is the result of calling the function provided in the .map() method.
    //   var values = this.state.graphData[index].map((datum) => datum.y); // values is an array that contains only the y values from each object in the this.graphData[index] array
    //   return {
    //     x: index + 1,
    //     y: totalAverageVariable === "total" ? values.reduce((a, b) => a + b) : values.reduce((a, b) => a + b) / values.length, //ternary operator if "total" is true then gives total, if false gives average
    //   }
    // })
    // console.log(data)
    // this.setState( (prevState) => ({
    //   ...prevState,
    //   graphData: this.props.dataset.getResponses(),
    //   sessionsData: [
    //   { session: "Game Design Project 1" },
    //   { session: "Final Project" },
    //   { session: "Documentation Design Final" },
    //   ],
    //   // data: data,
    // }));

  }

 // Test Data y axis
// sessionsData = [
//     { session: "Game Design Project 1" },
//     { session: "Final Project" },
//     { session: "Documentation Design Final" },
// ];

  // // // Test Data x axis
  // graphData = [
  //   [
  //     { x: 1, y: 6 },
  //     { x: 2, y: 2 },
  //     { x: 3, y: 4},
  //   ],
  //   [
  //     { x: 1, y: 4 },
  //     { x: 2, y: 8 },
  //     { x: 3, y: 5 },
  //   ],
  //   [
  //     { x: 1, y: 2 },
  //     { x: 2, y: 6 },
  //     { x: 3, y: 8 },
  //   ],
  //   [
  //     { x: 1, y: 2 },
  //     { x: 2, y: 2 },
  //     { x: 3, y: 1 },
  //   ],
  //   [
  //     { x: 1, y: 1 },
  //     { x: 2, y: 4 },
  //     { x: 3, y: 6 },
  //   ],
  //   [
  //     { x: 1, y: 1 },
  //     { x: 2, y: 6 },
  //     { x: 3, y: 4 },
  //   ],
  // ];

  setResponses() {
    this.setState( (state, datatype) => ( {
      graphData: this.props.dataset.getResponses()
    } ) )
  }
  setReacts() {
    this.setState( (state, datatype) => ( {
      graphData: state.dataset.getReacts()
    } ) )
  }
  setTags() {
    this.setState( (state, datatype) => ( {
      graphData: state.dataset.getTags()
    } ) )
  }
  setUpvotes() {
    this.setState( (state, datatype) => ( {
      graphData: state.dataset.getUpvotes()
    } ) )
  }
  setStars() {
    this.setState( (state, datatype) => ( {
      graphData: state.dataset.getStars()
    } ) )
  }

  setQuestions() {
    this.setState( (state, datatype) => ( {
      graphData: state.dataset.getQuestions()
    } ) )
  }

  setDatatype(value) {
    console.log(`${value} option picked`)
    switch (value) {
      case "questions": this.setQuestions()
      case "responses": this.setResponses()
      case "reacts": this.setReacts()
      case "tags": this.setTags()
      case "upvotes": this.setUpvotes()
      case "stars": this.setStars()
    }
  }

  render() {
    const victory_bars = []

    // console.log("State:", this.state);
    // // original
    // var data = Object.values(this.state.sessionsData).map((session, index) => { // data is a new array resulting from mapping over the values of the sessionsData object in the this.state object. Each element in the new data array is the result of calling the function provided in the .map() method.
    //   const values = this.state.graphData[index].map((datum) => datum.y); // values is an array that contains only the y values from each object in the this.graphData[index] array
    //   return {
    //     x: index + 1,
    //     y: totalAverageVariable === "total" ? values.reduce((a, b) => a + b) : values.reduce((a, b) => a + b) / values.length, //ternary operator if "total" is true then gives total, if false gives average
    //   }
    // })

    // tweaked Chris's code to make multiple VictoryBars
    for (let i = 0; i < this.state.graphData.length; i++) {
      const data = this.state.graphData[i].map((datum) => {
        return {
          x: datum.x + 1,
          y: datum.y,
          label: `X: ${datum.x}\nY: ${datum.y.toFixed(2)}`,
          events: [  //supposed to be the hover feature that creates a flyout with data from "labels" but only changes the bar color no flyout
            {
              target: "data",
              eventHandlers: {
                onMouseOver: () => { // user hovers over
                  console.log("mouse over event triggered"); // message in console log for verification purposes
                  return [
                    {
                      target: "data",
                      mutation: (props) => {
                        console.log("style mutation triggered"); // message in console log for verification purposes
                        return { style: { fill: "purple" } }; // changes bar to purple color
                      }
                    },
                    {
                      target: "label",
                      mutation: () => {
                        return { active: true }; // supposed to activate labels
                      }
                    }
                  ];
                },
                onMouseOut: () => { // user leaves data point
                  console.log("mouse out event triggered"); // message in console log for verification purposes
                  return [
                    {
                      target: "data",
                      mutation: () => {
                        return null; //removes changes to data point
                      }
                    },
                    {
                      target: "label",
                      mutation: () => {
                        return { active: false }; // deactivates any labels associated to data point
                      }
                    }
                  ];
                }
              }
            }
          ],
        }
      } );
      victory_bars.push(
        <VictoryBar
          key={i.toString()}
          data={data}
        />
      );
    };

    return (
      <View style={styles.graph}>
        <Text style={styles.graphText}>Select variables to visualize</Text>
        <Picker
          selectedValue={this.state.titleVariable}
          onValueChange={ (value) => {
            this.setState({titleVariable: value})
            this.setDatatype(value)
          } }
          style={styles.picker}
          placeholder={{ label: "Select data type" }}
        >
          <Picker.Item
            style={styles.pickerItem}
            label="Number Number of Questions asked by Presenters"
            value="questions"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Replies to Questions" // "textual replies"
            value="responses"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Emoji Reactions to Feedbacks" // these are reacts
            value="reacts"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Star Rating Reactions to Feedbacks"
            value="stars"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Upvotes Given"
            value="upvotes"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Tags Used"
            value="tags"
          />
        </Picker>

        {/* Graph */}
        <VictoryChart
          height={window.window.height / 2}
          width={window.window.width / 2}
          domainPadding={{ x: 10, y: 10 }} // add padding to the y-axis domain
          padding={{ top: 50, bottom: 50, right: 0, left: 50 }}
          animate={{
            duration: 2000,
            onLoad: { duration: 1000 }
          }}
        >
          <VictoryAxis
            domain={[0, 5]} // Set the x-axis limit of domain to values between 0 and 10
            label="Sessions" // defines the text that appears in the tooltip
            tickValues={ Object.values(this.props.sessionList).map( session => { return session.session } ) }
            tickFormat={(x) => x}
          />
          <VictoryAxis
            dependentAxis
            tickFormat={(y) => y}
            tickCount={5}
            domain={[0, 10]} // set the domain of the y-axis
          />

          <VictoryGroup
            offset={60}
            colorScale={"blue"}
          >
              {victory_bars}
          </VictoryGroup>
        </VictoryChart>

        <View style={styles.subPickers}>
          <Picker //used as a way for the user to select a value for totalAverageVariable
            selectedValue={this.state.totalAverageVariable}
            onValueChange={(value) =>
              this.setState({totalAverageVariable: value})
            }
            style={styles.subPicker}
            placeholder={{ label: "select variable" }}
          >
            <Picker.Item //allows individual items to be rendered within the Picker dropdown menu
              style={styles.subPickerItem}
              label="total"
              value="total"
            />
            <Picker.Item //allows individual items to be rendered within the Picker dropdown menu
              style={styles.subPickerItem}
              label="average"
              value="average"
            />
          </Picker>
          <Picker
            selectedValue={this.state.personTeamVariable}
            onValueChange={(value) =>
              this.setState({personTeamVariable: value})
            }
            style={styles.subPicker}
            placeholder={{ label: "select variable" }}
          >
            <Picker.Item
              style={styles.subPickerItem}
              label="from person"
              value="from person"
            />
            <Picker.Item
              style={styles.subPickerItem}
              label="from team"
              value="from team"
            />
          </Picker>
        </View>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  graph: {
    marginTop: 30,
    borderRadius: 30,
    marginBottom: 25,
    backgroundColor: "white",
    width: window.window.width / 1.5,
    height: window.window.height / 1.1,
  },
  graphText: {
    fontSize: 12,
    color: Colors.ppGreyText,
    marginTop: 20,
    marginLeft: 30,
  },
  picker: {
    marginTop: 30,
    marginLeft: 30,
    marginRight: 30,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: Colors.ppGreyText,
    fontSize: window.window.height / 50,
    width: window.window.width / 1.6,
    height: window.window.height / 10,
    fontSize: 20,
    fontWeight: "bold",
    color: Colors.ppTextColor,
    paddingLeft: 10,
  },
  pickerItem: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 30,
    color: Colors.ppTextColor,
  },
  subPickers: {
    marginVertical: 10,
    marginLeft: 30,
    marginRight: 30,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  subPicker: {
    borderColor: Colors.ppGreyText,
    padding: 10,
    borderWidth: 1,
    borderRadius: 10,
    fontSize: 18,
  },
});


// <VictoryGroup
// offset={60}
// colorScale={"blue"}
// >
// {/* {Object.entries(graphData).forEach( (session, s_index) => { */}
// { graphData.map( session => {
//   session.map((datum, index) => {(
//   <VictoryBar
//     key={index.toString()}
//     name={`bar-${index+1}`}
//     barRatio={0.1}
//     barWidth={3}
//     alignment="middle"
//     padding={1}
//     data={[{ x: datum.x, y: datum.y }]}
//     labelComponent={<VictoryTooltip/>}
//     labels={
//       (datum) => `X: ${datum.x}\nY: ${datum.y.toFixed(2)}`}
//     events={[  //supposed to be the hover feature that creates a flyout with data from "labels" but only changes the bar color no flyout
//       {
//         target: "data",
//         eventHandlers: {
//           onMouseOver: () => { // user hovers over
//             console.log("mouse over event triggered"); // message in console log for verification purposes
//             return [
//               {
//                 target: "data",
//                 mutation: (props) => {
//                   console.log("style mutation triggered"); // message in console log for verification purposes
//                   return { style: { fill: "purple" } }; // changes bar to purple color
//                 }
//               },
//               {
//                 target: "labels",
//                 mutation: () => {
//                   return { active: true }; // supposed to activate labels
//                 }
//               }
//             ];
//           },
//           onMouseOut: () => { // user leaves data point
//             console.log("mouse out event triggered"); // message in console log for verification purposes
//             return [
//               {
//                 target: "data",
//                 mutation: () => {
//                   return null; //removes changes to data point
//                 }
//               },
//               {
//                 target: "labels",
//                 mutation: () => {
//                   return { active: false }; // deactivates any labels associated to data point
//                 }
//               }
//             ];
//           }
//         }
//       }
//     ]}
//   />
// )})})}
// </VictoryGroup>
