import React, { Component } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { CheckBox } from 'react-native-elements';
import { Colors } from "../global/Constants";

export default class Checkbox extends Component {

  constructor(props: Props) {
    super(props);

    this.state = {
      checked: this.props.default,
    }
  }

  render() {
    return (
      <View>
        <CheckBox
          title={this.props.title}
          checked={this.state.checked}
          containerStyle={{
            backgroundColor: Colors.backgroundColor,
            borderColor: Colors.backgroundColor,
          }}
          onPress={() => {
            this.props.onPress(!this.state.checked);
            this.setState({checked : !this.state.checked});
          }}
        />
        <Text style={styles.helperText}>{this.props.explanationText}</Text>
      </View>
    )}
}

const styles = StyleSheet.create({
  helperText: {
    color: Colors.ppGreyText,
  },
});
