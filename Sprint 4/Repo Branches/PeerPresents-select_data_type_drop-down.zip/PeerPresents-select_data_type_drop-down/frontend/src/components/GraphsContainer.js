import React, { Component } from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { Colors } from "../global/Constants";
import window from "../global/Layout";
import Graph from './Graph';
import MainButton from './MainButton';
import { getDataset, getGraph, getPresentation, getSession, getQuestion, getResponse, getUpvote, getReact, getStar, getTag, getUser } from '../custom-modules/backendAPI';
import { FlatList } from 'react-native-gesture-handler';

var datasetTreeIsComplete = false; // control polling in componentDidMount()

export default class GraphsContainer extends Component {

  constructor(props) {
    super(props);
    this.state = {
      dataset: {},
      graphList: [],
      sessionList: [],
      sessionQuestionsDict: {}, // to-do: update
      // datasetTreeIsComplete: this.createDatasetTree().then( () => {
      //   this.state.datasetTreeIsComplete = true // once promise is fulfilled; used to control polling in componentDidMount()
      //   // that.setSessionQuestionsAndSessionList()
      //   // that.setUsers()
      //   return true
      // } )
    }
  }

  componentDidMount() {
    document.addEventListener("addGraphButtonClick", this.addGraph); // runs addGraph() on click event

    // not a permanent solution to Warning: Can't perform a React state update on an unmounted component. This is a no-op, but it indicates a memory leak in your application. To fix, cancel all subscriptions and asynchronous tasks in the componentWillUnmount method.
    // may have to conditionally render?
    // setTimeout( () => {
    //   this.setSessionQuestionsAndSessionList();
    //   this.setUsers();
    // }, 5000);

    this.createDatasetTree().then( (dataset) => {
      datasetTreeIsComplete = true // once promise is fulfilled; used to control polling in componentDidMount()
      // that.setSessionQuestionsAndSessionList()
      // that.setUsers()
    } );

    const treeListeningInterval = setInterval( () => { // start polling for datasetTreeIsComplete, prerequisite for setSessionQuestionsAndSessionList() and setUsers()
      if (datasetTreeIsComplete === true) {
        // this.setSessionQuestionsAndSessionList();
        setTimeout(() => {this.setUsers();},2500);
        clearInterval(treeListeningInterval); // discontinue polling
      }
     }, 25) // interval
    }

  // to-do: accept getGraph(graph_id, true), set state with new ["title", "total/average", "person/team"]
  // update id assignment logic if graph deletion is implemented
  addGraph = () => {
    this.setSessionList()
    this.setUsers()
    let newGraph = [
      "title",
      "total",
      "person",
      this.state.graphList.length.toString()] // last value is a key == (graphsList.indexOf(thisGraph) + 1), must be string
    this.setState(prevState => ({
      graphList: [...prevState.graphList, newGraph],
    }));
  }

  // basically an interface for setting sessionList the way it was before [ { 'session': session.title }, ..., ]
  setSessionList() {
    var sessionList = Object.values(this.state.dataset.sessions).map( (k) => { return { session: k.title } } );
    console.log(sessionList)
    this.setState( () => ({
      sessionList: sessionList,
    } ) )
  }

  // construct a dataset object tree where each object contains its children as objects mapped to their ids as keys
  async createDatasetTree() {
    /* declared separately, then folded into dataset for flexibility */
    let upvotes = {}; // done, not used
    let reacts = {}; // done
    let stars = {}; // done
    let tags = {}; // done
    let responses = {}; // done
    let questions = {}; // done
    let users = {}; // TBD method to populate lowest time complexity, least repeated code - create a user_id key if none exists, then send every type of object to user list?
    let teams = {}; // TBD create by presenter_list
    const helpers = {
      // helper definitions to be used by change datatype and graphs in Graphs component
        getResponses() {
        // map users to x values
        // may be okay to add more than { x, y } ifso it would be useful to have {x, y, user_id, session_id, data: { n-objects } } but TBD if Victory is okay with this
        var user_x_mappings = {};
        Object.keys(this.users).map( ( user_id, index ) => ( user_x_mappings[user_id] = index ) ) // {'user_id_1': 1,'user_id_2': 2,..., } for victory x values, consistent across sessions if different sets of users
        var responses = [] // responses[session][user] = count
        // let session_list = this.session_list
        for (let i = 0; i < this.session_list.length; i++) {
          let session_id = this.session_list[i] // scales better
          responses.push([]) // add a new session to the array
          Object.values(this.users).forEach( (user) => {
            // let user_x = user_x_mappings[user._id]
            let user_session_data_count = Object.entries(user.getData('responses', session_id)).length // Obj version
            // let user_session_data_count = user.getData('responses', session_id).length // Array version only
            responses[i].push( ( { x: user_x_mappings[user._id], y: user_session_data_count } ) )
            // map count to correct user x value
          })
        }
        // console.log(`responses inside getResponses() = ${responses}`);
        // update state if this is good

        return responses
      },

      getReacts() {
        // map users to x values
        // may be okay to add more than { x, y } ifso it would be useful to have {x, y, user_id, session_id, data: { n-objects } } but TBD if Victory is okay with this

        // const users = this.state.dataset.users
        // const user_x_mappings = Object.keys(users).map( ( user_id, index ) => ( { [user_id]: index } ) ) // {'user_id_1': 1,'user_id_2': 2,..., } for victory x values, consistent across sessions if different sets of users
        var user_x_mappings = {};
        Object.keys(this.users).map( ( user_id, index ) => ( user_x_mappings[user_id] = index ) ) // {'user_id_1': 1,'user_id_2': 2,..., } for victory x values, consistent across sessions if different sets of users
        var reacts = [] // reacts[session][user] = count
        // let session_list = this.state.dataset.session_list
        for (let i = 0; i < this.session_list.length; i++) {
          let session_id = this.session_list[i] // scales better
          reacts.push([]) // add a new session to the array
          Object.values(this.users).forEach( (user) => {
            // let user_x = user_x_mappings[user._id]
            let user_session_data_count = Object.entries(user.getData('reacts', session_id)).length // Obj version
            // let user_session_data_count = user.getData('reacts', session_id).length // Array version only
            reacts[i].push( ( { x: user_x_mappings[user._id], y: user_session_data_count } ) )
            // map count to correct user x value
          })
        }
        // console.log(`reacts inside getReacts() = ${reacts}`);
        return reacts
      },

      getUpvotes() {
        // map users to x values
        // may be okay to add more than { x, y } ifso it would be useful to have {x, y, user_id, session_id, data: { n-objects } } but TBD if Victory is okay with this

        // var users = this.state.dataset.users
        var user_x_mappings ={}
        Object.keys(this.users).map( ( user_id, index ) => ( user_x_mappings[user_id] = index ) ) // {'user_id_1': 1,'user_id_2': 2,..., } for victory x values, consistent across sessions if different sets of users

        var upvotes = [] // upvotes[session][user] = count
        // let session_list = this.state.dataset.session_list
        for (let i = 0; i < this.session_list.length; i++) {
          let session_id = this.session_list[i] // scales better
          upvotes.push([]) // add a new session to the array
          Object.values(this.users).forEach( (user) => {
            let user_session_data_count = Object.entries(user.getData('upvotes', session_id)).length // Obj version
            // let user_session_data_count = user.getData('upvotes', session_id).length // Array version only
            upvotes[i].push( ( { x: user_x_mappings[user._id], y: user_session_data_count } ) )
            // map count to correct user x value
          })
        }
        // console.log(`upvotes inside getUpvotes() = ${upvotes}`);
        // update state if this is good
        return upvotes
      },

      // TESTING (copy+paste from reacts changed varnames)
      getStars() {
        // map users to x values
        // may be okay to add more than { x, y } ifso it would be useful to have {x, y, user_id, session_id, data: { n-objects } } but TBD if Victory is okay with this

        // const users = this.state.dataset.users
        var user_x_mappings = {}
        Object.keys(this.users).map( ( user_id, index ) => ( user_x_mappings[user_id] = index ) ) // {'user_id_1': 1,'user_id_2': 2,..., } for victory x values, consistent across sessions if different sets of users

        var stars = [] // stars[session][user] = count
        // let session_list = this.state.dataset.session_list
        for (let i = 0; i < this.session_list.length; i++) {
          let session_id = this.session_list[i] // scales better
          stars.push([]) // add a new session to the array
          Object.values(this.users).forEach( (user) => {
            let user_session_data_count = Object.entries(user.getData('stars', session_id)).length // Obj version
            // let user_session_data_count = user.getData('stars', session_id).length // Array version only
            stars[i].push( ( { x: user_x_mappings[user._id], y: user_session_data_count } ) )
            // map count to correct user x value
          })
        }
        // console.log(`stars inside getStars() = ${stars}`);
        // update state if this is good
        return stars
      },

      getTags() {
        // map users to x values
        // may be okay to add more than { x, y } ifso it would be useful to have {x, y, user_id, session_id, data: { n-objects } } but TBD if Victory is okay with this
        // const users = this.state.dataset.users
        var user_x_mappings = {}
        Object.keys(this.users).map( ( user_id, index ) => ( user_x_mappings[user_id] = index ) ) // {'user_id_1': 1,'user_id_2': 2,..., } for victory x values, consistent across sessions if different sets of users

        var tags = [] // tags[session][user] = count
        // let session_list = this.state.dataset.session_list
        for (let i = 0; i < this.session_list.length; i++) {
          let session_id = this.session_list[i] // scales better
          tags.push([]) // add a new session to the array
          Object.values(this.users).forEach( (user) => {
            let user_session_data_count = Object.entries(user.getData('tags', session_id)).length // Obj version
            // let user_session_data_count = user.getData('tags', session_id).length // Array version only
            tags[i].push( ( { x: user_x_mappings[user._id], y: user_session_data_count } ) )
            // map count to correct user x value
          })
        }
        // console.log(`tags inside getTags() = ${tags}`);
        // update state if this is good
        return tags
      },

      getQuestions() {
          // map users to x values
        // may be okay to add more than { x, y } ifso it would be useful to have {x, y, user_id, session_id, data: { n-objects } } but TBD if Victory is okay with this

        // const users = this.state.dataset.users
        var user_x_mappings = {}
        Object.keys(this.users).map( ( user_id, index ) => ( user_x_mappings[user_id] = index ) ) // {'user_id_1': 1,'user_id_2': 2,..., } for victory x values, consistent across sessions if different sets of users

        var questions = [] // questions[session][user] = count
        // let session_list = this.state.dataset.session_list
        for (let i = 0; i < this.session_list.length; i++) {
          let session_id = this.session_list[i] // scales better
          questions.push([]) // add a new session to the array
          Object.values(this.users).forEach( (user) => {
            let user_session_data_count = Object.entries(user.getData('questions', session_id)).length // Obj version
            // let user_session_data_count = user.getData('questions', session_id).length // Array version only
            questions[i].push( ( { x: user_x_mappings[user._id], y: user_session_data_count } ) )
            // map count to correct user x value
          })
        }
        // console.log(`questions inside getQuestions() = ${questions}`);
        // update state if this is good
        return questions
      }
    };

    // get parent object, iterate through its list to get() children by their id and save those objects to a new property
    await getDataset(this.props.dataset_id, true).then( (dataset) => {
      // var dataset = dataset;
      dataset.sessions = {}; // add sessions property to dataset object for k,v pairs of session_id: session objects

      // each of the following nested loops follow the same pattern: iterate through its relevant xyz_list(s)
      // sessions
      dataset.session_list.forEach(session_id => { // new
        getSession(session_id, true).then((session) => {
          session.presentations = {}; // add presentations property to session object for k,v pairs of presentation_id: presentation objects

          // presentations
          session.presentation_list.forEach(presentation_id => {
            getPresentation(presentation_id, true).then((presentation) => {
              presentation.questions = {}; // add questions property to presentation object for k,v pairs of question_id: question objects

              // assign teams
              // no restriction that teams will be the same across presentations, use presentation_id for team key
              teams[presentation._id] = presentation.presenter_list; // array of user_ids

              // questions
              presentation.question_list.forEach(question_id => {
                getQuestion(question_id, true).then((question) => {
                  question.responses = {}; // add responses property to question object for k,v pairs of response_id: response objects

                  // responses
                  question.response_list.forEach(response_id => {
                    getResponse(response_id, true).then((response) => {
                      // add properties for k,v pairs: upvotes, reacts, stars, and tags
                      response.upvotes = {};
                      response.reacts = {};
                      response.stars = {};
                      response.tags = {};

                      // to-do: get user for each of these (listener_id)?
                      // upvote, react, star, tag objects k,v pairs to the properties added above
                      // upvotes - not used?
                      response.upvote_list.forEach(upvote_id => {
                        getUpvote(upvote_id, true).then((upvote) => {
                          upvote.session_id = session_id; // add session_id for filtering
                          response.upvotes[upvote_id] = upvote; // add to tree
                          upvotes[upvote._id] = upvote; // aggregate all upvotes in dataset, maybe also add a session tag?
                        });
                      });

                      // reacts are emojis
                      response.react_list.forEach(react_id => {
                        getReact(react_id, true).then((react) => {
                          react.session_id = session_id; // add session_id for filtering
                          reacts[react._id] = react;
                          response.reacts[react_id] = react;
                        });
                      });

                      // stars
                      response.star_list.forEach(star_id => {
                        getStar(star_id, true).then((star) => {
                          star.session_id = session_id; // add session_id for filtering
                          stars[star._id] = star;
                          response.stars[star_id] = star;
                        });
                      });

                      // tags
                      response.tag_list.forEach(tag_id => {
                        getTag(tag_id, true).then((tag) => {
                          tag.session_id = session_id; // add session_id for filtering
                          tags[tag._id] = tag;
                          response.tags[tag_id] = tag;
                        });
                      });
                    response.session_id = session_id; // add session_id for filtering
                    responses[response._id] = response;
                    question.responses[response._id] = response; // save updated child to its parent
                    });
                  });
                question.session_id = session_id; // add session_id for filtering
                questions[question._id] = question;
                presentation.questions[question._id] = question;
                });
              });
            session.presentations[presentation._id] = presentation;
            });
          });
          dataset.sessions[session_id] = session;
        });
      });

      /* can move these out of dataset if desirable */
      dataset.upvotes = upvotes;
      dataset.reacts = reacts;
      dataset.stars = stars;
      dataset.tags = tags;
      dataset.responses = responses;
      dataset.questions = questions;
      dataset.users = users;
      dataset.teams = teams;
      dataset = { ...dataset, ...helpers }

      /* save/update dataset object tree to state */
      this.setState(prevState => ( {...prevState.dataset, dataset   } ) )
      return dataset;
    })
    // return dataset; // this is a promise; can return if necessary but this function is void because setState above
    return this.state.dataset;
  }

  async setUsers() { // async to enable await keyword
    /*
      room for improvement, consolidation
      loop through questions, reacts, stars, tags, responses, upvotes, teams
      if user_id key exists: add that object there, else create the key
    */
    // by listener_id - upvotes, reacts, stars, tags, responses
    var {dataset} = this.state
    var {users} = this.state.dataset
    // let { questions, upvotes, reacts, stars, tags, responses } = this.state.dataset; // change references to dataset.x,y,z

    // main difference in the following blocks is the dataset.DATATYPE in for... of and the datatype's property key for assignment (users[].DATATYPES)
    // also, listener_id and presenter_id roughly, equivalently refer to the user responsible for the object's creation
    /* upvotes */
    for (let datatype of Object.values(dataset.upvotes)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, listener_id } = datatype; // destructures _id of datatype object, listener_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(users).includes(listener_id)) { users[listener_id] = await this.createUserDataProfile(listener_id) };
      users[listener_id].upvotes[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* reacts */
    // iterates through reacts and stores each in the user object who created it
    for (let datatype of Object.values(dataset.reacts)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, listener_id } = datatype; // destructures _id of datatype object, listener_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(users).includes(listener_id)) { users[listener_id] = await this.createUserDataProfile(listener_id) };
      users[listener_id].reacts[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* stars - presenter_id not listener_id? ensure presenter_id is the 'responsible party' for making a star */
    for (let datatype of Object.values(dataset.stars)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, presenter_id } = datatype; // destructures _id of datatype object, presenter_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(users).includes(presenter_id)) { users[presenter_id] = await this.createUserDataProfile(presenter_id) };
      users[presenter_id].stars[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* tags - disabled for debug - unclear who's responsible for a tag (presenter_id?) */
    for (let datatype of Object.values(dataset.tags)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, presenter_id } = datatype; // destructures _id of datatype object, listener_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(users).includes(presenter_id)) { users[presenter_id] = await this.createUserDataProfile(presenter_id) };
      users[presenter_id].tags[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* responses */
    for (let datatype of Object.values(dataset.responses)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, listener_id } = datatype; // destructures _id of datatype object, listener_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(users).includes(listener_id)) { users[listener_id] = await this.createUserDataProfile(listener_id) };
      users[listener_id].responses[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* questions */
    for (let datatype of Object.values(dataset.questions)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, presenter_id } = datatype; // destructures _id of datatype object, presenter_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(users).includes(presenter_id)) { users[presenter_id] = await this.createUserDataProfile(presenter_id) };
      users[presenter_id].questions[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    // update state after populating user objects with datatypes
    this.setState(prevState => ( {
      ...prevState,
      dataset: {
        ...prevState.dataset,
        users: users,
      }, // old dataset: changed dataset assignment
    } ) );
  }

  // tbd
  // async setTeams() {
  //   /*
  //     iterate over presentations, pull presenter_list
  //   */
  //   let { dataset } = this.state;
  // }

  // initialize a "profile" if one doesn't already exist in dataset.users for some user
  async createUserDataProfile(user_id) { // async because getUser() returns a promise
    let user_profile_template = await getUser(user_id).then( user => {
      // return the object to assign to user_profile_template
      return ( ( { ...all } ) => ( {
        ...all,
        upvotes: {},
        reacts: {},
        stars: {},
        tags: {},
        responses: {},
        questions: {},
        teams: {},
        // define users helper methods
        getData(datatype, session_id) { // both parameters should be strings matching a datatype (reacts, responses, upvotes, etc.)
          // return object
          let data_obj = {}
          Object.entries(this[datatype]).forEach( (data, index) => { // index may be used for mapping later
              if (data[1].session_id === session_id) { // only match session_ids RHS is the parameter
                  // do something here
                  data_obj[data[0]] = data[1] // add this {k:v}
              }
          })
          return data_obj
          // Same as above but returns as an array of datatype objects e.g. [ { 'react_id': { /* react_object */ }, ]
          // var data_array = []
          // Object.entries(this[datatype]).forEach( (data, index) => {
          //     if (data[1].session_id === key) { // only match session_ids
          //         data_array.push( ( { [data[0]]: data[1] } ) )
          //     }
          // } )
          // return data_array;
      },
      } ) )( user );
    } );
    return user_profile_template; // return destructured user object with additional properties to caller
  }

// outdated
  // setSessionQuestionsAndSessionList() {
  //   let sessionQuestions = {};
  //   // iterate over sessions
  //   Object.values(this.state.dataset.sessions).forEach(session => {
  //     if (!this.state.sessionList.includes(session.title)) {
  //       this.setState(prevState => ( { sessionList: [ ...prevState.sessionList, session.title] } ) )
  //     }; // if this session isn't in the sessionList, add it this.state.sessionList.push(session_id);
  //     sessionQuestions[session._id] = 0;
  //     // iterate over presentations
  //     Object.values(session.presentations).forEach(presentation => {
  //       sessionQuestions[session._id] += presentation.question_list.length;
  //       // for ([key, value] of Object.entries(presentation.questions)) {
  //       //   // k,v things
  //       // }
  //     } )
  //   } );

  //   this.setState(() => ({ sessionQuestionsDict: sessionQuestions }));
  // }

  // placeholder?
  // byUser(user_id, data_type) {
  //   responses (text), emojis, stars, tags, presentation
  //   if listener_id === user_id
  // }

  // WIP
  // byTeam(datatype, team_id) {
    // teams is an object
    // for this.dataset.teams
    //  if key == team_id
    //    for each (user)
    //      get the thing
  //   const {teams, users} = this.state.dataset;
  //   teams[team_id].values( ( user_id ) => {
  //   } )
  //   return teams
  // }

  /* moved getters into dataset to be used as helper functions passed to graphs */

  render() {
    return (
      <><FlatList
        data={this.state.graphList}
        extraData={this.state.graphList}
        scrollEnabled={true}
        keyExtractor={(item) => item[item.length - 1] } // key is the last element of item (a graph[] in graphList[])
        renderItem={({ item }) => (
          <Graph item={item} graphList={this.state.graphList} sessionList={this.state.sessionList} sessionQuestionsDict={this.state.sessionQuestionsDict} dataset = {this.state.dataset} graphData={this.state.dataset.getReacts()} />
        )} />
      </>
    )
  }
}

const styles = StyleSheet.create({});
