// WIP - Not used yet
import {getSession} from '../custom-modules/backendAPI';

// intended usage
// maybe dataset.getTeamData();
// dataset.getTextResponseData().fromTeam();
// dataset.getEmojiResponseData().fromIndividual();
// dataset.sessions["session_id"].presentations["presentation_id"].questions["question_id"].responses["response_id"].user_id
// dataset.sessions["session_id"].presentations["presentation_id"].listeners["user_id"] (or .user_id) responders?
// dataset.sessions["session_id"].presentations["presentation_id"].presenters["user_id"] (or .user_id) team?
// graphList = ["questionNum", "total", "from team", "unique_id_1"], so maybe helpers should take props (or state, depending where this goes), and return x,y pairs after === with these

// for reference

// let dataset = {
//     dataset: {}, // dataset object, nest for legibility
//     session_list: [], // array of session_ids
//     sessions: {
//         "session_id": {
//             presentation_list: [ // array of string ids
//                 "presentation_id1",
//                 "presentation_id2",
//             ],
//             presentations: {
//                 "presentation_id": { // each id from presentation_list, RHS presentation object?
//                     // presentations have questions, listeners, and presenters
//                     question_list: [ // array of question_ids
//                         "question_id1",
//                         "question_id2",
//                     ],
//                     questions: { // for each question_id in question_list
//                         "question_id": { // QUESTION OBJECT
//                             response_list: [ // array of response id strings
//                                 "response_id1",
//                                 "response_id2",
//                             ],
//                             responses: { // consider moving responses toward root, or making an all_responses that points to each of these for every question?
//                                 // for each response in response_list
//                                 "response_id": { // RESPONSE OBJECT
//                                     // responses have reacts, stars, and tags
//                                     // responses also have an upvote_list (not specified in project reqs, maybe stretch goal?)
//                                     // do need to know which user is responsible for each of these, so get()
//                                     react_list: [ // array of react[ion] id strings
//                                         "reaction_id1",
//                                         "reaction_id2",
//                                     ],
//                                     reactions: { // for each reaction_id
//                                         "reaction_id": {
//                                             // REACT[ION] OBJECT
//                                             // mostly care about the listener_id (who made this reaction)?
//                                         },
//                                     },
//                                     star_list: [ // array of star id strings
//                                         "star_id1",
//                                         "star_id2",
//                                     ],
//                                     stars: { // for each star_id
//                                         "star_id": {
//                                             // STAR OBJECT
//                                             // mostly care about who made this star
//                                         },
//                                     },
//                                     tag_list: [], // array of tag id strings, same as above but tags
//                                     tags: {
//                                         "tag_id": { // for each tag_id
//                                             // TAG OBJECT
//                                             // not sure what tag data we're interested in - how many tags? who made the tag (presenters make tags?)
//                                         },
//                                     },
//                                 },
//                             },
//                         },
//                     },
//                     listener_list: [ // array of ids of users who replied to questions?
//                         "listener_id1",
//                         "listener_id2",
//                     ],
//                     listeners: { // for each listener_id in listener_list
//                         "listener_id": {
//                             // LISTENER OBJECT (USER OBJECT)
//                         },
//                     },
//                     // exists according to schema
//                     presenter_list: [ // array of ids of users (team members?)
//                     ],
//                     // team members? consider moving listeners, presenters to root. this approach won't scale well, duplicates. or central list of objects already retrieved with getters and check against that list before performing any get()
//                     presenters: { // consider renaming to team members if correct
//                         "presenter_id" : {
//                             // USER OBJECT
//                         }
//                     },

//                     // note that responses have presentation FK, but there isn't a response_list (could create one if that's useful?)
//                 },
//             },
//         },
//     },

//     /*
//         # of questions asked
//         # of text replies [to a question]
//         # of emoji reactions [to a question's reply]
//         # of star reactions [to a question's reply]
//         # of tags reactions [to a question's reply] (?)

//         return y = #

//         during each session or total?
//         can filter by person
//         can filter by team
//     */

//     getQuestionsBySession() {
//         // ex: 45 questions were asked in session 1
//         // return those question objects?
//         // i don't think there's any difference between 'by team' and 'by presenter' unless schema is missing information (questions have presenter_id)
//     },

//     /* maybe
//     whoisTeam(params) { // placeholder name, will change if context changes; params TBD, maybe empty
//         // to be confirmed - get presenter_list for a presentation, the ids it contains are the team members?
//         // should return either presenter_list or aggregate some data based on these users
//      },
//     addSession(session_id, getSession) {
//         let session = getSession(session_id, true);
//         session.then((s) => {
//             this.sessions[s._id] = s;
//         });
//     },
//     keys() {
//         return Object.keys(this);
//     },
//     values() {
//         return Object.values(this);
//     },
//     */

//     // also maybe
//     iterateAndGet(params) {
//         /* destructuring syntax reminder:
//             let destructuredObject = ( () => ( { only, these, properties } ) )(sourceObject);

//             need to wrap key assignment statement in ()
//             don't need to specify LHS of arrow - it can be empty ()
//             RHS needs to be wrapped in its own ( { } )
//             object to be destructured needs its own ()
//         */
//         // const dataset =
//         getDataset(dataset_id, true).then(dataset => { // might need to .then() if this assigns the promise instead of the dataset object
//             this.dataset[dataset._id] = dataset; // for now, save entire object but not like this?

//             // can be moved to a function for reuse once we know which properties of each object we actually care about
//             this.dataset.sessions[dataset._id] = { session_list: dataset.session_list };
//             this.setState({dataset: {_id, }});
//         });
//     },
// };
// let upvotes = {
//     "upvote_id": {
//         _id,
//         listener_id,
//         response_id,
//     },
//     "upvote_id2": {
//         _id,
//         listener_id,
//         response_id,
//     },
// }
// // emojis
// let reacts = {
//     "react_id": {
//         _id,
//         listener_id,
//         response_id,
//         react_code,
//     },
//     "react_id2": {
//         _id,
//         listener_id,
//         response_id,
//         react_code,
//     }
// }
// let stars = {
//     "star_id": {
//         _id,
//         presenter_id,
//         response_id,
//         presentation_id,
//         text,
//     },
//     "star_id2": {
//         _id,
//         presenter_id,
//         response_id,
//         presentation_id,
//         text,
//     }
// }
// let tags = {
//     "tag_id": {
//         _id,
//         presenter_id,
//         response_id,
//         presentation_id,
//         text,
//     }
// }
// let responses = {
//     "response_id": {
//         _id,
//         listener_id,
//         text,
//         /* less important? */
//         question_id,
//         presentation_id,
//         upvote_list,
//         react_list,
//         star_list,
//         tag_list,
//         publish_time,
//         instructor_bookmark,
//         instructor_hidden,
//         instructor_comment,
//         /* added */
//         upvotes,
//         reacts,
//         stars,
//         tags,
//         /* want to add? */
//         session_id,
//     },
//     "response_id2": {
//         _id,
//         listener_id,
//         text,
//         /* less important? */
//         question_id,
//         presentation_id,
//         upvote_list,
//         react_list,
//         star_list,
//         tag_list,
//         publish_time,
//         instructor_bookmark,
//         instructor_hidden,
//         instructor_comment,
//         /* added */
//         upvotes,
//         reacts,
//         stars,
//         tags,
//         /* want to add? */
//         session_id,
//     }
// }

// let users = {
//     user1: {
//         text_reply_count,
//         emoji_count,
//         star_count,
//         tag_count,
//         questions_asked_count, // all team members will share the same count
//         teams: { /* this could be any number of teams */},
//     }

// }

// let teams = { // each session will have some number of teams, they cannot persist across sessions (?) unless, perhaps, we compare team(session_i) === team(session_j)? but then must handle edge cases such as user_1 was absent or user_2 joined a different team for some other session but the other 5 members remained the same. might require updating schema?
//     team1: {
//         users: { /* this could be any number of users */},
//         /* want to add? */
//         presentation_id, // or presentation object?

//     }
// }
