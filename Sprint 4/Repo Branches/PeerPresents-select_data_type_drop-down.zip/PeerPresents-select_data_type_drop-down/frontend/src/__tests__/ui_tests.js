import * as React from 'react';
import TestRenderer from 'react-test-renderer';
import { fireEvent, queryByPlaceholderText, getByText,
    getAllByText, render } from '@testing-library/react-native';

import CommentAdd from '../components/CommentAdd'

test('Change comment text', () => {
    // const { queryByPlaceholderText, getByText } = render(
    //   <CommentAdd
    //     listener_id={"abc"}
    //     question_id={"bcd"} 
    //     presentation_id={"cde"}
    //     update_callback={null}
    //   />
    // );

    // const commentAdd = render(
    //   <CommentAdd
    //     listener_id={"abc"}
    //     question_id={"bcd"} 
    //     presentation_id={"cde"}
    //     update_callback={null}
    //   />
    // );

    // const testRenderer = TestRenderer.create(
    //   <CommentAdd listener_id={"abcde"} question_id={"bcdef"}
    //               presentation_id={"cdefg"} update_callback={null}/>);
    // const testInstance = testRenderer.root;
  
    // fireEvent.changeText(
    //     queryByPlaceholderText(text='Add comment...'),
    //     'bread'
    // );
    // fireEvent.press(getByText('Submit'));
  
    const mock = jest.fn(() => testInstance.props.update_callback);

    expect(mock()).toBe(null);

    expect(mock).toHaveBeenCalled();

    // const breadElements = getByText('bread');
    // console.log(breadElements);
    // expect(breadElements).toHaveLength(1);
});