const {connectToDB, disconnectFromDB, createDB, clearDB} = require('../app/managers/mongodbManager');

    

/*connectToDB()
.then(() => {
    clearDB()
    .then((res) => {
        createDB()
    }).catch((err) => {
        console.error(err);
    })
}*/

clearDB()
.then((res) => {
    createDB()
    .then((res) => {
        disconnectFromDB()
    }).catch((err) => {
        console.error(err);
        disconnectFromDB()
    })
}).catch((err) => {
    console.error(err);
    disconnectFromDB()
})