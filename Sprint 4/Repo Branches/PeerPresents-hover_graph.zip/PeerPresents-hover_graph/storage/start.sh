#!/usr/bin/sh
forever start --uid "storage" -a index.js > service.log 1>&1 &
