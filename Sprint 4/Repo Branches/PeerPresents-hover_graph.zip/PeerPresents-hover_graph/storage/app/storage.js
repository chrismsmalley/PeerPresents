const http = require('http'),
      Koa = require('koa'),
      cors = require('koa2-cors'),
      jwt = require('koa-jwt'),
      config = require('config'),
      api_conf = require('../config/api_conf.js'),
      err = require('./helpers/error'),
      {routes, allowedMethods} = require('./routes')
      app = new Koa();

app.use(err);
app.use(cors());
app.use(jwt({secret: api_conf.storage.secret}).unless({path: [/^\/login/]}));
app.use(routes());
app.use(allowedMethods());

const server = http.createServer(app.callback()).listen(config.server.port, function (){
    console.log('%s listing at port %d', config.app.name, config.server.port);
})

module.exports = {
    closeServer() {
        server.close()
    }
}
