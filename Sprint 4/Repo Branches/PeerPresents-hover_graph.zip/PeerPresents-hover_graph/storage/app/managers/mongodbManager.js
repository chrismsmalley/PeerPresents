"use strict";

const assert = require('assert');
const db_conf = require('../../config/ppdb_conf.js');
const ObjectID = require('mongodb').ObjectID;
const MongoClient = require('mongodb').MongoClient;
const user = encodeURIComponent(db_conf.mongo.user);
const pwd = encodeURIComponent(db_conf.mongo.pwd);
const authMechanism = 'DEFAULT';
const url = `mongodb://${user}:${pwd}@${db_conf.mongo.ip}:${db_conf.mongo.port}/${db_conf.mongo.name}?authMechanism=${authMechanism}`;

const options = { useUnifiedTopology: true };
const {
    UserSchema,
    CourseSchema,
    SessionSchema,
    PresentationSchema,
    QuestionSchema,
    ResponseSchema,
    DatasetSchema,
    GraphSchema,
    UpvoteSchema,
    ReactSchema,
    StarSchema,
    TagSchema
} = require('../schema/data_models.js')

// Create a new MongoDB client instance
const db_handle = new MongoClient(url, options);
db_handle.connect((err) => {
    assert.equal(null, err);
    console.log("Connection to database successful");

});

// enum for collection names
const Collections = Object.freeze({
    USER:         "user",
    QUESTION:     "question",
    RESPONSE:     "response",
    DATASET:      "dataset",
    GRAPH:        "graph",
    COURSE:       "course",
    SESSION:      "session",
    PRESENTATION: "presentation",
    UPVOTE:       "upvote",
    REACT:        "react",
    STAR:         "star",
    TAG:          "tag"
});

// enum for schema definitions
const Schemas = Object.freeze({
    USER:           UserSchema, 
    QUESTION:       QuestionSchema,
    RESPONSE:       ResponseSchema, 
    DATASET:        DatasetSchema, 
    GRAPH:          GraphSchema, 
    COURSE:         CourseSchema, 
    SESSION:        SessionSchema, 
    PRESENTATION:   PresentationSchema,
    UPVOTE:         UpvoteSchema,
    REACT:          ReactSchema,
    STAR:           StarSchema,
    TAG:            TagSchema
});

async function connectToDB() {
    try {
        db_handle.connect((err) => {
            assert.equal(null, err);
            console.log("Connection to database successful");
        });
        //const res = await client.connect();
        //db_handle = res;
    } catch (e) {
        console.error(e);
        return e;
    }
}

async function disconnectFromDB() {
    try {
        await db_handle.close();
        //const res = await db_handle.close();
        //db_handle = null;
    } catch (e) {
        console.error(e);
        return e;
    }
}

/* Takes a collection name (string) and model (json).
   Inserts the model into the collection
*/
async function createEntity(_collection, _model){
    try {
        //_model = JSON.parse(_model)
        // validate collection name
        var foundKey = undefined
        for (let [key, value] of Object.entries(Collections)) {
            if (_collection == value) {
                foundKey = key
            }
        }
        
        if (foundKey === undefined) { // reject
            throw new Error(`invalid collection name: ${_collection}`);
        }

        // validate model
        const {error, value} = Schemas[foundKey].validate(_model, {presence: 'required'})
        if (error != undefined) { // reject
            console.error(`createEntity error: ${error}`);
            throw new Error("invalid model datatype");
        }
        
        // check database connection
        if (db_handle === null) {
            throw new Error("Not connected to the database");
        }

        // generate model _id
        _model._id = new ObjectID();

        // get collection
        var dbo = db_handle.db(db_conf.name);
        const col = dbo.collection(_collection);
        
        // insert model
        const res = await col.insertOne(_model);
        const id = res.ops[0]._id;

        return String(id);
        
    } catch (e) {
        console.error(e);
        return e;
    }
}

/* Takes a collection name (string) and id (string).
   Returns the document if found.
*/
async function readEntity(_collection, _id){
    try {
        _id = ObjectID(_id);

        // validate collection name
        var found = Object.values(Collections).find(value => {return _collection == value});
        if (found === undefined) {
            throw new Error("invalid collection name");
        }

        // check database connection
        if (db_handle === null) {
            throw new Error("Not connected to the database");
        }
        
        // get collection
        var dbo = db_handle.db(db_conf.name);
        const col = dbo.collection(_collection);

        // find model by id
        const doc = await col.findOne({"_id": {$eq: _id}});;
        let ret;
        if (doc === null) {
            ret = 0; // not found
        } else {
            ret = doc;
        }
        
        return ret;
    } catch (e) {
        console.error(e);
        return e;
    }
}

/* Takes a collection name (string) and email (string).
   Returns the document if found.
*/
async function readEntityByEmail(_collection, email){
    try {
        // check database connection
        if (db_handle === null) {
            throw new Error("Not connected to the database");
        }
        
        // get collection
        var dbo = db_handle.db(db_conf.name);
        const col = dbo.collection('user');

        // find model by id
        const doc = await col.findOne({"email": {$eq: email}});
        let ret;
        if (doc === null) {
            ret = 0; // not found
        } else {
            ret = doc;
        }
        return ret;
    } catch (e) {
        console.error(e);
        return e;
    }
}

/* Takes a collection name (string), id (string), and model (json).
   Updates the document if found.
*/
async function updateEntity(_collection, _id, _model){
    try {
        // validate collection name
        var foundKey = undefined
        for (let [key, value] of Object.entries(Collections)) {
            if (_collection == value) {
                foundKey = key
            }
        }
        
        if (foundKey === undefined) { // reject
            throw new Error(`invalid collection name: ${_collection}`);
        }

        // validate model
        const {error, value} = Schemas[foundKey].validate(_model, {presense: 'optional'})
        if (error != undefined) { // reject
            console.error(`updateEntity error: ${error}`);
            throw new Error("invalid model datatype");
        }

        var ops = {$set: _model}
    
        if (db_handle === null) {
            throw new Error("Not connected to the database");
        }
        
        // set _id
        _model._id = ObjectID(_id);

        // get collection
        var dbo = db_handle.db(db_conf.name);
        const col = dbo.collection(_collection);
        
        // update model
        const res = await col.updateOne({"_id": _model._id}, ops);
        const count = res.modifiedCount; // number of docs updated
       
        _model._id = String(_model._id)

        return count;
    } catch (e) {
        console.error(e);
        return e;
    }
}

/* Takes a collection name (string) and id (string).
   Deletes the document if found.
*/
async function deleteEntity(_collection, _id){
    try {
        _id = ObjectID(_id);
        // validate collection name
        var found = Object.values(Collections).find(value => {return _collection == value});
        if (found === undefined) { // reject
            throw new Error("invalid collection name");
        }

        if (db_handle === null) {
            throw new Error("Not connected to the database");
        }
        // get collection
        var dbo = db_handle.db(db_conf.name);
        const col = dbo.collection(_collection);

        // delete model by id
        const res = await col.deleteOne({"_id": _id});
        let count = res.deletedCount; // number of docs deleted

        return count;
    } catch (e) {
        console.error(e);
        return e;
    }
}

/* Takes a collection name (string).
   Returns IDs for all documents found in collection.
*/
async function listEntities(_collection){
    try {
        // validate collection name
        var found = Object.values(Collections).find(value => {return _collection == value});
        if (found === undefined) {
            throw new Error("invalid collection name");
        }

        // check database connection
        if (db_handle === null) {
            throw new Error("Not connected to the database");
        }
        
        // get collection
        var dbo = db_handle.db(db_conf.name);
        const col = dbo.collection(_collection);

        // find model by id
        const cursor = col.find({}, {"_id": 1});
        let doc;
        let ret = new Array();
        while((doc = await cursor.next())){
            ret.push(doc._id);
        }
        
        return ret;
    } catch (e) {
        console.error(e);
        return e;
    }
}

/* Creates the database named in db_conf, if not already created.
*/
async function createDB(){
    try {
        console.log(url);
        console.log(db_conf);

        if (db_handle === null) {
            throw new Error("not connected to the database");
        }

        const dbo = db_handle.db(db_conf.name);

        // create collections
        await Promise.all([
            dbo.createCollection(Collections.USER),
            dbo.createCollection(Collections.QUESTION),
            dbo.createCollection(Collections.RESPONSE),
            dbo.createCollection(Collections.DATASET),
            dbo.createCollection(Collections.GRAPH),
            dbo.createCollection(Collections.COURSE),
            dbo.createCollection(Collections.SESSION),
            dbo.createCollection(Collections.PRESENTATION),
            dbo.createCollection(Collections.UPVOTE),
            dbo.createCollection(Collections.REACT),
            dbo.createCollection(Collections.STAR),
            dbo.createCollection(Collections.TAG)
        ]);

        return;
    } catch (e) {
        console.error(e);
        return e;
    }
}

/* Drops all collections in the database named in db_conf.
*/
async function clearDB(){
    try {
        console.log(url);
        console.log(db_conf);

        if (db_handle === null) {
            throw new Error("not connected to the database");
        }

        const dbo = db_handle.db(db_conf.name);

        // create collections
        await Promise.all([
            dbo.dropCollection(Collections.USER),
            dbo.dropCollection(Collections.QUESTION),
            dbo.dropCollection(Collections.RESPONSE),
            dbo.dropCollection(Collections.DATASET),
            dbo.dropCollection(Collections.GRAPH),
            dbo.dropCollection(Collections.COURSE),
            dbo.dropCollection(Collections.SESSION),
            dbo.dropCollection(Collections.PRESENTATION),
            dbo.dropCollection(Collections.UPVOTE),
            dbo.dropCollection(Collections.REACT),
            dbo.dropCollection(Collections.STAR),
            dbo.dropCollection(Collections.TAG)
        ]);

        return;
    } catch (e) {
        console.error(e);
        return e;
    }
}

module.exports = {
    connectToDB,
    disconnectFromDB,
    createDB,
    clearDB,
    createEntity,
    readEntity,
    readEntityByEmail,
    updateEntity,
    deleteEntity,
    listEntities
};
