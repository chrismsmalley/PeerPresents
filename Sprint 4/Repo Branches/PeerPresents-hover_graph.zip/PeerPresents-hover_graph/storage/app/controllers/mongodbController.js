const { createEntity, readEntity, readEntityByEmail, updateEntity, deleteEntity, listEntities } = require('../managers/mongodbManager');

/**
* @example curl -XGET "http://localhost:3030/users"
*/
async function listItems (ctx, next) {
    try{
        const res = await listEntities(ctx.params.collection);
        if (res instanceof Error) {
            throw new Error(res);
        }
        let ret = new Array();
        res.forEach(element => {
            ret.push(`/${ctx.params.collection}/${element}`)
        });
        ctx.body = {
            message: '',
            result: ret
        };
        ctx.status = 200;
    } catch (e) {
        ctx.body = {};
        ctx.status = 500;
        console.error(e);
    }

    await next();
}

/**
 * @example curl -XPOST "http://localhost:3030/users" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createItem (ctx, next) {
    try {
        let body = ctx.request.body;
        if (!body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let model = JSON.parse(body.model);
        //let model = body.model;
        const res = await createEntity(ctx.params.collection, model);
        if (res instanceof Error) {
            throw new Error(res);
        }
        ctx.body = {
            message: "Created new resource",
            result: {
                uri: `/${ctx.params.collection}/${res}`,
                id: res
            }
        };
        ctx.status = 201;
    } catch (e) {
        ctx.body = {
            message: "error",
            result: {}
        };
        ctx.status = 500;
        console.error(e)
    }
    
    await next();
}

/**
 * @example curl -XGET "http://localhost:3030/users/1"
 */
async function readItem (ctx, next) {
    try {
        const res = await readEntity(ctx.params.collection, ctx.params.id);
        if (res instanceof Error) {
            throw new Error(res);
        }
        if (res == 0 ) { // nothing found
            ctx.body = {
                message: "Resource not found",
                result: {
                    uri: `/${ctx.params.collection}/${ctx.params.id}`,
                    id: ctx.params.id
                }
            };
            ctx.status = 404;
        } else {
            ctx.body = {
                message: '',
                result: res
            };
            ctx.status = 200;
        }
    } catch (e) {
        ctx.body = {
            message: "error",
            result: {}
        };
        ctx.status = 500;
        console.error(e)
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:3030/users/example@example.com"
 */
async function readUserByEmail (ctx, next) {
    try {
        const res = await readEntityByEmail(ctx.params.collection, ctx.params.email);
        if (res instanceof Error) {
            throw new Error(res);
        }
        if (res == 0 ) { // nothing found
            ctx.body = {
                message: "Resource not found",
                result: {
                    uri: `/${ctx.params.collection}/${ctx.params.email}`,
                    email: ctx.params.email
                }
            };
            ctx.status = 404;
        } else {
            ctx.body = {
                message: '',
                result: res
            };
            ctx.status = 200;
        }
    } catch (e) {
        ctx.body = {
            message: "error",
            result: {}
        };
        ctx.status = 500;
        console.error(e)
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:3030/users/3" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateItem (ctx, next) {
    try {
        let body = ctx.request.body;
        if (!body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let model = JSON.parse(body.model);
        const res = await updateEntity(ctx.params.collection, ctx.params.id, model);
        if (res instanceof Error) {
            throw new Error(res);
        }
        if (res == 0 ) { // nothing updated
            ctx.body = {
                message: "Resource not found",
                result: {
                    uri: `/${ctx.params.collection}/${ctx.params.id}`,
                    id: ctx.params.id
                }
            };
            ctx.status = 404;
        } else {
            ctx.status = 204;
        }
    } catch (e) {
        ctx.body = {
            message: "error",
            result: {}
        };
        ctx.status = 500;
        console.error(e)
    }
    await next();
}

/**
 * @example curl -XDELETE "http://localhost:3030/users/3"
 */
async function deleteItem (ctx, next) {
    try {
        const res = await deleteEntity(ctx.params.collection, ctx.params.id);
        if (res instanceof Error) {
            throw new Error(res);
        }
        if (res == 0 ) { // nothing deleted
            ctx.body = {
                message: "Resource not found",
                result: {
                    uri: `/${ctx.params.collection}/${ctx.params.id}`,
                    id: ctx.params.id
                }
            };
            ctx.status = 404;
        } else {
            ctx.status = 204;
        }
    } catch (e) {
        ctx.body = {
            message: "error",
            result: {}
        }
        ctx.status = 500;
        console.error(e)
    }
    
    await next();
}

module.exports = {createItem, readItem, readUserByEmail, updateItem, deleteItem, listItems};
