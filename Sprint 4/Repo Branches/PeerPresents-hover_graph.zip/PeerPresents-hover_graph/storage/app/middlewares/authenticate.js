const jwt = require('njwt');
const api_conf = require('../../config/api_conf.js');

async function authenticate (ctx) {
    try {
        if (ctx.request.body.password === api_conf.storage.key_password) {
            // generate token
            let _token = jwt.create({role: 'admin'}, api_conf.storage.secret);

            // change things like expiration
            _token.setExpiration(); // remove expiration claim
            
            ctx.body = {
                token: _token.compact(),
                message: "successful log in"
            };
            ctx.status = 200;
        } else {
            ctx.status = 401;
            ctx.body = {
                message: "Authentication failed"
            };
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }
    //await next();
    return ctx;
}

module.exports = {
    authenticate
};