const Joi = require('@hapi/joi')

/* Define RegEx for DB primary keys (_id field)
   keys are hexadecimal strings (mongodb.ObjectId)
*/
const IdRegEx = new RegExp('^[0-9a-fA-F]+$')

/* Identity Models */
const UserSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    username: Joi.string()
        .min(1)
        .max(30)
        .required(),
    first_name: Joi.string()
        .alphanum()
        .min(2),
    last_name: Joi.string()
        .alphanum()
        .min(2),
    email: Joi.string()
        .email({minDomainSegments: 2, tlds: {allow: ['com', 'net', 'edu', 'uk', 'org']}}),
    password: Joi.string()
        .min(6)
        .required(),
    consent: Joi.boolean(),
    profile_pic: Joi.string()
        .dataUri()
        .optional(),
    roles: Joi.array()
        .items(Joi.string()
        .required()),
    course_list: Joi.array()
        .items(Joi.string()
        .pattern(IdRegEx)
        .optional()),
    session_list: Joi.array()
        .items(Joi.string()
        .pattern(IdRegEx)),
    presentation_list: Joi.array()
        .items(Joi.string()
        .pattern(IdRegEx)
    ),
});

/* Organization Models */
const CourseSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    title: Joi.string()
        .min(5)
        .max(50),
    code: Joi.string()
        .min(2)
        .max(15),
    color: Joi.string()
        .min(3)
        .max(10),
    semester: Joi.string(),
    instructor_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    student_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    session_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
});
const SessionSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    course_id: Joi.string()
        .pattern(IdRegEx),
    title: Joi.string()
        .min(5)
        .max(30),
    presentation_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    responses_num: Joi.number().default(0).integer().min(0),
    start_datetime: Joi.date(),
    end_datetime: Joi.date(),
    universal_questions_bool: Joi.boolean().default(false),
    universal_questions: Joi.array().items(Joi.string().allow("")),
    presenter_questions_bool: Joi.boolean().default(false),
    presenter_questions_num: Joi.number().default(0).integer().min(0).max(5),
    emojis_feedback: Joi.boolean().default(false),
    star_rating_feedback: Joi.boolean().default(false),
    tags_feedback: Joi.boolean().default(false),
    tags: Joi.object(),
    photo_media: Joi.boolean().default(false),
    qr_code_scan: Joi.boolean().default(false),
    share_contact_info: Joi.boolean().default(false),
});
const PresentationSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    session_id: Joi.string()
        .pattern(IdRegEx),
    title: Joi.string()
        .min(5)
        .max(30),
    presenter_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    listener_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    question_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    instructor_notes: Joi.string().default("")
        .max(2000).allow(""),
});

/* Content Models */
const QuestionSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    presentation_id: Joi.string()
        .pattern(IdRegEx),
    presenter_id: Joi.string()
        .pattern(IdRegEx),
    text: Joi.string()
        .min(1)
        .max(500),
    response_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
});
const ResponseSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    listener_id: Joi.string()
        .pattern(IdRegEx),
    question_id: Joi.string()
        .pattern(IdRegEx),
    presentation_id: Joi.string()
        .pattern(IdRegEx),
    text: Joi.string()
        .min(1)
        .max(500),
    upvote_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    react_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    star_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    tag_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    publish_time: Joi.date(),
    instructor_bookmark: Joi.boolean().default(false),
    instructor_hidden: Joi.boolean().default(false),
    instructor_comment: Joi.string().min(0).max(200).allow(""),
});

/* Dataset Models */
const DatasetSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    title: Joi.string()
        .min(5)
        .max(35),
    session_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    graph_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    instructor_list: Joi.array()
        .items(Joi.string().pattern(IdRegEx)),
    // last_modified
});

/* Graph Models */
const GraphSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    dataset_id: Joi.string()
        .pattern(IdRegEx),
    title_variable: Joi.string()
        .min(5)
        .max(35),
    total_average_variable: Joi.string()
        .min(5)
        .max(15),
    person_team_variable: Joi.string()
        .min(5)
        .max(15),
});

/* Reaction Models */
const UpvoteSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    listener_id: Joi.string()
        .pattern(IdRegEx),
    response_id: Joi.string()
        .pattern(IdRegEx),
});
const ReactSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    listener_id: Joi.string()
        .pattern(IdRegEx),
    response_id: Joi.string()
        .pattern(IdRegEx),
    react_code: Joi.string()
        .alphanum()
        .min(1)
        .max(12)
});
const StarSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    presenter_id: Joi.string()
        .pattern(IdRegEx),
    response_id: Joi.string()
        .pattern(IdRegEx),
    presentation_id: Joi.string()
        .pattern(IdRegEx),
    value: Joi.number()
        .integer()
        .min(0)
        .max(3),
});
const TagSchema = Joi.object({
    _id: Joi.string()
        .pattern(IdRegEx),
    presenter_id: Joi.string()
        .pattern(IdRegEx),
    response_id: Joi.string()
        .pattern(IdRegEx),
    presentation_id: Joi.string()
        .pattern(IdRegEx),
    text: Joi.string()
        .trim(true)
        .alphanum()
        .min(1)
        .max(12),
});

module.exports = {
    UserSchema,
    CourseSchema,
    SessionSchema,
    PresentationSchema,
    QuestionSchema,
    ResponseSchema,
    DatasetSchema,
    GraphSchema,
    UpvoteSchema,
    ReactSchema,
    StarSchema,
    TagSchema
};