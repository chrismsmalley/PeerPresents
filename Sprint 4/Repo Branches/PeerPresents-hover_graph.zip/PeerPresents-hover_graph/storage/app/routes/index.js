const Router = require('koa-router'),
      KoaBody = require('koa-body'),
      {authenticate} = require('../middlewares/authenticate'),
      //{index, readItem, list, createItem, updateItem, removeItem} = require('../controllers/indexController');
      //{ createEntity, updateEntity, deleteEntity } = require('../managers/mongodbManager'),
      {readUserByEmail, createItem, readItem, updateItem, deleteItem, listItems} = require('../controllers/mongodbController');

const router = new Router();

//router.put('/:entity/:id',	KoaBody(), updateItem)

router.post('/login', KoaBody(), authenticate);


router.post('/:collection',    KoaBody(), createItem);
router.get( '/:collection/:id',	           readItem);
router.put( '/:collection/:id', KoaBody(), updateItem);
router.del( '/:collection/:id',	           deleteItem);
router.get( '/:collection',                listItems);
router.get( '/email/:email',              readUserByEmail);


module.exports = {
    routes () { return router.routes() },
    allowedMethods () { return router.allowedMethods() }
};
