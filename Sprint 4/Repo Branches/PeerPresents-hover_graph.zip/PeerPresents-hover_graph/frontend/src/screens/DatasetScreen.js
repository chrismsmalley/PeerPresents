import * as React from "react";
import { StyleSheet, Text, View, ScrollView } from "react-native";
import { Colors } from "../global/Constants";
import window from "../global/Layout";
import SideMenu from "../components/SideMenu";
import MainButton from "../components/MainButton";
import SeparatingLine from "../components/SeparatingLine";
import BackButton from "../components/BackButton";
import Logo from "../components/Logo";
import { Picker } from "@react-native-picker/picker";
import { VictoryBar, VictoryChart, VictoryAxis, VictoryGroup } from "victory";
import SimpleFlatList from "../components/SimpleFlatList";
import GraphsContainer from "../components/GraphsContainer";
import Graph from "../components/Graph";
import { getUser, getCourse, getPresentation, getAllDatasetIDs,
  getDatasetList, getDataset, getSession, getSessionList, getAllSessionIDs, createGraph, getGraph, getGraphList} from '../custom-modules/backendAPI';

export default function DatasetScreen({ route, navigation }) {
  // will get assigned upon page load; currently has dummy variables
 /* const [variables, setVariables] = React.useState({
    titleVariable: "",
    totalAverageVariable: "",
    personTeamVariable: "",
  });*/

  const [dataset, setDataset] = React.useState(route.params.dataset)

  return (
    <View style={styles.screenContainer}>
      <View style={{ flexDirection: "row", flex: 1 }}>
        <SideMenu navigation={navigation} />
        <View style={styles.logoAndScrollContainer}>
          <Logo />
          <View style={styles.upperButtonContainer}>
            <MainButton active={true} text={"Export Data"} square={false} />
          </View>
          <BackButton backTo={"Datasets"} navigation={navigation} />
          <View style={{marginStart: window.window.width / 8}} >
            <SeparatingLine />
          </View>
          <ScrollView style={styles.scrollViewContainer}>
            <Text style={styles.title}>{dataset.title}</Text>
            <View style={styles.session}>
              <View style={styles.sessionContainer}>
                <Text style={styles.sessionTitles}>Sessions in Dataset</Text>
                <Text style={styles.sessionTitles}>Class</Text>
                <Text style={styles.sessionTitles}>End Date</Text>
              </View>
              <SimpleFlatList
                screen={"dataset_sessions"}
                navigation={navigation}
                dataset_id={dataset._id}
                // Pull from data base
              />
            </View>
            <GraphsContainer
              // graphs displayed in this component
              dataset_id={dataset._id}/>
            <View style={styles.lowerButtonContainer}>
              <MainButton
                // trigger event for GraphsContainer to call addGraph()
                onPress={() => {
                  const event = new CustomEvent("addGraphButtonClick");
                  document.dispatchEvent(event);
                 } }
                active={true}
                text={"Add Graph"}
                square={false}>
              </MainButton>
            </View>
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  logoAndScrollContainer: {
    justifyContent: 'center',
  },
  scrollViewContainer: {
    width: window.window.width / 1.5,
    height: window.window.height/1.1,
    marginStart: window.window.width / 6,
    backgroundColor: Colors.backgroundColor,
  },
  upperButtonContainer: {
    alignSelf: "flex-end",
    marginBottom: window.window.height / 20,
  },
  screenContainer: {
    flex: 1,
    flexDirection: "column",

  },
  title: {
    fontSize: window.window.height / 30,
    marginTop: window.window.height / 30,
    marginBottom: 30,
    fontWeight: "bold",
  },
  session: {
    marginTop: 30,
    borderRadius: 30,
    marginBottom: 25,
    backgroundColor: "white",
    width: window.window.width / 1.5,
    height: window.window.height / 3,
  },
  sessionContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginHorizontal: 20,
    marginBottom: 30,
    marginTop: 15,
  },
  sessionTitles: {
    fontWeight: "bold",
    fontSize: 20,
    color: Colors.ppGreyText,
  },
  graphText: {
    fontSize: 15,
    color: Colors.ppGreyText,
    marginTop: 20,
    marginLeft: 30,
  },
  picker: {
    marginTop: 30,
    marginLeft: 30,
    marginRight: 30,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: Colors.ppGreyText,
    fontSize: window.window.height / 50,
    width: window.window.width / 1.6,
    height: window.window.height / 10,
    fontSize: 20,
    fontWeight: "bold",
    color: Colors.ppTextColor,
    paddingLeft: 10,
  },
  pickerItem: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 30,
    color: Colors.ppTextColor,
  },
  graph: {
    marginTop: 30,
    borderRadius: 30,
    marginBottom: 25,
    backgroundColor: "white",
    width: window.window.width / 1.5,
    height: window.window.height / 1.1,
  },
  subPickers: {
    marginVertical: 10,
    marginLeft: 30,
    marginRight: 30,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  subPicker: {
    borderColor: Colors.ppGreyText,
    padding: 10,
    borderWidth: 1,
    borderRadius: 10,
    fontSize: 18,
  },
  lowerButtonContainer: {
    alignSelf: "flex-end",
    marginBottom: window.window.height / 20,
    marginTop: window.window.height / 20,
  },
});
