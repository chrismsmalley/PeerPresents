import * as React from 'react';
import TestRenderer from 'react-test-renderer';
import { render, fireEvent } from '@testing-library/react-native'
import AddEditItem from '../components/AddEditItem';
import AddPhoto from '../components/AddPhoto';
import AddUserIcon from '../components/AddUserIcon';
import CommentAdd from '../components/CommentAdd';
import CourseCard from '../components/CourseCard';
import EditElement from '../components/EditElement';
import MainButton from '../components/MainButton';
import Reaction from '../components/ReactionItem';
import SearchItem from '../components/SearchItem';
import Tag from '../components/Tag';
import UserIcon from '../components/UserIcon';
import Login from '../screens/Login';
import Signup from '../screens/Signup';
// import DashboardTab from '../screens/DashboardTab';
import { Image, Text, TextInput } from 'react-native';
// import { SearchBar } from 'react-native-elements';


/***************** COMPONENTS *****************/

// it(`Renders the AddEditItem component`, () => {
//   const testRenderer = TestRenderer.create(<AddEditItem onPress={null} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.onPress).toBe(null);
// });

it(`Renders the AddPhoto component`, () => {
  const testRenderer = TestRenderer.create(<AddPhoto setProfilePic={null}
    showActionSheetWithOptions={null} />);
  const testInstance = testRenderer.root;

  expect(testInstance.props.setProfilePic).toBe(null);
  expect(testInstance.props.showActionSheetWithOptions).toBe(null);
});

// it(`Renders the AddUserIcon component`, () => {
//   const testRenderer = TestRenderer.create(<AddUserIcon userIconDim={25}
//     onPress={null} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.userIconDim).toBe(25);
//   expect(testInstance.props.onPress).toBe(null);
// });

// it(`Renders the Comment component`, () => {
//   const testRenderer = TestRenderer.create(<Comment commentsScreen={"presenters"}
//   response_id={"abcde"} commentChangedFunc={null} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.commentsScreen).toBe("presenters");
//   expect(testInstance.props.response_id).toBe("abcde");
//   expect(testInstance.props.commentChangedFunc).toBe(null);
// });

// it(`Renders the CommentAdd component`, () => {
//   const testRenderer = TestRenderer.create(<CommentAdd listener_id={"abcde"}
//   question_id={"bcdef"} presentation_id={"cdefg"} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.listener_id).toBe("abcde");
//   expect(testInstance.props.question_id).toBe("bcdef");
//   expect(testInstance.props.presentation_id).toBe("cdefg");
// });

it(`Renders the CourseCard component`, () => {
  const testRenderer = TestRenderer.create(<CourseCard onPress={null}
    plusIcon={true} courseColor={"#aaaaaa"} />);
  const testInstance = testRenderer.root;

  expect(testInstance.props.onPress).toBe(null);
  expect(testInstance.props.plusIcon).toBe(true);
  expect(testInstance.props.courseColor).toBe("#aaaaaa");
});

// it(`Renders the CourseList component`, () => {
//   const testRenderer = TestRenderer.create(<CourseList search={true}
//     onPress={null} myPresentationsTab={false} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.search).toBe(true);
//   expect(testInstance.props.onPress).toBe(null);
//   expect(testInstance.props.myPresentationsTab).toBe(false);
// });

// it(`Renders the CourseMainItem component`, () => {
//   const testRenderer = TestRenderer.create(<CourseMainItem data={{title: "TEST"}}
//   onPress={null} myPresentationsTab={false} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.data.title).toBe("TEST");
//   expect(testInstance.props.onPress).toBe(null);
//   expect(testInstance.props.myPresentationsTab).toBe(false);
// });

// it(`Renders the EditElement component`, () => {
//   const testRenderer = TestRenderer.create(<EditElement text={"TEST"}
//   onPress={null} id={"abcde"} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.text).toBe("TEST");
//   expect(testInstance.props.onPress).toBe(null);
//   expect(testInstance.props.id).toBe("abcde");
// });

it(`Renders the MainButton component`, () => {
  const testRenderer = TestRenderer.create(<MainButton onPress={null}
    children={null} />);
  const testInstance = testRenderer.root;

  expect(testInstance.props.onPress).toBe(null);
  expect(testInstance.props.children).toBe(null);
});

// it(`Renders the MemberList component`, () => {
//   const testRenderer = TestRenderer.create(<MemberList presentation_id={"abcde"}/>);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.presentation_id).toBe("abcde");
// });

// it(`Renders the QuestionItem component`, () => {
//   const testRenderer = TestRenderer.create(<QuestionItem onPress={null}
//     data={{text: "abcde"}} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.onPress).toBe(null);
//   expect(testInstance.props.data.text).toBe("abcde");
// });

it(`Renders the Reaction component`, () => {
  const testRenderer = TestRenderer.create(<ReactionItem react_code={"1"} count={3}
  closeModal={null} reaction_dictionary={[{id: "1", count: 0, users: []}]} />);
  const testInstance = testRenderer.root;

  expect(testInstance.props.react_code).toBe("1");
  expect(testInstance.props.count).toBe(3);
  expect(testInstance.props.closeModal).toBe(null);
  expect(testInstance.props.reaction_dictionary).toStrictEqual([{id: "1",
    count: 0, users: []}]);
});

it(`Renders the SearchItem component`, () => {
  const testRenderer = TestRenderer.create(<SearchItem hasItem={false}
    onPress={null} data={{text: "TEST"}} />);
  const testInstance = testRenderer.root;

  expect(testInstance.props.hasItem).toBe(false);
  expect(testInstance.props.onPress).toBe(null);
  expect(testInstance.props.data.text).toBe("TEST");
});

// it(`Renders the SectionList component`, () => {
//   const testRenderer = TestRenderer.create(<SectionList course={null}
//     onPress={null} data={["abcde"]} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.course).toBe(null);
//   expect(testInstance.props.onPress).toBe(null);
//   expect(testInstance.props.data).toStrictEqual(["abcde"]);
// });

// it(`Renders the SortBar component`, () => {
//   const testRenderer = TestRenderer.create(<SortBar sortFunc={null} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.sortFunc).toBe(null);
// });

// it(`Renders the TabBarIcon component`, () => {
//   const testRenderer = TestRenderer.create(<TabBarIcon focused={false}
//     name={"ios-add"} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.focused).toBe(false);
//   expect(testInstance.props.name).toBe("ios-add");
// });

it(`Renders the Tag component`, () => {
  const testRenderer = TestRenderer.create(<Tag addTag={true} addTagFunc={null}
    updateTag={false} updateTagFunc={null} name={"TEST"} />);
  const testInstance = testRenderer.root;

  expect(testInstance.props.addTag).toBe(true);
  expect(testInstance.props.addTagFunc).toBe(null);
  expect(testInstance.props.updateTag).toBe(false);
  expect(testInstance.props.updateTagFunc).toBe(null);
  expect(testInstance.props.name).toBe("TEST");
});

// it(`Renders the Title component`, () => {
//   const testRenderer = TestRenderer.create(<Title course={null}
//     onPressRight={null} text={"TEST"} />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.props.course).toBe(null);
//   expect(testInstance.props.onPressRight).toBe(null);
//   expect(testInstance.props.text).toBe("TEST");
// });

it(`Renders the UserIcon component`, () => {
  const testRenderer = TestRenderer.create(<UserIcon profile_pic={null}
    membersView={true} onPress={null} />);
  const testInstance = testRenderer.root;

  expect(testInstance.props.profile_pic).toBe(null);
  expect(testInstance.props.membersView).toBe(true);
  expect(testInstance.props.onPress).toBe(null);
});



/***************** SCREENS *****************/

it(`Renders the Login screen`, () => {
  const testRenderer = TestRenderer.create(<Login />);
  const testInstance = testRenderer.root;

  expect(testInstance.findByType(Image).props.style["resizeMode"]).toBe("contain");
  expect(testInstance.findAllByType(Text)[0].props["children"]).toBe("Log in");
  expect(testInstance.findAllByType(Text)[1].props["children"]).toBe("Back");
  
  expect(testInstance.findAllByType(TextInput)[0].props["placeholder"])
  .toBe(" Email address");
  expect(testInstance.findAllByType(TextInput)[1].props["placeholder"])
  .toBe(" Password");
});

// it(`Renders the Signup screen`, () => {
//   const testRenderer = TestRenderer.create(<Signup />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.findAllByType(Text)[0].props["children"]).toBe("Sign up");
//   expect(testInstance.findAllByType(Text)[1].props["children"]).toBe("Back");
  
//   expect(testInstance.findAllByType(TextInput)[0].props["placeholder"])
// .toBe("  First name");
//   expect(testInstance.findAllByType(TextInput)[1].props["placeholder"])
// .toBe("  Last name");
//   expect(testInstance.findAllByType(TextInput)[2].props["placeholder"])
// .toBe("  Email address");
//   expect(testInstance.findAllByType(TextInput)[3].props["placeholder"])
// .toBe("  Password");
//   expect(testInstance.findAllByType(TextInput)[4].props["placeholder"])
// .toBe("  Confirm password");
//   expect(testInstance.findAllByType(TextInput)[5].props["placeholder"])
// .toBe("  Code");
// });

// it(`Renders the DashboardTab screen`, () => {
//   const testRenderer = TestRenderer.create(<DashboardTab />);
//   const testInstance = testRenderer.root;

//   expect(testInstance.findAllByType(Text)[0].props["children"]).toBe("+");
//   expect(testInstance.findByType(SearchBar).props["placeholder"])
// .toBe("Search Course...");
// });