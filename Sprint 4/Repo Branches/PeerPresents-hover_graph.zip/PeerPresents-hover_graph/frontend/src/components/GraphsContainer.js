import React, { Component } from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { Colors } from "../global/Constants";
import window from "../global/Layout";
import Graph from './Graph';
import MainButton from './MainButton';
import { getDataset, getGraph, getPresentation, getSession, getQuestion, getResponse, getUpvote, getReact, getStar, getTag, getUser } from '../custom-modules/backendAPI';
import { FlatList } from 'react-native-gesture-handler';

export default class GraphsContainer extends Component {

  constructor(props) {
    super(props);
    this.state = {
      dataset: {}, // create this once GraphsContainer is mounted
      graphList: [
        // graphList is initially empty, but should be populated with the graphs in dataset.graphList
        // ["questionNum", "total", "from team", "unique_id_1"],
        // ["questionNum", "average", "from person", "unique_id_2"],
        // ["questionNum", "average", "from team", "unique_id_3"],
      ],
      sessionList: [],
      sessionQuestionsDict: {}, // to-do: update
    }
    this.createDatasetTree();
  }

  componentDidMount() {
    // To-Do: addGraph() for each graph in dataset.graphList, also set state.graphList = dataset.graphList and be sure those render on load
    // setGraph() or updateGraph() as well?
    // components under render
    document.addEventListener("addGraphButtonClick", this.addGraph); // runs addGraph() on click event

    // not a permanent solution to Warning: Can't perform a React state update on an unmounted component. This is a no-op, but it indicates a memory leak in your application. To fix, cancel all subscriptions and asynchronous tasks in the componentWillUnmount method.
    // may have to conditionally render?
    setTimeout( () => {
      this.setSessionQuestionsAndSessionList();
      this.setUsers();
    }, 5000);
  }

  // to-do: accept getGraph(graph_id, true), set state with new ["title", "total/average", "person/team"]
  // update id assignment logic if graph deletion is implemented
  addGraph = () => {
    let newGraph = [
      "static graph title",
      "static graph total/average",
      "static graph person/team",
      this.state.graphList.length.toString()] // last value is a key == (graphsList.indexOf(thisGraph) + 1), must be string
    this.setState(prevState => ({
      graphList: [...prevState.graphList, newGraph],
    }));
  }

  // construct a dataset object tree where each object contains its children as objects mapped to their ids as keys
  async createDatasetTree() {
    /* declared separately, then folded into dataset for flexibility */
    let upvotes = {}; // done, not used
    let reacts = {}; // done
    let stars = {}; // done
    let tags = {}; // done
    let responses = {}; // done
    let questions = {}; // done
    let users = {}; // TBD method to populate lowest time complexity, least repeated code - create a user_id key if none exists, then send every type of object to user list?
    let teams = {}; // TBD create by presenter_list

    // get parent object, iterate through its list to get() children by their id and save those objects to a new property
    getDataset(this.props.dataset_id, true).then(dataset => {
      dataset.sessions = {}; // add sessions property to dataset object for k,v pairs of session_id: session objects

      // each of the following nested loops follow the same pattern: iterate through its relevant xyz_list(s)
      // sessions
      dataset.session_list.forEach(session_id => { // new
        getSession(session_id, true).then((session) => {
          session.presentations = {}; // add presentations property to session object for k,v pairs of presentation_id: presentation objects

          // presentations
          session.presentation_list.forEach(presentation_id => {
            getPresentation(presentation_id, true).then((presentation) => {
              presentation.questions = {}; // add questions property to presentation object for k,v pairs of question_id: question objects

              // assign teams
              // no restriction that teams will be the same across presentations, use presentation_id for team key
              teams[presentation._id] = presentation.presenter_list; // array of user_ids

              // questions
              presentation.question_list.forEach(question_id => {
                getQuestion(question_id, true).then((question) => {
                  question.responses = {}; // add responses property to question object for k,v pairs of response_id: response objects

                  // responses
                  question.response_list.forEach(response_id => {
                    getResponse(response_id, true).then((response) => {
                      // add properties for k,v pairs: upvotes, reacts, stars, and tags
                      response.upvotes = {};
                      response.reacts = {};
                      response.stars = {};
                      response.tags = {};

                      // to-do: get user for each of these (listener_id)?
                      // upvote, react, star, tag objects k,v pairs to the properties added above
                      // upvotes - not used?
                      response.upvote_list.forEach(upvote_id => {
                        getUpvote(upvote_id, true).then((upvote) => {
                          upvote.session_id = session_id; // add session_id for filtering
                          response.upvotes[upvote_id] = upvote; // add to tree
                          upvotes[upvote._id] = upvote; // aggregate all upvotes in dataset, maybe also add a session tag?
                        });
                      });

                      // reacts are emojis
                      response.react_list.forEach(react_id => {
                        getReact(react_id, true).then((react) => {
                          react.session_id = session_id; // add session_id for filtering
                          reacts[react._id] = react;
                          response.reacts[react_id] = react;
                        });
                      });

                      // stars
                      response.star_list.forEach(star_id => {
                        getStar(star_id, true).then((star) => {
                          star.session_id = session_id; // add session_id for filtering
                          stars[star._id] = star;
                          response.stars[star_id] = star;
                        });
                      });

                      // tags
                      response.tag_list.forEach(tag_id => {
                        getTag(tag_id, true).then((tag) => {
                          tag.session_id = session_id; // add session_id for filtering
                          tags[tag._id] = tag;
                          response.tags[tag_id] = tag;
                        });
                      });
                    response.session_id = session_id; // add session_id for filtering
                    responses[response._id] = response;
                    question.responses[response._id] = response; // save updated child to its parent
                    });
                  });
                question.session_id = session_id; // add session_id for filtering
                questions[question._id] = question;
                presentation.questions[question._id] = question;
                });
              });
            session.presentations[presentation._id] = presentation;
            });
          });
          dataset.sessions[session_id] = session;
        });
      });
      /* can move these out of dataset if desirable */
      dataset.upvotes = upvotes;
      dataset.reacts = reacts;
      dataset.stars = stars;
      dataset.tags = tags;
      dataset.responses = responses;
      dataset.questions = questions;
      dataset.users = users;
      dataset.teams = teams;
      // dataset = this.setUsersDirectly(dataset);
      /* save/update dataset object tree to state */
      this.setState(prevState => ( {...prevState.dataset, dataset} ) )
    })
    // let {dataset} = await this.setUsersDirectly(this.state.dataset);
    // console.log(dataset);
    // await this.setUsers();
    // return dataset; // this is a promise; can return if necessary but this function is void because setState above
  }

  async setUsers() { // async to enable await keyword
    /*
      loop through questions, reacts, stars, tags, responses, upvotes, teams
      if user_id key exists: add that object there, else create the key
    */
    // by listener_id - upvotes, reacts, stars, tags, responses
    let {dataset} = this.state; // copy of state.dataset to change, and then update once
    // let { questions, upvotes, reacts, stars, tags, responses } = this.state.dataset; // change references to dataset.x,y,z

    // main difference in the following blocks is the dataset.DATATYPE in for... of and the datatype's property key for assignment (dataset.users[].DATATYPES)
    // also, listener_id and presenter_id roughly, equivalently refer to the user responsible for the object's creation
    /* upvotes */
    for (let datatype of Object.values(dataset.upvotes)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, listener_id } = datatype; // destructures _id of datatype object, listener_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(dataset.users).includes(listener_id)) { dataset.users[listener_id] = await this.createUserDataProfile(listener_id) };
      dataset.users[listener_id].upvotes[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* reacts */
    // iterates through reacts and stores each in the user object who created it
    for (let datatype of Object.values(dataset.reacts)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, listener_id } = datatype; // destructures _id of datatype object, listener_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(dataset.users).includes(listener_id)) { dataset.users[listener_id] = await this.createUserDataProfile(listener_id) };
      dataset.users[listener_id].reacts[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* stars - presenter_id not listener_id? ensure presenter_id is the 'responsible party' for making a star */
    for (let datatype of Object.values(dataset.stars)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, presenter_id } = datatype; // destructures _id of datatype object, presenter_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(dataset.users).includes(presenter_id)) { dataset.users[presenter_id] = await this.createUserDataProfile(presenter_id) };
      dataset.users[presenter_id].stars[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* tags - disabled for debug - unclear who's responsible for a tag (presenter_id?) */
    for (let datatype of Object.values(dataset.tags)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, presenter_id } = datatype; // destructures _id of datatype object, listener_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(dataset.users).includes(presenter_id)) { dataset.users[presenter_id] = await this.createUserDataProfile(presenter_id) };
      dataset.users[presenter_id].tags[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* responses */
    for (let datatype of Object.values(dataset.responses)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, listener_id } = datatype; // destructures _id of datatype object, listener_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(dataset.users).includes(listener_id)) { dataset.users[listener_id] = await this.createUserDataProfile(listener_id) };
      dataset.users[listener_id].responses[_id] = datatype; // add { react_id: react } to the correct user's profile
    }
    /* questions */
    for (let datatype of Object.values(dataset.questions)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
      let { _id, presenter_id } = datatype; // destructures _id of datatype object, presenter_id created it
      // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
      // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
      if (!Object.keys(dataset.users).includes(presenter_id)) { dataset.users[presenter_id] = await this.createUserDataProfile(presenter_id) };
      dataset.users[presenter_id].questions[_id] = datatype; // add { react_id: react } to the correct user's profile
    }

    // update state after populating user objects with datatypes
    this.setState(prevState => ( {
      ...prevState,
      dataset: dataset, // old dataset: changed dataset assignment
    } ) );
  }

  // async setUsersDirectly(dataset) { // async to enable await keyword
  //   /*
  //     loop through questions, reacts, stars, tags, responses, upvotes, teams
  //     if user_id key exists: add that object there, else create the key
  //   */
  //   // by listener_id - upvotes, reacts, stars, tags, responses
  //   // let {dataset} = this.state; // copy of state.dataset to change, and then update once
  //   // let { questions, upvotes, reacts, stars, tags, responses } = this.state.dataset; // change references to dataset.x,y,z

  //   // main difference in the following blocks is the dataset.DATATYPE in for... of and the datatype's property key for assignment (dataset.users[].DATATYPES)
  //   // also, listener_id and presenter_id roughly, equivalently refer to the user responsible for the object's creation
  //   /* upvotes */
  //   for (let datatype of Object.values(dataset.upvotes)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
  //     let { _id, listener_id } = datatype; // destructures _id of datatype object, listener_id created it
  //     // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
  //     // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
  //     if (!Object.keys(dataset.users).includes(listener_id)) { dataset.users[listener_id] = await this.createUserDataProfile(listener_id) };
  //     dataset.users[listener_id].upvotes[_id] = datatype; // add { react_id: react } to the correct user's profile
  //   }
  //   /* reacts */
  //   // iterates through reacts and stores each in the user object who created it
  //   for (let datatype of Object.values(dataset.reacts)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
  //     let { _id, listener_id } = datatype; // destructures _id of datatype object, listener_id created it
  //     // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
  //     // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
  //     if (!Object.keys(dataset.users).includes(listener_id)) { dataset.users[listener_id] = await this.createUserDataProfile(listener_id) };
  //     dataset.users[listener_id].reacts[_id] = datatype; // add { react_id: react } to the correct user's profile
  //   }
  //   /* stars - presenter_id not listener_id? ensure presenter_id is the 'responsible party' for making a star */
  //   for (let datatype of Object.values(dataset.stars)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
  //     let { _id, presenter_id } = datatype; // destructures _id of datatype object, presenter_id created it
  //     // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
  //     // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
  //     if (!Object.keys(dataset.users).includes(presenter_id)) { dataset.users[presenter_id] = await this.createUserDataProfile(presenter_id) };
  //     dataset.users[presenter_id].stars[_id] = datatype; // add { react_id: react } to the correct user's profile
  //   }
  //   /* tags - disabled for debug - unclear who's responsible for a tag (presenter_id?) */
  //   for (let datatype of Object.values(dataset.tags)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
  //     let { _id, presenter_id } = datatype; // destructures _id of datatype object, listener_id created it
  //     // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
  //     // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
  //     if (!Object.keys(dataset.users).includes(presenter_id)) { dataset.users[presenter_id] = await this.createUserDataProfile(presenter_id) };
  //     dataset.users[presenter_id].tags[_id] = datatype; // add { react_id: react } to the correct user's profile
  //   }
  //   /* responses */
  //   for (let datatype of Object.values(dataset.responses)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
  //     let { _id, listener_id } = datatype; // destructures _id of datatype object, listener_id created it
  //     // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
  //     // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
  //     if (!Object.keys(dataset.users).includes(listener_id)) { dataset.users[listener_id] = await this.createUserDataProfile(listener_id) };
  //     dataset.users[listener_id].responses[_id] = datatype; // add { react_id: react } to the correct user's profile
  //   }
  //   /* questions */
  //   for (let datatype of Object.values(dataset.questions)) { // .values() returns array, datatype is the react/upvote/response/question/etc. object
  //     let { _id, presenter_id } = datatype; // destructures _id of datatype object, presenter_id created it
  //     // checks that a "user profile" exists; otherwise creates one with getUser() and additional datatype properties
  //     // await because profile needs to exist before adding any datatypes e.g. react, upvote, response
  //     if (!Object.keys(dataset.users).includes(presenter_id)) { dataset.users[presenter_id] = await this.createUserDataProfile(presenter_id) };
  //     dataset.users[presenter_id].questions[_id] = datatype; // add { react_id: react } to the correct user's profile
  //   }

  //   // update state after populating user objects with datatypes
  //   // this.setState(prevState => ( {
  //   //   ...prevState,
  //   //   dataset: dataset, // old dataset: changed dataset assignment
  //   // } ) );
  //   return dataset;
  // }

  // potential rewrite; teams already assigned createDatasetTree()
  async setTeams() {
    /*
      iterate over presentations, pull presenter_list
    */
    let { dataset } = this.state;
  }

  // initialize a "profile" if one doesn't already exist in dataset.users for some user
  async createUserDataProfile(user_id) { // async because getUser() returns a promise
    let user_profile_template = await getUser(user_id).then( user => {
      // return the object to assign to user_profile_template
      return ( ( { ...all } ) => ( {
        ...all,
        upvotes: {},
        reacts: {},
        stars: {},
        tags: {},
        responses: {},
        questions: {},
        teams: {},
      } ) )( user );
    } );
    return user_profile_template; // return destructured user object with additional properties to caller
  }

  /* helper functions - may not live here forever */
  // will be renamed and updated
  setSessionQuestionsAndSessionList() {
    let sessionQuestions = {};
    // iterate over sessions
    Object.values(this.state.dataset.sessions).forEach(session => {
      if (!this.state.sessionList.includes(session.title)) {
        this.setState(prevState => ( { sessionList: [ ...prevState.sessionList, session.title] } ) )
      }; // if this session isn't in the sessionList, add it this.state.sessionList.push(session_id);
      sessionQuestions[session._id] = 0;
      // iterate over presentations
      Object.values(session.presentations).forEach(presentation => {
        sessionQuestions[session._id] += presentation.question_list.length;
        // for ([key, value] of Object.entries(presentation.questions)) {
        //   // k,v things
        // }
      } )
    } );

    this.setState(() => ({ sessionQuestionsDict: sessionQuestions }));
  }

  byUser(user_id, data_type) {
    // responses (text), emojis, stars, tags, presentation
    // if listener_id === user_id
  }

  byTeam() {
    // create teams by looking through each presentation's presenter_list
  }

  getResponses() {
    // by team?
    // by person?

    // responses: { whodunnit: { session, presentation, } }
  }

  getTextResponses() {
    // by person
    // by team
  }

  getEmojis() {
    // by team
    // by person
  }

  getStars() {
    // by team
    // by person
  }

  getTags() {
    // Need More Info
  }

  render() {
    return (
      <><FlatList
        data={this.state.graphList}
        extraData={this.state.graphList}
        scrollEnabled={true}
        keyExtractor={(item) => item[item.length - 1] } // key is the last element of item (a graph[] in graphList[])
        renderItem={({ item }) => (
          <Graph item={item} graphList={this.state.graphList} sessionList={this.state.sessionList} sessionQuestionsDict={this.state.sessionQuestionsDict} dataset = {this.state.dataset} />
        )} />
      </>
    )
  }
}

const styles = StyleSheet.create({});
