import React, { Component } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Colors } from '../global/Constants';
import { Picker } from "@react-native-picker/picker";
import { VictoryBar, VictoryChart, VictoryAxis, VictoryGroup, VictoryTooltip } from "victory";
import window from "../global/Layout";
import GraphsContainer from './GraphsContainer';
import { getAllDatasetIDs, getDataset, getGraph } from '../custom-modules/backendAPI';



export default class Graph extends Component {

  constructor(props) {
    super(props);

    this.state = {
      titleVariable: this.props.item[0],
      totalAverageVariable: this.props.item[1],
      personTeamVariable: this.props.item[2],

      graphList: [], // not used
      sessionList: [], // not used
      sessionsData: {},

    }
  }

  componentDidMount() {
    this.setState(() => ({
      sessionsData: [
      { session: "Game Design Project 1" },
      { session: "Final Project" },
      { session: "Documentation Design Final" },
    ]}));
  }

 // Test Data y axis
  sessionsData = [
     { session: "Game Design Project 1" },
     { session: "Final Project" },
     { session: "Documentation Design Final" },
  ];

  // // Test Data x axis
  graphData = [
    [
      { x: 1, y: 6, z: "Test A" },
      { x: 2, y: 2, z: "Test A" },
      { x: 3, y: 4, z: "Test A" },
    ],
    [
      { x: 1, y: 4, z: 22 },
      { x: 2, y: 8, z: 22 },
      { x: 3, y: 5, z: 22 },
    ],
    [
      { x: 1, y: 2, z: "😀" },
      { x: 2, y: 6, z: "😀" },
      { x: 3, y: 8, z: "😀" },
    ],
    [
      { x: 1, y: 2, z: 42 },
      { x: 2, y: 2, z: 42 },
      { x: 3, y: 1, z: 42 },
    ],
    [
      { x: 1, y: 1, z: 52 },
      { x: 2, y: 4, z: 52 },
      { x: 3, y: 6, z: 52 },
    ],
    [
      { x: 1, y: 1, z: 62 },
      { x: 2, y: 6, z: 62 },
      { x: 3, y: 4, z: 62 },
    ],
  ];



  render() {
    console.log("State:", this.state);

    const { totalAverageVariable } = this.state;

    // Calculate the total or average based on the selected state variable
    const data = Object.values(this.state.sessionsData).map((session, index) => { // data is a new array resulting from mapping over the values of the sessionsData object in the this.state object. Each element in the new data array is the result of calling the function provided in the .map() method.
      const values = this.graphData[index].map((datum) => datum.y); // values is an array that contains only the y values from each object in the this.graphData[index] array
      return {
        x: index + 1, // x property for data
        y: totalAverageVariable === "total" ? values.reduce((a, b) => a + b) : values.reduce((a, b) => a + b) / values.length, //ternary operator if "total" is true then gives total, if false gives average - y property for data
        z: this.graphData[index][0].z // z property for data
    }
  })

    return (
      <View style={styles.graph}>
        <Text style={styles.graphText}>Select variables to visualize</Text>
        <Picker
          selectedValue={this.state.titleVariable}
          onValueChange={(value) =>
            this.setState({titleVariable: value})
          }
          style={styles.picker}
          placeholder={{ label: "Select data type" }}
        >
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Questions Asked"
            value="questionNum"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Textual Feedbacks to Questions"
            value="textFeedback"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Emoji Reactions to Feedbacks"
            value="emoji"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Star Rating Reactions to Feedbacks"
            value="star"
          />
        </Picker>


        {/* Graph */}
        <VictoryChart
          height={window.window.height / 2}
          width={window.window.width / 2}
          domainPadding={{ x: 10, y: 10 }} // add padding to the y-axis domain
          padding={{ top: 50, bottom: 50, right: 0, left: 50 }}
          animate={{
            duration: 2000,
            onLoad: { duration: 1000 }
          }}
        >
          <VictoryAxis
            domain={[0, 5]} // Set the x-axis limit of domain to values between 0 and 10
            label="Sessions" // defines the text that appears in the tooltip 
            tickValues={this.props.sessionList}
            tickFormat={(x) => x}
          />
          <VictoryAxis
            dependentAxis
            tickFormat={(y) => y}
            tickCount={5}
            domain={[0, 10]} // set the domain of the y-axis
          />

          <VictoryGroup
            offset={60}
            colorScale={"blue"}
          >
            {data.map((datum, index) => (
              <VictoryBar
                key={index.toString()}
                name={`bar-${index}`}
                barRatio={0.8}
                barWidth={30}
                alignment="middle"
                padding={1}
                data={[{ x: datum.x + 0.1, y: datum.y }]}
                labelComponent={<VictoryTooltip/>}
                labels={() => `X: ${data[index].x}\nY: ${data[index].y.toFixed(2)}\nZ: ${this.graphData[index][0].z}`} // assign the labels prop using datum object
                events={[  // hover feature that creates a flyout with data from "labels" but only changes the bar color no flyout 
                  {
                    target: "data",
                    eventHandlers: {
                      onMouseOver: () => { // user hovers over 
                        console.log("mouse over event triggered"); // message in console log for verification purposes
                        return [
                          {
                            target: "data",
                            mutation: (props) => {
                              console.log("style mutation triggered"); // message in console log for verification purposes
                              return { style: { fill: "purple" } }; // changes bar to purple color
                            }
                          },
                          {
                            target: "labels",
                            mutation: () => {
                              return { active: true }; // activate labels 
                            }
                          }
                        ];
                      },
                      onMouseOut: () => { // user leaves data point
                        console.log("mouse out event triggered"); // message in console log for verification purposes
                        return [
                          {
                            target: "data",
                            mutation: () => {
                              return null; //removes changes to data point 
                            }
                          },
                          {
                            target: "labels",
                            mutation: () => {
                              return { active: false }; // deactivates any labels associated to data point
                            }
                          }
                        ];
                      }
                    }
                  }
                ]}
              />
            ))}
          </VictoryGroup>
        </VictoryChart>
        <GraphsContainer sessionsData={this.state.sessionsData} />

        <View style={styles.subPickers}>
          <Picker //used as a way for the user to select a value for totalAverageVariable
            selectedValue={this.state.totalAverageVariable}
            onValueChange={(value) =>
              this.setState({totalAverageVariable: value})
            }
            style={styles.subPicker}
            placeholder={{ label: "select variable" }}
          >
            <Picker.Item //allows individual items to be rendered within the Picker dropdown menu
              style={styles.subPickerItem}
              label="total"
              value="total"
            />
            <Picker.Item //allows individual items to be rendered within the Picker dropdown menu
              style={styles.subPickerItem}
              label="average"
              value="average"
            />
          </Picker>
          <Picker
            selectedValue={this.state.personTeamVariable}
            onValueChange={(value) =>
              this.setState({personTeamVariable: value})
            }
            style={styles.subPicker}
            placeholder={{ label: "select variable" }}
          >
            <Picker.Item
              style={styles.subPickerItem}
              label="from person"
              value="from person"
            />
            <Picker.Item
              style={styles.subPickerItem}
              label="from team"
              value="from team"
            />
          </Picker>
        </View>
      </View>
    )
  }
}


const styles = StyleSheet.create({
  graph: {
    marginTop: 30,
    borderRadius: 30,
    marginBottom: 25,
    backgroundColor: "white",
    width: window.window.width / 1.5,
    height: window.window.height / 1.1,
  },
  graphText: {
    fontSize: 12,
    color: Colors.ppGreyText,
    marginTop: 20,
    marginLeft: 30,
  },
  picker: {
    marginTop: 30,
    marginLeft: 30,
    marginRight: 30,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: Colors.ppGreyText,
    fontSize: window.window.height / 50,
    width: window.window.width / 1.6,
    height: window.window.height / 10,
    fontSize: 20,
    fontWeight: "bold",
    color: Colors.ppTextColor,
    paddingLeft: 10,
  },
  pickerItem: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 30,
    color: Colors.ppTextColor,
  },
  subPickers: {
    marginVertical: 10,
    marginLeft: 30,
    marginRight: 30,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  subPicker: {
    borderColor: Colors.ppGreyText,
    padding: 10,
    borderWidth: 1,
    borderRadius: 10,
    fontSize: 18,
  },
});



