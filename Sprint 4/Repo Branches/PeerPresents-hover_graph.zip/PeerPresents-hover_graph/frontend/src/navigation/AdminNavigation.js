import * as React from "react";
import DashboardTab from "../screens/DashboardTab";
import CoursesTab from "../screens/CoursesTab";
import DataTab from "../screens/DataTab";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { Colors } from "../global/Constants";
import { StyleSheet } from "react-native";
import window from "../global/Layout";
import CustomSidebarMenu from "../components/CustomSidebarMenu";
import CourseScreen from "../screens/CourseScreen";
import CreateCourseScreen from "../screens/CreateCourseScreen";
import EditDeleteCourseScreen from "../screens/EditDeleteCourseScreen";
import AddCourseScreen from "../screens/AddCourseScreen";
import ProfileTab from "../screens/ProfileTab";
import PresentationScreen from "../screens/PresentationScreen";
import DatasetScreen from "../screens/DatasetScreen";
import CreateDatasetScreen from "../screens/CreateDatasetScreen";
import { createStackNavigator } from '@react-navigation/stack';
import SessionScreen from '../screens/SessionScreen';
import QuestionScreen from '../screens/QuestionsScreen';
import CreateEditSessionScreen from "../screens/CreateEditSessionScreen";

const Drawer = createDrawerNavigator();

export default function AdminNavigation({ navigation, route }) {
  return (
    <Drawer.Navigator
      initialRouteName="HomeAdmin"
      drawerStyle={styles.drawerStyle}
      drawerContentOptions={{
        activeTintColor: "white",
        inactiveTintColor: "white",
      }}
      drawerContent={(props) => <CustomSidebarMenu {...props} />}
    >
      <Drawer.Screen name="Instructor Dashboard">{DashboardStackScreen}</Drawer.Screen>
      <Drawer.Screen name="Courses">{CoursesStackScreen}</Drawer.Screen>
      {/* Removing the data tab from the app until ready */}
      <Drawer.Screen name="Data">{DataStackScreen}</Drawer.Screen>
      <Drawer.Screen name="Profile">{ProfileStackScreen}</Drawer.Screen>
    </Drawer.Navigator>
  );
}

const DashboardStack = createStackNavigator();

function DashboardStackScreen({ route, navigation }) {
  return (
    <DashboardStack.Navigator
      screenOptions={{headerShown: false,
        cardStyle: {backgroundColor: Colors.backgroundColor}
      }}>
      <DashboardStack.Screen name="DashboardTab" component={DashboardTab} />
      <DashboardStack.Screen name="Session" component={SessionScreen} />
      <DashboardStack.Screen name="Presentation" component={PresentationScreen} />
      <DashboardStack.Screen name="Questions" component={QuestionScreen} />
      <DashboardStack.Screen name="CreateEditSession" component={CreateEditSessionScreen} />
    </DashboardStack.Navigator>
  );
}

const CoursesStack = createStackNavigator();

function CoursesStackScreen({ route, navigation }) {
  return (
 <CoursesStack.Navigator
    screenOptions={{headerShown: false,
      cardStyle: {backgroundColor: Colors.backgroundColor}
    }}>
      <CoursesStack.Screen name="Courses" component={CoursesTab} />
      <CoursesStack.Screen name="CreateCourse" component={CreateCourseScreen} />
      <CoursesStack.Screen name="EditCourse" component={EditDeleteCourseScreen} />
      <CoursesStack.Screen name="AddCourse" component={AddCourseScreen} />
      <CoursesStack.Screen name="Course" component={CourseScreen} />
      <CoursesStack.Screen name="Session" component={SessionScreen} />
      <CoursesStack.Screen name="Presentation" component={PresentationScreen} />
      <CoursesStack.Screen name="Questions" component={QuestionScreen} />
      <CoursesStack.Screen name="CreateEditSession" component={CreateEditSessionScreen} />
    </CoursesStack.Navigator>
  );
}

const DataStack = createStackNavigator();

function DataStackScreen({ route, navigation }) {
  return (
 <DataStack.Navigator
    screenOptions={{headerShown: false,
      cardStyle: {backgroundColor: Colors.backgroundColor}
    }}>
      <DataStack.Screen name="DataTab" component={DataTab} />
      <DataStack.Screen name="DatasetScreen" component={DatasetScreen} />
      <DataStack.Screen name="CreateDatasetScreen" component={CreateDatasetScreen} />
    </DataStack.Navigator>
  );
}

const ProfileStack = createStackNavigator();

function ProfileStackScreen({ route, navigation }) {
  return (
 <ProfileStack.Navigator
    screenOptions={{headerShown: false,
      cardStyle: {backgroundColor: Colors.backgroundColor}
    }}>
      <ProfileStack.Screen name="Profile" component={ProfileTab} />
    </ProfileStack.Navigator>
  );
}

const styles = StyleSheet.create({
  drawerStyle: {
    backgroundColor: Colors.ppMainPurple,
    width: window.window.width / 7,
  },
});
