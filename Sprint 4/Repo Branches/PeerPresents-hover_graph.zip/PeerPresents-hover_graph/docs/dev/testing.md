## The Jest Testing Environment

### Introduction

PeerPresents uses Jest, a JavaScript testing framework. The official documentation can be found at https://jestjs.io (some of the explanations below are taken from this resource).
Another useful guide for testing React applications can be found at https://reactnative.dev/docs/testing-overview
Jest includes various types of tests that you can use:

#### 1. Unit tests

Testing for the smallest parts of the code, such as methods. Jest allows you to use mocks in order to deal with dependencies.

#### 2. Integration tests

Testing of a combination of different parts of the application that need to cooperate in it.

#### 3. Component tests

Testing of individual React components that get rendered - their UI as well as their business logic.
This type includes user interactions, as well as rendered output.

#### 4. End-to-End tests

Testing that the application works as expected on an actual device, after building it in the release configuration.

### Installation

In order to install Jest, go to the PeerPresents folder on your machine and run the following command in the shell:

```
$ npm install --save-dev jest
```

For additional configurations or installation help, please refer to the official documentation at https://jestjs.io/docs/en/getting-started.


## Testing in PeerPresents

In PeerPresents, the tests folder can be found at:

```
PeerPresents/frontend/src/__tests__
```

Currently, the folder mainly containes component tests, which verify correct render of the different components of the application.

In order to run the tests, go to the tests folder mentioned above and run the following command in the shell:

```
$ npm run test
```

You will then get a full report on the tests, and which of them have passed.


## Recommendations on writing tests

1. A very useful and efficient approach for developing software is called Test-Driven Design (TDD), which means writing the tests of the application before writing the code that these tests test.
This is helpful for a few reasons:

- Firstly, as soon as you finish writing a piece of code you can test it to make sure it works well and does not break.

- Secondly, the tests are written withous bias, and you don't change them to fit the code, but the other way around - you change (fix) your code to pass the tests, which ensures your code is correct.

- Thirdly, with this approach you make sure your code fully works as you develop, which gived you confidence in your code and does not require you to go back after a big amount of development to fix bugs.

- Lastly, writing tests does not become a chore that you have to do after the development is over because you do that as part of the code development.

