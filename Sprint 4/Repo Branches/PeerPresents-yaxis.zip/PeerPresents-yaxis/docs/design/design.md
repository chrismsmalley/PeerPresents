## PeerPresents Design Document ##
A Web-Based System for In-Class Peer Feedback during Student Presentations


### Context

Peer feedback systems enable students to get feedback without substantially burdening the instructor. However, current systems typically ask students to provide feedback after class; this introduces challenges for ensuring relevant, timely, diverse, and sufficient amounts of feedback, and reduces the time available for student reflection. PeerPresents is a novel system for in-class peer review where students can quickly exchange feedback on projects without being burdened by additional work outside of class. We found students can receive immediate, copious, and diverse peer feedback through a structured in-class activity. Students also described the feedback they received as helpful and reported that they gave more feedback than without using the system. These early results demonstrate the potential
benefits of in-class peer feedback systems.


### Overview
![architecture overview](../res/architecture_overview.png)


### Stakeholders

* Students presenting their work
* Students giving feedback to peers
* Course Staff or Instructors
* Researchers using data


### Goals

#### Overall Goals

* Support stakeholder goals
* Scale horizontally to support user growth
  * I.e. microservice architecture
* Target platforms
  * (Server): Flexible deployment (compatible with cloud platforms and on-premise machines)
  * (App): Desktop and mobile web-browsers

#### Stakeholders

* Students presenting their work
* Students giving feedback to peers
* Course staff / Instructors
* Researchers using generated data

#### Scope

For scope and stakeholder goals, see the Project Plan document.

### Proposed Solution

**Architecture:**

Follows a microservice architecture. The user interacts exclusively through the Frontend. The Frontend sends all requests to the Backend (1 or more servers). If using more than 1 Backend Worker, a simple load balancer can be used. The Backend Web Server receives all incoming Frontend requests and sends tasks to the available Worker Services. Worker Services process the actual requests and respond to the requester. The task load of the Worker Services is monitored by the Backend Master. The Backend Master can start and stop Worker Services as needed by the current task load.

**Components:**

* Frontend
* Backend
  * Web Server / HTTP load balancer
  * Master
  * Worker
* Storage

**Implementation**

PeerPresents is a Node.js application. The Koa framework is used for the backend components and API consumption. The frontend uses the React-Native framework to build declarative UIs and dynamic layouts.

### Testability, Monitoring, and Alerting

**Unit Tests**

Unit tests will be written for all components continuously during development. A component must pass all unit tests before being accepted into the master branch.

**Functional Tests**

Functional tests will be written for all components continuously during development. A component must pass all functional tests before being accepted into the master branch.

**Monitoring**

Any system/component actively running on non-development resources must be monitored with periodic health checks. The monitoring results must be stored in an auditable format in a secure location. 

### Open Questions




