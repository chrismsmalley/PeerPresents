# Backend Development Guide

This guide is intended to help you through common development tasks for the backend components of PeerPresents. It is assumed you already have a local development environment setup and ready to go. If not, see the [local dev guide](local_dev_guide.md).

If you are unfamiliar with the PeerPresents architecture and the various components, you may want to start with the [design document](../design/design.md).

## Major Components

1. [Backend API](#backend-api)
2. [Storage API](#storage-api)
3. [Application Database](#application-database)

## Common Tasks

1. [Adding a new entity to the Application Database](#adding-a-new-entity-to-the-application-database)
2. [Adding a field to an Application Database entity](#adding-a-field-to-an-application-database-entity)
3. [Adding a new method to the Backend API](#adding-a-new-method-to-the-backend-api)
4. [Adding a new method of the Storage API](#adding-a-new-method-of-the-storage-api)
5. [Adding authentication to an API](#adding-authentication-to-an-api)

## Components

### Backend API

The Backend API handles requests from the Frontend client. This API is ran by the Worker service. The source code for the Worker service can be found in `PeerPresents/backend_worker/`.

### Storage API

The Storage API handles requests from the Worker service. This API is ran by the Storage service. The source code for the Storage service can be found in `PeerPresents/storage/`.

### Application Database

The Application Database is a MongoDB instance that accepts remote commands from the Storage service. The Schema used by the Application Database is enforced by the Storage service. The schema is defined using the [hapi joi library](https://github.com/hapijs/joi) The definition file is located here: `PeerPresents/storage/app/schema/data_models.js`  . To modify the schema you must edit the `data_models.js` file.

## Tasks

### Adding a new entity to the Application Database

To add a new data model entity in the Application Database schema you will need to do two things.

1. Define the entity in the schema definition file
2. Add backend API calls to support CRUD operations on the new entity

Follow the instructions below.

#### 1. Define Entity in Schema

The Application Database schema is defined using the [hapi joi library](https://github.com/hapijs/joi) The definition file is located here: `PeerPresents/storage/app/schema/data_models.js` .

You can follow the existing entity definitions as an example to define your new entity. Reference the hapi joi documentation to learn how the library functions work.

After you have added the new entity definition, make sure you add it to the list of exports (`module.exports`) at the bottom of the file.

With the schema definition updated, the Storage service is ready to handle the new entity. However the Worker service is not yet ready. 

Follow the next steps to prepare the Backend API to use the new entity.

#### 2. Create Entity CRUD Functions in Backend API

Now you will need to create functions to support Create, Read, Update, and Delete (CRUD) operations on the new database entity. Find the relevant files in `PeerPresents/backend_worker/app/`.

Inside this `app` folder you will need to work with two files:

The **routes file**: `app/routes/index.js`

and the **controller file**: `app/controllers/storageController.js`

The **routes file** defines all the URL endpoints the API supports as well as which functions they run.

Near the top of the page you can see the CRUD route definitions for the `user` entity:

```
router.post(uri_prefix+'/id/',         createUser);
router.get( uri_prefix+'/id/:userid',  readUser);
router.put( uri_prefix+'/id/:userid',  updateUser);
router.del( uri_prefix+'/id/:userid',  deleteUser);
router.get( uri_prefix+'/id/',         listUsers);
```

The functions used in these routes are defined in the **controller file**.

You will need to mimic these 5 lines to define the routes needed for the new entity. However you will need to use new functions (create<Entity>, etc.) that are not defined yet.

With the new routes defined, you are ready to add the functions to the **controller file**.

Use the user functions (createUser, readUser, etc.) as a model for how to write the new functions for the new entity. Most of the code will be the same, but a few portions of the functions are entity-specific.

*Note: The Backend API's controller file could probably be refactored to be more like the Storage API's controller file. That is to say, it could be made to not be entity-specific.

Once these functions are defined, make sure they are in the `module.export` list in the controller file. Also most sure the new functions are imported in the routes file.

Now the new entity is ready to be tested through the Storage API and Backend API.

### Adding a field to an Application Database entity

Adding a field to an existing entity is a short task. You only need to update the schema file.

The Application Database schema is defined using the [hapi joi library](https://github.com/hapijs/joi) The definition file is located here: `PeerPresents/storage/app/schema/data_models.js` .

Edit the schema definition file to modify the existing entity as needed.

You can follow the existing entity definitions as an example. Reference the hapi joi documentation to learn how the library functions work.

After the schema is edited the Storage service will be ready to use it the next time to starts.

### Adding a new method to the Backend API

Find the relevant files in `PeerPresents/backend_worker/app/`.

Inside this `app` folder you will need to work with two files:

The **routes file**: `app/routes/index.js`

and the **controller file**: `app/controllers/storageController.js`

The **routes file** defines all the URL endpoints the API supports as well as which functions they run.

Near the top of the page you can see the CRUD route definitions for the `user` entity:

```
router.post(uri_prefix+'/id/',         createUser);
router.get( uri_prefix+'/id/:userid',  readUser);
router.put( uri_prefix+'/id/:userid',  updateUser);
router.del( uri_prefix+'/id/:userid',  deleteUser);
router.get( uri_prefix+'/id/',         listUsers);
```

The first line defines the route: "POST requests to /id/ are processed by the function createUser()".

The second line defines the route: "GET requests to /id/<value> are processed by the function readUser(<value>)".

As you can see, four things are being defined:

1. HTTP method: (GET, POST, PUT, DELETE)
2. URL endpoint: ('/id/')
3. Parameters from URL: (:userid)
4. Function: (readUser)

You will need to know what your new method needs for the first three items. Follow the existing routes as examples. The fourth item, the function, is a new function that you will define in the **controller file**.

After you define the new routes, you are ready to add the functions to the **controller file**.

Use the user functions (createUser, readUser, etc.) as a model for how to write your new functions. 

The goal of these functions is to process the incoming request (from Frontend) and use that information to determine what data to request from the Storage API. The result of your Storage API request(s) must be returned to the requester (the Frontend).

Once these functions are defined, make sure they are in the `module.export` list in the controller file. Also most sure the new functions are imported in the routes file.

Now the new the methods are ready to be tested through the Backend API.

### Adding a new method of the Storage API

Find the relevant files in `PeerPresents/storage/app/`.

Inside this `app` folder you will need to work with two files:

The **routes file**: `app/routes/index.js`

and the **controller file**: `app/controllers/mongodbController.js`

This works the same as it does with the [Backend API](#adding-a-new-method-to-the-backend-api) except the relevant files are in different locations. See the Backend API section for more details.

### Adding authentication to an API

#### Token-Base Auth

For APIs authentication it is generally best to go with a "token-based" approach. This typically means that the API has one endpoint that lets users "authenticate" themselves and issues a special token to them. All following API requests from the user send along this token with their requests. As long as a request comes in with a valid token, we know it is from an valid user. Typically the tokens are set to expire after a set amount of time. If a request with an expired token is receive, the user has to renew their token.

#### Token Auth Example

At the time of writing, only the Storage API used authentication. The Backend API authenticates with the Storage API for all communication. The Storage API can be used as a model for how to add authentication to another API.

Let's examine the relevant files in: `PeerPresents/storage/app/`

The **routes file**: `app/routes/index.js`

the **auth file**: `app/middlewares/authenticate.js`

and the **main app file**: `/app/storage.js`

In the routes file we have the following route definition:

```
router.post('/login', authenticate);
```

This '/login' endpoint triggers the authenticate function defined in the auth file.

The authenticate function checks the request to see if it has a password field that matches its key_password (key_password read from config file). If the password matches, it is considered to be authenticated. Otherwise it is rejected and nothing happens.

If authenticated, a new token is generated and returned to the requestor. The requestor is responsible for storing the token and sending it with any following API calls.

Finally, to configure the app to require a token for all API calls (expect the `/login` endpoint), we have the following line in the main app file: `/app/storage.js`

```
app.use(jwt({secret: api_conf.storage.secret}).unless({path: [/^\/login/]}));
```

This tells the API router that it should only accept requests that contain a token generated using the `secret` defined in the api config. Although it should ignore this for the '/login' endpoint.

To see how to properly send the token to the Storage API, see the Backend API controller file: `PeerPresents/backend_worker/app/controllers/storageController.js`

The request options must have a header field as shown below:

```
const rp = require('request-promise-native')

// set request options
let options = {
    uri: `${uri_head}/user`,
    method: 'POST',
    body: {
        model: _model
    },
    resolveWithFullResponse: true,
    simple: false,
    json: true,
    headers: {
        'Authorization': `Bearer ${api_conf.storage.token}`
    }
}

// make request to storage api
const res = await rp(options);
```

#### Adding Auth to Backend API

Using the information above, you could add authentication between the Frontend client and Backend API.

The Frontend would need to:

1. Call a special endpoint (E.g. '/login') to request a new token. 
2. Locally store the token it receives.
3. Send its token as a header field for all other API calls.

The Backend would need to:

1. Add authentication "middleware" to generate valid tokens.
2. Create new endpoint to issue new tokens (using middleware above).
3. Configure the Koa app routes (expect the new endpoint) to require your tokens.