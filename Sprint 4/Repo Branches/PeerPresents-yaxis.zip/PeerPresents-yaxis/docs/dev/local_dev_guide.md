# Local Development Setup Guide

## Local Development Environment Setup

Use the IDE or Editor of your choice. You will only need to run some setup commands through the CLI. Commands and related tools will vary slightly across different OS platforms.

### Cross-Platform Instructions

#### 1) Install Node.js

Peer Presents uses Node.js v12+

Download and install the lastest LTS version of Node.js: https://nodejs.org/en/download/

If you use Node for other projects you may want to install a Node version manager. On Mac and Linux you can use `nvm` and for Windows you can use `nodist`. For more details about these see: https://npm.github.io/installation-setup-docs/installing/using-a-node-version-manager.html

#### 2) Peer Presents GitHub Repository

The GitHub repository is: https://github.com/Ludolab/PeerPresents

We use the `master` branch as the base branch for the most recent MVP. This branch should always be demo-ready.

We follow a feature branch workflow. If you are unfamiliar with it, please review this [guide](https://www.atlassian.com/git/tutorials/comparing-workflows/feature-branch-workflow). The base branch for new features is `dev`.  So new feature branches should be created off of `dev` and when completed, merged back into `dev` through a pull request.

To get started, first clone the repository. Run this command in your terminal:
`git clone http://github.com/Ludolab/PeerPresents.git`

Now you can start looking around the project code:

`cd PeerPresents/`

But remember you'll start off in the `master` branch, so to see the latest source switch to the `dev` branch. The following command creates a new local branch called "dev" and sets it to track the remote branch "origin/dev":

`git checkout -b dev origin/dev`

When you are ready to start a feature branch first make sure you are on the `dev` branch:

`git branch`

If we wanted to create a branch called "new_feature" we could do so with:

`git checkout -b new_feature`



#### 3) Install Node Modules for each Core Component

There are four core components: 

* Frontend
* Storage
* Backend_Master
* Backend_Worker

Each component has it's own project configuration file (package.json) and it's own node_modules folder. The node_modules folders are not stored in the repository so you'll have to install those modules with npm. Note that you only need to install modules for the components you'll be using. For example, if you are only working on the frontend you typically won't need to run the Storage or Backend components.

##### Frontend

From the root directory `PeerPresents/`:

`cd frontend`

This component has one dependency that isn't part of the package.json configuration because it is generally better to install it globally.
`npm install -g expo-cli`

Install all dependency modules:

`npm install`

##### Storage

From the root directory `PeerPresents/`:

`cd storage
`

Install all dependency modules:

`npm install`

##### Backend_Master

From the root directory `PeerPresents/`:

`cd backend_master`

Install all dependency modules:

`npm install`

##### Backend_Worker

From the root directory `PeerPresents/`:

`cd backend_worker`

Install all dependency modules:

`npm install`

#### 4) Running Components

Most components can be started through npm with:

`npm start`

However, each component is slightly different and these may change over time. You can generally see how to start the component by looking at it's package.json file and seeing what "scripts" are available.

##### Frontend

`npm run web`

##### Storage

`npm start`

##### Backend_Master

`npm start`

##### Backend_Worker

`npm start`

### Mac

Mac specific details can be documented here.

### Linux

Linux specific details can be documented here.

### Windows

Windows specific details can be documented here.

