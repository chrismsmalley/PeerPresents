

# Application Admin Guide

This guide is meant to cover the typical tasks you will need to do keep PeerPresents running in the documented environment(s). All this information is covered in more detail throughout the admin and design documents.

## Common Tasks

1. [Log into Server](#log-into-server)
2. [Switch to `root` User](#switch-to-root-user)
3. [Managing Services](#managing-services)
   1. [Worker Service](#managing-worker-service)
   2. [Storage Service](#managing-storage-service)
   3. [Application Database](#managing-application-database)
4. [Deploying](#deploying)
5. [Understanding App Config Files](#configuration-files)
6. [Resetting the App Database](#resetting-the-app-database)
7. [Troubleshooting](#troubleshooting)
   1. [Cannot Connect to Server](#cannot-connect-to-server)
   2. [Web Site Down](#web-site-is-down)
   3. [Web App Network Failure](#web-app-network-failure)
   4. [Application Database Not Responding](#application-database-not-responding)

## Overview

![architecture overview](../res/architecture_overview.png)

The PeerPresents application relies on several components running in the documented environment(s). For the Alpha version, the required components are: Web Server, Worker Service, and Storage Service.

### Component Purpose/Function

**1. Web Server**

Serves the Frontend application to users' web browsers. The content served through the web server is all static content. 

**2. Worker Service**

This service handles all the Backend API requests sent by the Frontend. It delegates tasks to the Storage service and handles sending responses back to the Frontend.

**3. Storage Service**

This service handles all the Storage API requests from the Worker service(s). It directly modifies the application database (currently an instance of MongoDB).

### Infrastructure

The PeerPresents environments are Virtual Machines (VMs) hosts by CMU Campus Cloud. For more details on Campus Cloud, how to access it, and getting support, see the [Admin Overview](administration.md) Doc.

## Log into Server

You can access the server as the user `peerpresents` using the `ssh` command. E.g. to access the test server from a local machine (laptop/desktop) run:

```
$ ssh peerpresents@peerpresents-test.andrew.cmu.edu
```

You'll need credentials which you can find in the [Credentials Management](../dev/project_management_plan.md#credentials-management-plan) Plan details.

## Switch to root User

For a many tasks you will need to run commands as the `root` user. The `root` user has full access to the system, so take proper precautions before running commands.

To switch to the `root` user run the command below. You will then be prompted for the root password.

```
$ su
```

After you successfully enter the password you'll be the `root` user instead of `peerpresents`.

Run the commands you need to as `root` then switch back to `peerpresents` when you are done. You can tell you are `root` because the command prompt begins with `#` instead of the usual `$` :

```
# 
```

Change back to `peerpresents` user by running the command:

```
# exit
```

## Managing Services

This section serves as a reference for commands needed to start, stop, or check the status of important services. This includes: Web Server, Worker Service, and Storage Service.

This section assumes you are already logged into the server you need to manage services on. If you are not logged into the server

### Managing Web Server

You can use the `systemctl` command to manage the Nginx process. However you need to run them as the `root` user. See the [switch to root user](#switch-to-root-user) section for details on running commands as `root`.

To **stop the web server**:

```
# systemctl stop nginx
```

To **start the web server**:

```
# systemctl start nginx
```

To stop and then start up again:

```
# systemctl restart nginx
```

To reload configurations without dropping connections:

```
# systemctl reload nginx
```

##### Important Files and Directories

Check the [Nginx documentation](administration.md#nginx) to see where the web server configuration and log files are.

### Managing Worker Service

You can use the `forever` command as the `peerpresents` user to manage the Worker service.

To **check the service** status:

```
$ forever list
```

You should see a uid of "worker" in the output. E.g.:

```
info:    Forever processes running
data:        uid    command                               script   forever pid   id logfile                                uptime
data:    [0] worker /opt/node-v12.17.0-linux-x64/bin/node index.js 21237   21244    /home/peerpresents/.forever/worker.log 0:0:0:1.618
```

To **stop the service**:

```
$ forever stop worker
```

To **start the service**:

```
$ cd ~/src/PeerPresents/backend_worker/
$ ./start.sh
```

### Managing Storage Service

You can use the `forever` command as the `peerpresents` user to manage the Storage service.

To **check the service** status:

```
$ forever list
```

You should see a uid of "storage" in the output. E.g.:

   ```
   info:    Forever processes running
   data:        uid     command                               script   forever pid   id logfile                                 uptime
   data:    [0] storage /opt/node-v12.17.0-linux-x64/bin/node index.js 21145   21152    /home/peerpresents/.forever/storage.log 0:0:0:1.303
   ```

To **stop the service**:

```
$ forever stop storage
```

To **start the service**:

```
$ cd ~/src/PeerPresents/storage/
$ ./start.sh
```

### Managing Application Database

You can use the `systemctl` command to manage the MongoDB process. However you need to run them as the `root` user. See the [switch to root user](#switch-to-root-user) section for details on running commands as `root`.

To **stop the database**:

```
# systemctl stop mongod
```

To **start the database**:

```
# systemctl start mongod
```

You can also check the status of the database. You do not need to be root to do so.

```
$ systemctl status mongod
```

## Deploying

Follow the steps below to update PeerPresents on an environment and deploy it ("make the website live"). These steps assume you have already logged into the environment you want to update the application on. If you haven't logged into the environment yet, see [how to log into a server](#log-into-server). If you are having trouble accessing the environment, see the [Troubleshooting](#troubleshooting) section.

### 1. Update Source Code

As the `peerpresents` user, you will to change to the source code directory: `~/src/PeerPresents/`. This is the "root" directory of the Github repo.

```
$ cd ~/src/PeerPresents/
```

After you are in the PeerPresents directory, run the following command to update the repository:

```
$ git fetch
```

**Note:** You will need read access to the repo to successfully download it. Talk to technical or management staff if you require access.

**Check which branch** you need. Typically you will be using either one of the following branches: `master`, `test`, or `dev`.

Use this command to see what branch you currently are on:

```
$ git branch
```

If you need to change the branch use the `checkout` command. E.g. to change to the `test` branch, run the command:

```
$ git checkout test
```

Ensure your branch is update-to-date by running:

```
$ git pull
```

Now all the source code should be updated.

### 2. Build from Source Code

After updating the source code, you need to build/install the new versions of the components as the `peerpresents` user.

#### A. Storage

Enter the directory: `PeerPresents/storage/`

```
$ cd ~/src/PeerPresents/storage/
```

Install with:

```
$ npm install
```

#### B. Worker

Enter the directory: `PeerPresents/backend_worker/`

```
$ cd ~/src/PeerPresents/backend_worker/
```

Install with:

```
$ npm install
```

#### C. Frontend

Enter the directory: `PeerPresents/frontend/src`

```
$ cd ~/src/PeerPresents/frontend/src/
```

Install with:

```
$ npm install
```

Build the component for web:

```
$ expo build:web
```

### 3. Deploy

After building the latest components you are ready to deploy the full application.

You need to:

#### A. Stop Services

If the previous versions of the services are running, you should stop them first (See Managing Services section above for more details).

```
$ forever stop worker
$ forever stop storage
```

#### B. Deploy New Frontend

Assuming you already built the frontend for web deployment, next you need to copy the web build to the web server's content directory. You will need to switch to the `root` user to do so.

To switch to the `root` user run the command below. You will then be prompted for the root password.

```
$ su
```

After you successfully enter the password you'll be the `root` user instead of `peerpresents`.

Now you can copy the web build to the web server with the command:

```
# cp -r /home/peerpresents/src/PeerPresents/frontend/src/web-build/ /usr/share/nginx/html/
```

Change back to `peerpresents` user by running the command:

```
# exit
```

#### C. Start Services

(See [Managing Services](#managing-services) section above for more details)

Start Worker:

```
$ cd ~/src/PeerPresents/backend_worker/
$ ./start.sh
```

Start Storage:

```
$ cd ~/src/PeerPresents/storage/
$ ./start.sh
```

#### D. Reload Configurations

In order for the changes to reflect immediately, you will have to reload the configurations. First you will need to switch to the `root` user to do so.

To switch to the `root` user run the command below. You will then be prompted for the root password.

```
$ su
```

Then run the command below to reload the configurations:

```
# systemctl reload nginx
```

When you are done, change back to `peerpresents` user by running the command:

```
# exit
```

## Configuration Files

At the time of writing, the PeerPresents app has two configuration files: `ppdb_conf.js` for database config information and `api_conf.js` for API config information.

### Database Config

The `ppdb_conf.js` file looks like this:

```
module.exports = {
    mongo: {
        ip: "fake",
        port: 0,
        name: "fake",
        user: "fake",
        pwd: "fake"
    }
};
```

This config file is used by the Storage component's source file: `mongodbManager.js`. It contains all the information the mongodb manager file needs to connect to the database and issue requests to it.

It contains networking information:

`ip`: the IP address the database is listening on
`port`: the port number the database is listening on

It also contains database information and credentials:

`name`: the name of the mongoDB database being used
`user`: the username that has access to read/write on the database, <name>
`pwd`: the password of the above user

Details on gathering the accurate information for this config file can be found in the [Database Setup section](docs/server_setup_guide.md#configure-mongodb-for-peerpresents) of the Server Setup Guide.

### API Config

The `api_conf.js` file looks like this:

```
module.exports = {
    storage: {
        secret: "secret",
        key_password: "password",
        token: "token",
        domain: "",
        port: 0
    }
}
```

This config file is used by both the Storage component (files: `app/storage.js`, `app/authenticate.js`) and the Worker component (file: `app/controllers/storageController.js`).

The Storage component uses the follow fields for generate authentication tokens:

`secret`: A passphrase used in generating new tokens
`key_password`: A password that should be sent with authentication requests

The Worker component uses the remaining fields for accessing the Storage API:

`token`: The most recent token provided from authenticating with the Storage API
`domain`: The IP address the Storage API is listening on
`port`: The port number the Storage API is listening on

## Resetting the App Database

```diff
*** VERY IMPORTANT - PLEASE NOTE: ***
   #### DO NOT ATTEMPT TO RUN THIS SCRIPT IF YOU ARE NOT THE LEAD DEVELOPER WHO IS IN CHARGE OF THE ENTIRE PROJECT
   #### DO NOT ATTEMPT TO RUN THIS SCRIPT IF YOU ARE NOT ENTIRELY SURE THAT THE DATABASE HAS A FULL BACKUP
   #### DO NOT ATTEMPT TO RUN THIS SCRIPT BEFORE YOU SPOKE WITH A SENIOR DEVELOPER WHO IS FAMILIAR WITH THE SYSTEM
   #### DO NOT ATTEMPT TO RUN THIS SCRIPT IF YOU ARE NOT ENTIRELY SURE WHAT YOU ARE DOING
   #### RUNNING THIS SCRIPT, AS MENTIONED BELOW, WILL DELETE ALL THE DATA AND CANNOT BE UNDONE
```
   
Sometime you may want to reset the Application Database. **This will irreversibly delete the current database** configured in the `ppdb_conf.js` file. Do not do this in a production environment unless you have backed up the database or know you do not need the production data any longer.

Scripts for managing the Application Database remotely can be found in the Storage component source code directory: `PeerPresents/storage/manamement/`.

The script named `reset-database.js` will delete the database and re-configure it for the existing schema. This provides a new, empty, database ready for PeerPresents to use.

If you want to insert test data into the database you can use the script named `load-test-data.js`.

Example resetting the App DB then loading it with test data:

```
$ cd PeerPresents/storage/management/
$ node ./reset-database.js
$ node ./load-test-data.js
```

## Troubleshooting

This section is intended to guide you toward relevant information in the documentation for various problems.

### Cannot Connect to Server

Follow these steps if you cannot connect to one of our servers with `ssh`.

#### 1. Double check the `ssh` command you entered.

The user should be `peerpresents`. The domain name will depend on the environment you are trying to access. For test the domain should be `peerpresents-test.andrew.cmu.edu`. So the full command should look like:

```
$ ssh peerpresents@peerpresents-test.andrew.cmu.edu
```

#### 2. Check if the server is 'up'

Next you should check to see if the server is still up and running. You can use the `ping` command to test if the server responds to network requests. E.g.

```
$ ping peerpresents-test.andrew.cmu.edu
```

The `ping` command sends packets to the target and outputs how many packets were sent and how many packets were lost (not received).

If all (or most) packets are received, the server is up but something is wrong with `ssh`. 

If *no* packets are received, the server is either down (off) or not operating correctly.

In either scenario, you'll want to go to the [Campus Cloud documentation](docs/dev/project_management_plan.md#infrastructure-information) and see how get "console access" to the server.

Following the Campus Cloud documentation, you can check if the server is running or not. In most cases like this, is it worth trying to restart the server and see if you can access with `ssh` after it is running again.

If you still cannot access it, a system admin will need to look into the issue. You may also contact Campus Cloud for assistance.

### Web Site is Down

Follow these steps if no one can access the web site from web browsers.

#### 1. Check the web server is running

Reference the [Managing Web Server](#managing-web-server) section to see if the Storage service is running. If not, start it.

#### 2. Check for HTTPS errors

If the web site fails to load due to SSL or HTPPS related errors, the problem may be that the server's SSL certificate has expired. Follow the [Renewing SSL Certs](administration.md#renewing-ssl-certs) section of the Administration Guide to renew the SSL certificate.

### Web App Network Failure

Follow these steps if the web app loads but doesn't display any content.

#### 1. Check that the backend services are running

Reference the [Managing Storage Service](#managing-storage-service) section to see if the Storage service is running. If not, start it.

Reference the [Managing Worker Service](#managing-worker-service) section to see if the Storage service is running. If not, start it.

#### 2. Check if issue persists

If the issue wasn't resolved by restarting the backend services, that means the web app cannot reach the backend API for some reason. A system admin will need to investigate further. The first thing to check is ports that the Storage and Worker services are listening on. Those ports should be open in the server's firewall configuration.

### Application Database Not Responding

If the Application Database is not responding to network requests, it is either unreachable (network issue), not running (mongoDB or server issue), or PeerPresents is not configured properly (PeerPresents setup issue).

#### 1. Is it running?

First thing to check is if you can log into the server and check the status of the database (MongoDB). 

After logging into the server you can run this command check if MongoDB is running:

```
$ systemctl status mongod
```

If is is running the output will contain a line that says, "Active: active (running)". The output should look similar to this:

```
● mongod.service - MongoDB Database Server
   Loaded: loaded (/usr/lib/systemd/system/mongod.service; enabled; vendor preset: disabled)
   Active: active (running) since Tue 2020-05-26 13:44:14 EDT; 2 weeks 0 days ago
     Docs: https://docs.mongodb.org/manual
 Main PID: 128708 (mongod)
   Memory: 236.3M
   CGroup: /system.slice/mongod.service
           └─128708 /usr/bin/mongod -f /etc/mongod.conf
```

For more details on managing mongoDB on the server see [Managing Application Database](#managing-application-database). 

If it is not running you should try starting it again. If it keeps failing to start and stay running there is something wrong with the mongodb configuration or server.

#### 2. Is it configured properly?

Make sure the Storage service is using a good database config (`PeerPresents/storage/app/config/ppdb_conf.js`) with accurate information. See [Configure MongoDB for PeerPresents](#configure-mongoDB-for-peerpresents) for details on verifying the information in the database config file. If the configuration information does not match, modify it accordingly and try starting the mongodb service again.

#### 3. Is it reachable on the network?

If mongodb is running and everything seems configured correctly, but the application is still not getting responses from the database then there is likely a networking issue. A system admin would have to troubleshoot the connection between the Storage service and the MongoDb instance.
