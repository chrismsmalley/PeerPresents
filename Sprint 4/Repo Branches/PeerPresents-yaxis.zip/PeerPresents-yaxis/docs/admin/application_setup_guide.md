# Application Setup Guide

## PeerPresents Setup

This guide assumes the server is already prepared according to the Server Setup Guide. With the server ready to go, your next need to setup the PeerPresents application.

## Table of Contents

1. [Initial Setup](#initial-setup)
2. [Configuration](#configuration)
3. [Running the Application](#running-the-application)

### Initial Setup

Log in as the `peerpresents` user. You will install PeerPresents from its source code hosted on [Github](https://github.com/Ludolab/PeerPresents).

#### 1. Clone Source Repository

You will download the source code into the directory: `/home/peerpresents/src/`

Change to that directory, or create it if it doesn't already exist.

After you are in the `src/` directory, run the following command to clone the repository:

```
$ git clone https://github.com/Ludolab/PeerPresents
```

**Note:** You will need read access to the repo to successfully down it. Talk to technical or management staff if you require access.

This will create a new directory: `PeerPresents`

**Check which branch** you need. Typically you will be using the `master` branch, which is set by default. But for testing you often want to use the `dev` branch.

Use this command to see what branch you currently are on:

```
$ git branch
```

If you need to change the branch use the `checkout` command. E.g. to change to the `dev` branch, run the command:

```
$ git checkout dev
```

#### 2. Install Components

Now that all the source code is available on the machine you can start install the components as the `peerpresents` user.

##### A. Storage

Enter the directory: `PeerPresents/storage/`

Install with:

```
$ npm install
```

##### B. Worker

Enter the directory: `PeerPresents/backend_worker/`

Install with:

```
$ npm install
```

##### C. Master

Enter the directory: `PeerPresents/backend_master/`

Install with:

```
$ npm install
```

##### D. Frontend

Enter the directory: `PeerPresents/frontend/src`

Install with:

```
$ npm install
```

The frontend uses `expo-cli` which needs to be installed by the `root` user. Install it by running:

```
# npm install --global expo-cli
```

Build the component for web:

```
$ expo build:web
```

### Configuration

#### 1. Setup SSL

#### 2. Configure Components

In order to keep the services running you will need the node package `forever` installed. Install it as the `root` user with the command:

```
npm install --global forever
```

##### A. Storage

##### B. Worker

// copy api config

```
$ cp ~/peerpresents_conf/api_conf.js ~/src/PeerPresents/backend_worker/config/api_conf.js

$ cp ~/peerpresents_conf/api_conf.js ~/src/PeerPresents/storage/config/api_conf.js
```

// copy database config

```
$ cp ~/peerpresents_conf/ppdb_conf.js ~/src/PeerPresents/storage/config/ppdb_conf.js
```



// setup running as service

https://stackoverflow.com/questions/4018154/how-do-i-run-a-node-js-app-as-a-background-service

```
[Unit]
Description=PeerPresents_Worker

[Service]
ExecStart=/home/peerpresents/src/PeerPresents/backend_worker/start.sh
Restart=always
User=nobody
Group=nobody
Environment=PATH=/usr/bin:/usr/local/bin
Environment=NODE_ENV=production
WorkingDirectory=/home/peerpresents/src/PeerPresents/backend_worker

[Install]
WantedBy=multi-user.target
```



##### C. Master

##### D. Frontend

Deploy the web build to the web server.

You will need to copy the folder `/home/peerpresents/src/PeerPresents/frontend/src/web-build/`

to `/usr/share/nginx/html/`. The web server is configured to serve files in: `/usr/share/nginx/html/web-build/`

Assuming you already built the frontend for web deployment, run this command as the `root` user:

```
# cp -r /home/peerpresents/src/PeerPresents/frontend/src/web-build/ /usr/share/nginx/html/
```



### Running the Application

#### Start Components

##### A. Storage

**Steps to run as a service (server environment)**

1. Run the start script:

   ```
   $ cd ~/src/PeerPresents/storage/
   $./start.sh
   ```

3. Check it is running using the `forever` command:

   ```
   $ forever list
   ```

   You should see a uid of "storage" in the output. E.g.:

   ```
   info:    Forever processes running
   data:        uid     command                               script   forever pid   id logfile                                 uptime
   data:    [0] storage /opt/node-v12.17.0-linux-x64/bin/node index.js 21145   21152    /home/peerpresents/.forever/storage.log 0:0:0:1.303
   ```

**Steps to run locally (laptop, etc.)**

2. Run the service in a terminal
   1. cd into PeerPresents/storage/
   2. run `npm install`
   3. run `npm start`
3. Storage API Server should start on your local machine on the configured port

##### B. Worker

**Steps to run as a service (server environment)**

1. Run the start script:

   ```
   $ cd ~/src/PeerPresents/backend_worker/
   $./start.sh
   ```

2. Check it is running using the `forever` command:

   ```
   $ forever list
   ```

   You should see a uid of "worker" in the output. E.g.:

   ```
   info:    Forever processes running
   data:        uid    command                               script   forever pid   id logfile                                uptime
   data:    [0] worker /opt/node-v12.17.0-linux-x64/bin/node index.js 21237   21244    /home/peerpresents/.forever/worker.log 0:0:0:1.618
   ```

**Steps to run locally (laptop, etc.)**

1. Replace the fake config file with a test environment config file
   1. Copy the `api_conf.js` file from Box folder, "Peer Presents Credentials"
   2. Replace PeerPresents/backend_worker/config/api_conf.js
2. Run the service in a terminal
   1. cd into PeerPresents/backend_worker/
   2. run `npm install`
   3. run `npm start`
3. Backend API Server should start on your local machine on port 3010. You can send API requests to `localhost:3010/`

##### C. Master

The Alpha version doesn't use a master service- it only uses 1 worker instance.

##### D. Frontend

The Frontend is a static file served to client web browsers via the configured web server.
