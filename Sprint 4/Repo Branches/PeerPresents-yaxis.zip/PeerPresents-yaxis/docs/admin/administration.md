# Administration Guide

The guide contains just about everything you need to know to keep the environments update-to-date. If you need to know how to setup a new environment, see the Server Setup Guide.

## Table of Contents
1. [Infrastructure](#infrastructure)
2. [Maintaining Environment](#maintaining-the-environment)

## Infrastructure

PeerPresents environments are virtual machines (VMs) hosted by the CMU [Campus Cloud](https://www.cmu.edu/computing/services/infrastructure/server/campus-cloud/index.html) service. Details about the service and the associated account can be found in the infrastructure plan. All environments should be nearly identical.

### Test Environment

#### Description

The test environment is used to host test builds of the PeerPresents application. This environment should be used for testing the application before deploying it to the production environment.

**Operating System**: CentOS 8

#### Server Access

For most purposes the server can be accessed via SSH. Check the Campus Cloud documentation for details on how to access the available server management tools.

**Domain**: peerpresents-test.andrew.cmu.edu

Login credentials are stored in the "Peer Presents Credentials" folder on Box.

```
$ ssh peerpresents@peerpresents-test.andrew.cmu.edu
```

### Production Environment

#### Description

A production environment will be created nearing the end of the Beta phase of development. It should be nearly identical to the test environment.

The production environment is used to host the live PeerPresents application.

#### Server Access

**Domain**: peerpresents.andrew.cmu.edu

Login credentials are stored in the "Peer Presents Credentials" folder on Box.

```
$ ssh peerpresents@peerpresents-test.andrew.cmu.edu
```

## Maintaining the Environment

The sections below describe how to do typical maintenance tasks for the PeerPresents environments.

#### Switching to Root user

For a many tasks you will need to run as the `root` user. The `root` user has full access to the system, so take proper precautions before running commands.

To switch to the `root` user run the command below. You will then be prompted for the root password.

```
$ su
```

After you successfully enter the password you'll be the `root` user instead of `peerpresents`.

Change back to `peerpresents` user by running the command:

```
# exit
```

#### Updating System

Log in as the root user and run the follow command:

```
# dnf update -y
```

#### Nginx 

##### Management

You can use the `systemctl` command as the root user to manage the Nginx process.

To stop the web server:

```
# systemctl stop nginx
```

To start the web server:

```
# systemctl start nginx
```

To stop and then start up again:

```
# systemctl restart nginx
```

To reload configurations without dropping connections:

```
# systemctl reload nginx
```

To disable auto-start on system boot:

```
# systemctl disable nginx
```

To enable auto-start on system boot:

```
# systemctl enable nginx
```

##### Important Files and Directories

Now that you know how to manage the Nginx service, you should take a few minutes to familiarize yourself with a few important directories and files.

###### Content

- `/usr/share/nginx/html`: The actual web content, which by default only consists of the default Nginx page you saw earlier, is served out of the `/usr/share/nginx/html` directory. This can be changed by altering Nginx configuration files.

###### Server Configuration

- `/etc/nginx`: The Nginx configuration directory. All of the Nginx configuration files reside here.
- `/etc/nginx/nginx.conf`: The main Nginx configuration file. This can be modified to make changes to the Nginx global configuration.
- `/etc/nginx/conf.d/`: This directory contains server block configuration files, where you can define the websites that are hosted within Nginx. A typical approach is to have each website in a separate file that is named after the website’s domain name, such as `your_domain.conf`.

###### Server Logs

- `/var/log/nginx/access.log`: Every request to your web server is recorded in this log file unless Nginx is configured to do otherwise.
- `/var/log/nginx/error.log`: Any Nginx errors will be recorded in this log.

#### Renewing SSL Certs

If the SSL certificates have expired, you will need to generate new ones. Run the following command as the `root` user to generate new certs:

```
# certbot --nginx
```

That command will save the certificates and key in the `/etc/letsencrypt/live/` directory. However it should automatically config Nginx to use the new certs.

#### Managing PeerPresents Application

For a quick reference on typical tasks for managing the application, see the [Quick Guide](app_quick_guide.md).

For detailed instructions on how to install, configure, and run the application, see the [Application Setup Guide](application_setup_guide.md).

#### Managing Application Database

TODO [stop|start|status] service
