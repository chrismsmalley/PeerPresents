
import React, { Component } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Colors } from '../global/Constants';
import { Picker } from "@react-native-picker/picker";
import { VictoryBar, VictoryChart, VictoryAxis, VictoryGroup } from "victory";
import window from "../global/Layout";
import GraphsContainer from './GraphsContainer';
import { getAllDatasetIDs, getDataset, getGraph } from '../custom-modules/backendAPI';



export default class Graph extends Component {

  constructor(props) {
    super(props);

    this.state = {
      titleVariable: this.props.item[0],
      totalAverageVariable: this.props.item[1],
      personTeamVariable: this.props.item[2],

      graphList: [], // not used
      sessionList: [], // not used
    }
  }
  
  componentDidMount() {

  }

 // Test Data y axis
  sessionsData = [
     { session: "Game Design Project 1" },
     { session: "Final Project" },
     { session: "Documentation Design Final" },
  ];

  // // Test Data x axis
  graphData = [
    [
      { x: 1, y: 6 },
      { x: 2, y: 2 },
      { x: 3, y: 4},
    ],
    [
      { x: 1, y: 4 },
      { x: 2, y: 8 },
      { x: 3, y: 5 },
    ],
    [
      { x: 1, y: 2 },
      { x: 2, y: 6 },
      { x: 3, y: 8 },
    ],
    [
      { x: 1, y: 2 },
      { x: 2, y: 2 },
      { x: 3, y: 1 },
    ],
    [
      { x: 1, y: 1 },
      { x: 2, y: 4 },
      { x: 3, y: 6 },
    ],
    [
      { x: 1, y: 1 },
      { x: 2, y: 6 },
      { x: 3, y: 4 },
    ],
  ];



  render() {

  //   const { totalAverageVariable } = this.state; // destructure the state variable
  //   const graphData = this.props.graphData;

  //   // Calculate the total or average based on the selected state variable
  //   const data = Object.values(this.props.sessionsData).map((session, index) => {
  //    const values = graphData[index].map((datum) => datum.y); // isolate the "y" variable
  //    return {
  //     x: index + 1,
  //     //if "true" then give total - "false" give average
  //     y: totalAverageVariable === "total" ? values.reduce((a, b) => a + b) : values.reduce((a, b) => a + b) / values.length,
  //   }
  // })

  const { totalAverageVariable } = this.state;

  // Calculate the total or average based on the selected state variable
  const data = Object.values(this.props.sessionsData).map((session, index) => {
    const values = this.graphData[index].map((datum) => datum.y); // isolate the "y" variable
    return {
      x: index + 1,
      y: totalAverageVariable === "total" ? values.reduce((a, b) => a + b) : values.reduce((a, b) => a + b) / values.length,
    }
  })

    return (
      <View style={styles.graph}>
        <Text style={styles.graphText}>Select variables to visualize</Text>
        <Picker
          selectedValue={this.state.titleVariable}
          onValueChange={(value) =>
            this.setState({titleVariable: value})
          }
          style={styles.picker}
          placeholder={{ label: "Select data type" }}
        >
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Questions Asked"
            value="questionNum"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Textual Feedbacks to Questions"
            value="textFeedback"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Emoji Reactions to Feedbacks"
            value="emoji"
          />
          <Picker.Item
            style={styles.pickerItem}
            label="Number of Star Rating Reactions to Feedbacks"
            value="star"
          />
        </Picker>

         
       

        {/* Y-Axis Button */}
        <View style={styles.yAxisButton}>
          <Picker
          selectedValue={totalAverageVariable}
          onValueChange={(value) =>
          this.setState({totalAverageVariable: value})
          }
          style={styles.yAxisPicker}
          placeholder={{ label: "Total or Average?" }}
          >
          <Picker.Item label="Total" value="total" />
          <Picker.Item label="Average" value="average" />
        </Picker>
        </View>

         

        {/* Graph */}
        <VictoryChart
          height={window.window.height / 2}
          width={window.window.width / 2}
          domainPadding={{x:25}}
          padding={{top:50, bottom:50, right:0, left:50}}
          animate={{
            duration: 2000,
            onLoad: { duration: 1000 }
          }}
          //domainPadding={{ x: 10, y: 10 }}

        >
          <VictoryAxis
            // tickValues specifies both the number of ticks and where
            // they are placed on the axis
            label = "Sessions"
            tickValues={this.props.sessionList}
            tickFormat={(x) => x}  //chris changed so that is not hardcoded to 5. was => x=5
            //tickCount={this.props.sessionList.length}
          />
          <VictoryAxis
            dependentAxis
            // tickFormat specifies how ticks should be displayed
            tickFormat={(y) => y}

          />

          
          <VictoryGroup
                offset={60}
                colorScale={"blue"}
              >
                {data.map((datum, index) => (
                  <VictoryBar
                    key={index.toString()} // Updated key value assignment
                    barRatio={0.8}
                    barWidth={40}
                    alignment='middle'
                    data={[datum]} // Use the calculated data
                  />
                ))}


          </VictoryGroup>
        </VictoryChart>
        <View style={styles.subPickers}>
          <Picker
            selectedValue={this.state.totalAverageVariable} 
            onValueChange={(value) =>
              this.setState({totalAverageVariable: value})
            }
            style={styles.subPicker}
            placeholder={{ label: "select variable" }}
          >
            <Picker.Item
              style={styles.subPickerItem}
              label="total"
              value="total"
            />
            <Picker.Item
              style={styles.subPickerItem}
              label="average"
              value="average"
            />
          </Picker>
          <Picker
            selectedValue={this.state.personTeamVariable}
            onValueChange={(value) =>
              this.setState({personTeamVariable: value})
            }
            style={styles.subPicker}
            placeholder={{ label: "select variable" }}
          >
            <Picker.Item
              style={styles.subPickerItem}
              label="from person"
              value="from person"
            />
            <Picker.Item
              style={styles.subPickerItem}
              label="from team"
              value="from team"
            />
          </Picker>
        </View>
      </View>
    )
  }
}


const styles = StyleSheet.create({
  graph: {
    marginTop: 30,
    borderRadius: 30,
    marginBottom: 25,
    backgroundColor: "white",
    width: window.window.width / 1.5,
    height: window.window.height / 1.1,
  },
  graphText: {
    fontSize: 12,
    color: Colors.ppGreyText,
    marginTop: 20,
    marginLeft: 30,
  },
  picker: {
    marginTop: 30,
    marginLeft: 30,
    marginRight: 30,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: Colors.ppGreyText,
    fontSize: window.window.height / 50,
    width: window.window.width / 1.6,
    height: window.window.height / 10,
    fontSize: 20,
    fontWeight: "bold",
    color: Colors.ppTextColor,
    paddingLeft: 10,
  },
  pickerItem: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 30,
    color: Colors.ppTextColor,
  },
  subPickers: {
    marginVertical: 10,
    marginLeft: 30,
    marginRight: 30,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  subPicker: {
    borderColor: Colors.ppGreyText,
    padding: 10,
    borderWidth: 1,
    borderRadius: 10,
    fontSize: 18,
  },
});





// put back

{/* <VictoryGroup
offset={60}//window.window.width / 70}
colorScale={"blue"}
>

{Object.values(this.props.sessionQuestionsDict).map((data, index) => (
  <VictoryBar
    key={Object.toString} // assign a unique key value - need to change to data.toString ?
    barRatio={0.8}
    barWidth={40}
    alignment='middle'
    data={[index, data]} x={0} y={1}
  />
))}
 */}
