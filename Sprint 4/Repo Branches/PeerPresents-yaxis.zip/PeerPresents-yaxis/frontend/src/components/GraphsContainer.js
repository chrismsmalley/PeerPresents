import React, { Component } from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { Colors } from "../global/Constants";
import window from "../global/Layout";
import Graph from './Graph';
import MainButton from './MainButton';
import { getDataset, getGraph, getPresentation, getSession } from '../custom-modules/backendAPI';
import { FlatList } from 'react-native-gesture-handler';

export default class  GraphsContainer extends Component {

  constructor(props) {
    super(props);
    this.state = {
      graphList: [
        // graphList initially empty
        // ["questionNum", "total", "from team", "unique_id_1"],
        // ["questionNum", "average", "from person", "unique_id_2"],
        // ["questionNum", "average", "from team", "unique_id_3"],
      ],
      sessionList: [],
      sessionQuestionsDict: {},
      questionList: [],
    }
  }



  componentDidMount() {
    // Get all graphs for this dataset and populate them as Graph
    // components under render

    document.addEventListener("addGraphButtonClick", this.addGraph); // runs addGraph() on event

    getDataset(this.props.dataset_id, true).then(_ds => {
      _ds.session_list.forEach(session_id => {
        getSession(session_id, true).then(_sess => {

          _sess.presentation_list.forEach(presentation_id => {
            getPresentation(presentation_id, true).then(_presentation => {

              let newQuestionCount = _presentation.question_list.length;

              if(this.state.sessionQuestionsDict.hasOwnProperty(_presentation.session_id) == false) {
                this.state.sessionQuestionsDict[_presentation.session_id] = 0;
              }

              this.state.sessionQuestionsDict[_presentation.session_id] = this.state.sessionQuestionsDict[_presentation.session_id] + newQuestionCount;

              let newSession = _sess.title;

              let new_list = this.state.sessionList;

              new_list.push(newSession);

              this.setState({ sessionList : new_list });

            })
          })
        })
      })

      /* try this - iterate through _ds.graph_list calling addGraph()
      _ds.graph_list.forEach(graph_id => { // Make this seperate function to respond to add graph button?
        getGraph(graph_id, true).then(_graph => {
          let newGraph = [_graph.title_variable,
                          _graph.total_average_variable,
                          _graph.person_team_variable]
          // let newGraphList = this.state.graphList.push(newGraph);
          // this.setState({ graphList : newGraphList });
          this.setState(prevState => ({ graph_list: [...prevState, newGraph] }))
        })
      })
      //_ds.graph_list.forEach(graph_id => this.addGraph());
      */
    })
  }

  // to-do: accept getGraph(graph_id, true), set state with new ["title", "total/average", "person/team"]
  // update id assignment logic if graph deletion is implemented
  addGraph = () => {
    let newGraph = [
      "static graph title",
      "static graph total/average",
      "static graph person/team",
      this.state.graphList.length.toString()] // last value is a key == (graphsList.indexOf(thisGraph) + 1), must be string
    this.setState(prevState => ({
      graphList: [...prevState.graphList, newGraph],
    }));
  }

  render() {
    return (
      <><FlatList
        data={this.state.graphList}
        extraData={this.state.graphList}
        scrollEnabled={true}
        keyExtractor={(item) => item[item.length - 1] } // key is the last element of item (a graph[] in graphList[])
        renderItem={({ item }) => (
          <Graph item={item} graphList={this.state.graphList} sessionList={this.state.sessionList} sessionQuestionsDict={this.state.sessionQuestionsDict} />
        )} />
      </>
    )
  }
}

const styles = StyleSheet.create({

});
