const {createDB} = require('./managers/mongodbManager');

createDB();
