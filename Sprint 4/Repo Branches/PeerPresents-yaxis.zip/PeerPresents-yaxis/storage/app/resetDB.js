// const {connectToDB, createDB, clearDB} = require('./managers/mongodbManager');


// connectToDB()
// .then(() => {
//     clearDB()
//     .then((res) => {
//         createDB()
//     }).catch((err) => {
//         console.error(err);
//     })
// })


