const {
    connectToDB,
    disconnectFromDB,
    createDB,
    clearDB,
    createEntity,
    readEntity,
    updateEntity,
    deleteEntity,
    listEntities
} = require('../app/managers/mongodbManager');

const {
    UserSchema,
    CourseSchema,
    SessionSchema,
    PresentationSchema,
    QuestionSchema,
    ResponseSchema,
    UpvoteSchema,
    ReactSchema,
    StarSchema,
    TagSchema
} = require('../app/schema/data_models.js')

const writeUser = async (model) => {
    try {
        let res = await createEntity("user", model);
    } catch(err) {
        console.error(err);
        return false;
    }
    return true;
}

/* Templates for db entities */
const aUser = {
    _id: "1",
    username: "blearn",
    email: "blearn@andrew.cmu.edu",
    roles: ["presenter", "listener"],
    course_list: [],
    session_list: [],
    presentation_list: []
}


const aCourse = {
    _id: "1",
    title: "Test Course",
    code: "101",
    semester: "Fall",
    instructor_list: [],
    student_list: [],
    session_list: []
}

const aSession = {
    _id: "1",
    course_id: "1",
    title: "Test Session",
    presentation_list: [],
    start_datetime: Date.now(),
    end_datetime: Date.now()
}

const aPresentation = {
    _id: "1",
    session_id: "1",
    title: "Test Presentation",
    presenter_list: [],
    listener_list: [],
    question_list: [],
}

const aQuestion = {
    _id: "1",
    presentation_id: "1",
    presenter_id: "1",
    text: "Example text.",
    response_list: [],
}

const aResponse = {
    _id: "1",
    listener_id: "1",
    question_id: "1",
    presentation_id: "1",
    text: "Example text.",
    upvote_list: [],
    react_list: [],
    star_list: [],
    tag_list: [],
    publish_time: Date.now()
}

const aUpvote = {
    _id: "1",
    listener_id: "1",
    response_id: "1"
}
const aReact = {
    _id: "1",
    listener_id: "1",
    response_id: "1",
    react_code: "1"
}
const aStar = {
    _id: "1",
    presenter_id: "1",
    response_id: "1",
    presentation_id: "1",
    value: 0
}
const aTag = {
    _id: "1",
    presenter_id: "1",
    response_id: "1",
    presentation_id: "1",
    text: "tag"
}


let insertTestData = async () => {
    /* Insert 4 Students */
    let s1 = Object.assign({}, aUser)
    let s2 = Object.assign({}, aUser)
    let s3 = Object.assign({}, aUser)
    let s4 = Object.assign({}, aUser)

    s1._id = "5eb2132cc60d3098c8ccb883"
    s1.username = "KellyJ"
    s1.email = "kellyj@andrew.cmu.edu"

    s2.username = "James"
    s2.email = "james@andrew.cmu.edu"

    s3.username = "TinaF"
    s3.email = "tinaf@andrew.cmu.edu"

    s4.username = "AdamA"
    s4.email = "adama@andrew.cmu.edu"

    try {
        //s1._id = await updateEntity("user", s1._id, s1);
        s1._id = await createEntity("user", s1);
        s2._id = await createEntity("user", s2);
        s3._id = await createEntity("user", s3);
        s4._id = await createEntity("user", s4);
    } catch(err) {
        console.error(err);
        return false;
    }

    /* Insert 4 Instructors */
    let i1 = Object.assign({}, aUser) 
    let i2 = Object.assign({}, aUser) 
    let i3 = Object.assign({}, aUser) 
    let i4 = Object.assign({}, aUser)

    i1.username = "AlbusDumbledore"
    i1.email = "dumbledore@andrew.cmu.edu"
    i1.roles = ["instructor"]

    i2.username = "SeverusSnape"
    i2.email = "snape@andrew.cmu.edu"
    i2.roles = ["instructor"]

    i3.username = "VanHelsing"
    i3.email = "helsingv@andrew.cmu.edu"
    i3.roles = ["instructor"]

    i4.username = "WillDyer"
    i4.email = "dyerw@andrew.cmu.edu"
    i4.roles = ["instructor"]

    try {
        i1._id = await createEntity("user", i1);
        i2._id = await createEntity("user", i2);
        i3._id = await createEntity("user", i3);
        i4._id = await createEntity("user", i4);
    } catch(err) {
        console.error(err);
        return false;
    }

    /* Insert 4 Courses */
    let c1 = Object.assign({}, aCourse)
    let c2 = Object.assign({}, aCourse)
    let c3 = Object.assign({}, aCourse)
    let c4 = Object.assign({}, aCourse)

    c1.title = "Game Design"
    c1.code = "53-409"
    c1.instructor_list = [i1._id]
    c1.student_list = [s1._id, s2._id, s3._id]

    c2.title = "Design Educational Games"
    c2.code = "05-418"
    c2.instructor_list = [i2._id]
    c2.student_list = [s4._id]

    c3.title = "Transition Design"
    c3.code = "51-400"
    c3.instructor_list = [i3._id]
    c3.student_list = [s2._id, s4._id]

    c4.title = "Interaction Design Overview"
    c4.code = "05-392"
    c4.instructor_list = [i4._id]
    c4.student_list = [s1._id, s2._id, s3._id, s4._id]

    try {
        c1._id = await createEntity("course", c1);
        c2._id = await createEntity("course", c2);
        c3._id = await createEntity("course", c3);
        c4._id = await createEntity("course", c4);
    } catch(err) {
        console.error(err);
        return false;
    }


    /* Insert 2 Sessions per Course */
    let sess1 = Object.assign({}, aSession)
    let sess2 = Object.assign({}, aSession)
    let sess3 = Object.assign({}, aSession)
    let sess4 = Object.assign({}, aSession)
    let sess5 = Object.assign({}, aSession)
    let sess6 = Object.assign({}, aSession)
    let sess7 = Object.assign({}, aSession)
    let sess8 = Object.assign({}, aSession)

    sess1.course_id = c1._id
    sess1.title = "Session 1"
    sess2.course_id = c1._id
    sess2.title = "Session 2"

    sess3.course_id = c2._id
    sess3.title = "Project 1"
    sess4.course_id = c2._id
    sess4.title = "Project 2"

    sess5.course_id = c3._id
    sess5.title = "Mid-Term"
    sess6.course_id = c3._id
    sess6.title = "Final"

    sess7.course_id = c4._id
    sess7.title = "First Presentation"
    sess8.course_id = c4._id
    sess8.title = "Second Pressentation"

    try {
        sess1._id = await createEntity("session", sess1)
        sess2._id = await createEntity("session", sess2)
        sess3._id = await createEntity("session", sess3)
        sess4._id = await createEntity("session", sess4)
        sess5._id = await createEntity("session", sess5)
        sess6._id = await createEntity("session", sess6)
        sess7._id = await createEntity("session", sess7)
        sess8._id = await createEntity("session", sess8)
    } catch(err) {
        console.error(err)
        return false;
    }

    // Update Courses with pointers to Sessions

    c1.session_list = [sess1._id, sess2._id]
    c2.session_list = [sess3._id, sess4._id]
    c3.session_list = [sess5._id, sess6._id]
    c4.session_list = [sess7._id, sess8._id]

    try {
        await updateEntity("course", c1._id, c1);
        await updateEntity("course", c2._id, c2);
        await updateEntity("course", c3._id, c3);
        await updateEntity("course", c4._id, c4);
    } catch(err) {
        console.error(err);
        return false;
    }

    /* Insert 0-2 Presentations per Session */
    let pres1 = Object.assign({}, aPresentation)
    let pres2 = Object.assign({}, aPresentation)
    let pres3 = Object.assign({}, aPresentation)
    let pres4 = Object.assign({}, aPresentation)
    let pres5 = Object.assign({}, aPresentation)
    let pres6 = Object.assign({}, aPresentation)
    let pres7 = Object.assign({}, aPresentation)
    let pres8 = Object.assign({}, aPresentation)

    pres1.title = "Presentation One"
    pres1.session_id = sess1._id
    pres1.presenter_list = [s1._id, s2._id, s3._id]

    pres2.title = "Presentation Two"
    pres2.session_id = sess2._id
    pres2.presenter_list = [s1._id, s2._id, s3._id]

    pres3.title = "Presentation Three"
    pres3.session_id = sess1._id
    pres3.presenter_list = [s4._id]

    pres4.title = "James' Presentation"
    pres4.session_id = sess5._id
    pres4.presenter_list = [s2._id]

    pres5.title = "Adam's Presentation"
    pres5.session_id = sess5._id
    pres5.presenter_list = [s4._id]

    pres6.title = "First Presentation - Team 1"
    pres6.session_id = sess7._id
    pres6.presenter_list = [s1._id, s2._id]

    pres7.title = "First Presentation - Team 2"
    pres7.session_id = sess7._id
    pres7.presenter_list = [s3._id]

    pres8.title = "First Presentation - Team 3"
    pres8.session_id = sess7._id
    pres8.presenter_list = [s4._id]

    try {
        pres1._id = await createEntity("presentation", pres1);
        pres2._id = await createEntity("presentation", pres2);
        pres3._id = await createEntity("presentation", pres3);
        pres4._id = await createEntity("presentation", pres4);
        pres5._id = await createEntity("presentation", pres5);
        pres6._id = await createEntity("presentation", pres6);
        pres7._id = await createEntity("presentation", pres7);
        pres8._id = await createEntity("presentation", pres8);
    } catch(err) {
        console.error(err);
        return false;
    }


    /* Update students' pointers to Org entities */
    s1.course_list = [c1._id, c4._id]
    s1.session_list = [sess1._id, sess2._id, sess7._id]
    s1.presentation_list = [pres1._id, pres2._id, pres6._id]

    s2.course_list = [c1._id, c3._id, c4._id]
    s2.session_list = [sess1._id, sess2._id, sess5._id, sess7._id]
    s2.presentation_list = [pres1._id, pres2._id, pres4._id, pres6._id]
   
    s3.course_list = [c1._id, c4._id]
    s3.session_list = [sess1._id, sess2._id, sess7._id]
    s3.presentation_list = [pres1._id, pres2._id, pres7._id]
    
    s4.course_list = [c2._id, c3._id, c4._id]
    s4.session_list = [sess1._id, sess3._id, sess5._id, sess7._id]
    s4.presentation_list = [pres3._id, pres5._id, pres8._id]

    try {
        await updateEntity("user", s1._id, s1);
        await updateEntity("user", s2._id, s2);
        await updateEntity("user", s3._id, s3);
        await updateEntity("user", s4._id, s4);
    } catch(err) {
        console.error(err);
        return false;
    }

    /* Update Sessions' pointers to Presentations */
    sess1.presentation_list = [pres1._id, pres3._id]
    sess2.presentation_list = [pres2._id]
    sess3.presentation_list = [pres3._id]
    sess4.presentation_list = []
    sess5.presentation_list = [pres4._id, pres5._id]
    sess6.presentation_list = []
    sess7.presentation_list = [pres6._id, pres7._id, pres8._id]
    sess8.presentation_list = []

    try {
        await updateEntity("session", sess1._id, sess1);
        await updateEntity("session", sess2._id, sess2);
        await updateEntity("session", sess3._id, sess3);
        await updateEntity("session", sess4._id, sess4);
        await updateEntity("session", sess5._id, sess5);
        await updateEntity("session", sess6._id, sess6);
        await updateEntity("session", sess7._id, sess7);
        await updateEntity("session", sess8._id, sess8);
    } catch(err) {
        console.error(err);
        return false;
    }

    /* Insert 0-3 Questions for 3 Presentations */
    let q1 = Object.assign({}, aQuestion)
    q1.presentation_id = pres1._id
    q1.presenter_id = String(s1._id)
    q1.text = "How clear was the introduction?"

    let q2 = Object.assign({}, aQuestion)
    q2.presentation_id = pres1._id
    q2.presenter_id = String(s1._id)
    q2.text = "Was the video necessary?"

    let q3 = Object.assign({}, aQuestion)
    q3.presentation_id = pres4._id
    q3.presenter_id = String(s2._id)
    q3.text = "Was the conclusion clear?"

    let q4 = Object.assign({}, aQuestion)
    q4.presentation_id = pres5._id
    q4.presenter_id = String(s4._id)
    q4.text = "Was the presentation too long?"

    let q5 = Object.assign({}, aQuestion)
    q5.presentation_id = pres3._id
    q5.presenter_id = String(s4._id)
    q5.text = "How clear was the introduction?"

    let q6 = Object.assign({}, aQuestion)
    q6.presentation_id = pres3._id
    q6.presenter_id = String(s4._id)
    q6.text = "Was the video necessary?"

    // create Questions
    try {
        q1._id = await createEntity("question", q1)
        q2._id = await createEntity("question", q2)
        q3._id = await createEntity("question", q3)
        q4._id = await createEntity("question", q4)
        q5._id = await createEntity("question", q5)
        q6._id = await createEntity("question", q6)
    } catch(err) {
        console.error(err)
        return false
    }

    // update Presentations w/ Question pointers
    try {
        await updateEntity("presentation", pres1._id, {question_list: [q1._id, q2._id]} )
        await updateEntity("presentation", pres3._id, {question_list: [q5._id, q6._id]} )
        await updateEntity("presentation", pres4._id, {question_list: [q3._id]} )
        await updateEntity("presentation", pres5._id, {question_list: [q4._id]} )
    } catch(err) {
        console.error(err)
        return false
    }

    /* Insert 0-2 Responses per Question */
    let res1 = Object.assign({}, aResponse)
    res1.question_id = q1._id
    res1.presentation_id = pres1._id
    res1.listener_id = String(s4._id)
    res1.text = "The concept of Identity is one that is really interesting and really lets you get in their head."

    let res2 = Object.assign({}, aResponse)
    res2.question_id = q1._id
    res2.presentation_id = pres1._id
    res2.listener_id = String(s4._id)
    res2.text = "How do you implement controls and potential game strategies that can accommodate all the different challenges the players face?"

    let res3 = Object.assign({}, aResponse)
    res3.question_id = q3._id
    res3.presentation_id = pres4._id
    res3.listener_id = String(s3._id)
    res3.text = "needs more specific mechanics before more judgments about idea can be made"

    let res4 = Object.assign({}, aResponse)
    res4.question_id = q3._id
    res4.presentation_id = pres4._id
    res4.listener_id = String(s1._id)
    res4.text = "Every 5 minutes or so a congress occurs where people can propose and argue their legislation? If they don't show up and propose and vote, then they cannot get their legislation passed so they are encouraged to show up?"

    let res5 = Object.assign({}, aResponse)
    res5.question_id = q5._id
    res5.presentation_id = pres3._id
    res5.listener_id = String(s1._id)
    res5.text = "The concept of Identity is one that is really interesting and really lets you get in their head."

    let res6 = Object.assign({}, aResponse)
    res6.question_id = q5._id
    res6.presentation_id = pres3._id
    res6.listener_id = String(s2._id)
    res6.text = "How do you implement controls and potential game strategies that can accommodate all the different challenges the players face?"



    // create Responses
    try {
        res1._id = await createEntity("response", res1)
        res2._id = await createEntity("response", res2)
        res3._id = await createEntity("response", res3)
        res4._id = await createEntity("response", res4)
        res5._id = await createEntity("response", res5)
        res6._id = await createEntity("response", res6)
    } catch(err) {
        console.error(err)
        return false
    }

    /* Insert 0-2 Reacts, Tags, Stars per Response */
    let react1 = Object.assign({}, aReact)
    react1.response_id = res1._id
    react1.listener_id = String(s1._id)
    react1.react_code = "1"

    let react2 = Object.assign({}, aReact)
    react2.response_id = res1._id
    react2.listener_id = String(s2._id)
    react2.react_code = "2"

    let react3 = Object.assign({}, aReact)
    react3.response_id = res2._id
    react3.listener_id = String(s1._id)
    react3.react_code = "4"

    let react4 = Object.assign({}, aReact)
    react4.response_id = res1._id
    react4.listener_id = String(s2._id)
    react4.react_code = "1"

    let react5 = Object.assign({}, aReact)
    react5.response_id = res2._id
    react5.listener_id = String(s1._id)
    react5.react_code = "3"

    let star1 = Object.assign({}, aStar)
    star1.response_id = res2._id
    star1.presenter_id = String(s2._id)
    star1.presentation_id = pres4._id
    star1.value = 3

    let tag1 = Object.assign({}, aTag)
    tag1.response_id = res2._id
    tag1.presenter_id = String(s2._id)
    tag1.presentation_id = pres4._id
    tag1.text = "interesting"


    let react6 = Object.assign({}, aReact)
    react6.response_id = res5._id
    react6.listener_id = String(s1._id)
    react6.react_code = "1"

    let react7 = Object.assign({}, aReact)
    react7.response_id = res5._id
    react7.listener_id = String(s2._id)
    react7.react_code = "2"

    let react8 = Object.assign({}, aReact)
    react8.response_id = res6._id
    react8.listener_id = String(s1._id)
    react8.react_code = "4"

    let star2 = Object.assign({}, aStar)
    star2.response_id = res6._id
    star2.presenter_id = String(s2._id)
    star2.presentation_id = pres3._id
    star2.value = 3

    let tag2 = Object.assign({}, aTag)
    tag2.response_id = res6._id
    tag2.presenter_id = String(s2._id)
    tag2.presentation_id = pres3._id
    tag2.text = "interesting"

    // create Reacts
    try {
        react1._id = await createEntity("react", react1)
        react2._id = await createEntity("react", react2)
        react3._id = await createEntity("react", react3)
        react4._id = await createEntity("react", react4)
        react5._id = await createEntity("react", react5)
        star1._id = await createEntity("star",  star1)
        tag1._id = await createEntity("tag",   tag1)
        react6._id = await createEntity("react", react6)
        react7._id = await createEntity("react", react7)
        react8._id = await createEntity("react", react8)
        star2._id = await createEntity("star",  star2)
        tag2._id = await createEntity("tag",  tag2)
    } catch(err) {
        console.error(err)
        return false
    }

    // update Responses with React pointers
    try {
        await updateEntity("response", res1._id, {
            react_list: [react1._id, react2._id, react4._id]
        })
        await updateEntity("response", res2._id, {
            react_list: [react3._id, react5._id],
            star_list: [star1._id],
            tag_list: [tag1._id]
        })
        await updateEntity("response", res5._id, {
            react_list: [react6._id, react7._id]
        })
        await updateEntity("response", res6._id, {
            react_list: [react8._id],
            star_list: [star2._id],
            tag_list: [tag2._id]
        })
    } catch(err) {
        console.error(err)
        return false
    }

    // update Questions with Response pointers
    try {
        await updateEntity("question", q1._id, {
            response_list: [res1._id, res2._id]
        })
        await updateEntity("question", q3._id, {
            response_list: [res3._id, res4._id]
        })
        await updateEntity("question", q5._id, {
            response_list: [res5._id, res6._id]
        })
    } catch(err) {
        console.error(err)
        return false
    } 

    console.log("completed loading test data into database")
    return true;
}

insertTestData()
.then((res) => {
    disconnectFromDB();
}).catch((err) => {
    console.error(err)
    disconnectFromDB();
})

