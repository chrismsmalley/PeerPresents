const rp = require('request-promise-native'),
      api_conf = require('../../config/api_conf.js');

const uri_head = `http://${api_conf.storage.domain}:${api_conf.storage.port}`;

/* Identity API */

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createUser (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/user`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.status = res.statusCode;
            ctx.body = {
                message: res.body.message,
                result: ""
            };
        }
        else {
            ctx.status = 201;
            ctx.body = {
                message: `Created new user.`,
                result: {
                    uri: `/id/${res.body.result.id}`,
                    id: res.body.result.id
                }
            };
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
        ctx.body = {
            message: `error`,
            result: ""
        }
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/id/1"
 */
async function readUser (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.userid;

        // set request options
        let options = {
            uri: `${uri_head}/user/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {    
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.status = 404;
            ctx.body = {
                message: "User not found",
                result: {
                    uri: `/id/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
        } else {
            ctx.status = 200
            ctx.body = {
                message: `User found`,
                result: res.body.result
            }
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/id/3" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateUser (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.userid;

        // set request options
        let options = {
            uri: `${uri_head}/user/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteUser (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.userid;

        // set request options
        let options = {
            uri: `${uri_head}/user/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "User not found",
                result: {
                    uri: `/id/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.status = 204
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}


/**
 * @example curl -XGET "http://localhost:8080/email/example@example.com"
 */
async function readUserByEmail (ctx, next) {
    try {
        // get params
        let _EMAIL = ctx.params.email;

        // set request options
        let options = {
            uri: `${uri_head}/email/${_EMAIL}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {    
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.status = 404;
            ctx.body = {
                message: "User not found",
                result: {
                    uri: `/id/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
        } else {
            ctx.status = 200
            ctx.body = {
                message: `User found`,
                result: res.body.result
            }
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}


/* Presentation API */

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createQuestion (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/question`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new question.`,
                result: {
                    uri: `/presentation/content/question/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createCourse (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error(`request missing parameter: 'model' ${_body}`);
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/course`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new course.`,
                result: {
                    uri: `/presentation/org/course/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createSession (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/session`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            console.error(JSON.stringify(res))
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new session.`,
                result: {
                    uri: `/presentation/org/session/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createPresentation (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/presentation`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new presentation.`,
                result: {
                    uri: `/presentation/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/presentation/content/question/1"
 */
async function readQuestion (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/question/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Question not found",
                result: {
                    uri: `/presentation/content/question/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Question found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/presentation/org/course/1"
 */
async function readCourse (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/course/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Course not found",
                result: {
                    uri: `/presentation/org/course/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Course found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}



/**
 * @example curl -XGET "http://localhost:8080/presentation/org/session/1"
 */
async function readSession (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/session/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Session not found",
                result: {
                    uri: `/presentation/org/session/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Session found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/presentation/org/presentation/1"
 */
async function readPresentation (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/presentation/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Presentation not found",
                result: {
                    uri: `/presentation/org/presentation/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Presentation found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/prsentation/content/question" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateQuestion (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/question/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/presentation/org/course" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateCourse (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/course/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/presentation/org/session" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateSession (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/session/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/presentation/org/presentation" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updatePresentation (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/presentation/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.status = res.statusCode;
            ctx.body = {
                message: res.body.message,
                result: ""
            };
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
        ctx.body = {
            message: "error",
            result: ""
        }
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteQuestion (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        ctx.body = { message: "", result: "" };

        // set request options
        let options = {
            uri: `${uri_head}/question/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.status = 404;
            ctx.body = {
                message: "Question not found",
                result: {
                    uri: `/presentation/content/question/${res.body.result.id}`,
                    id: res.result.id
                }
            }
        } else {
            ctx.status = 204;
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
        ctx.body = {
            message: "error",
            result: ""
        };
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteCourse (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/course/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Course not found",
                result: {
                    uri: `/presentation/org/course/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.status = 204
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteSession (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/session/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Session not found",
                result: {
                    uri: `/presentation/org/session/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.status = 204
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}


/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deletePresentation (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/presentation/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Presentation not found",
                result: {
                    uri: `/presentation/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.status = 204
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/* Live API */

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createLiveSession (ctx, next) {
    try {
        // set given session active
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/session`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new session.`,
                result: {
                    uri: `/live/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteLiveSession (ctx, next) {
    try {
        // set given session as deactive
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/session/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Session not found",
                result: {
                    uri: `/live/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.status = 204
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/* Audience API */

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createUpvote (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/upvote`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new upvote.`,
                result: {
                    uri: `/audience/upvote/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteUpvote (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/upvote/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Upvote not found",
                result: {
                    uri: `/audience/upvote/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.status = 204
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createReact (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/react`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new react.`,
                result: {
                    uri: `/audience/react/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteReact (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/react/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "React not found",
                result: {
                    uri: `/audience/react/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.status = 204
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createStar (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/star`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new star.`,
                result: {
                    uri: `/audience/star/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteStar (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/star/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Star not found",
                result: {
                    uri: `/audience/star/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.status = 204
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createTag (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/tag`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new tag.`,
                result: {
                    uri: `/audience/tag/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteTag (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/tag/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Tag not found",
                result: {
                    uri: `/audience/tag/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.status = 204
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPOST "http://localhost:8080/id/user" -d '{"name":"New record 1"}' -H 'Content-Type: application/json'
 */
async function createResponse (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/response`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new response.`,
                result: {
                    uri: `/audience/response/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function createDataset (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/dataset`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new dataset.`,
                result: {
                    uri: `/audience/dataset/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function createGraph (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        //let _model = JSON.parse(_body.model);
        let _model = _body.model;

        // set request options
        let options = {
            uri: `${uri_head}/graph`,
            method: 'POST',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.body = {
                message: `Created new graph.`,
                result: {
                    uri: `/audience/graph/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 201;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/audience/upvote/1"
 */
async function readUpvote (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/upvote/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Upvote not found",
                result: {
                    uri: `/audience/upvote/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Upvote found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/audience/react/1"
 */
async function readReact (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/react/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "React not found",
                result: {
                    uri: `/audience/react/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `React found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/audience/star/1"
 */
async function readStar (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/star/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Star not found",
                result: {
                    uri: `/audience/star/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Star found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/audience/tag/1"
 */
async function readTag (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/tag/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Tag not found",
                result: {
                    uri: `/audience/tag/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Tag found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/audience/response/1"
 */
async function readResponse (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/response/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Response not found",
                result: {
                    uri: `/audience/response/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Response found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/audience/dataset/1"
 */
async function readDataset (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/dataset/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Dataset not found",
                result: {
                    uri: `/audience/dataset/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Dataset found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/audience/graph/1"
 */
async function readGraph (ctx, next) {
    try {
        // get params
        let _ID = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/graph/${_ID}`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Graph not found",
                result: {
                    uri: `/audience/graph/${res.body.result.id}`,
                    id: res.body.result.id
                }
            }
            ctx.status = 404;
        } else {
            ctx.body = {
                message: `Graph found`,
                result: res.body.result
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/audience/upvote" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateUpvote (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/upvote/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/audience/react" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateReact (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/react/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/audience/star" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateStar (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/star/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/audience/tag" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateTag (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/tag/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/audience/reponse" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateResponse (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/response/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/audience/dataset" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateDataset (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/dataset/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XPUT "http://localhost:8080/audience/graph" -d '{"name":"New record 3"}' -H 'Content-Type: application/json'
 */
async function updateGraph (ctx, next) {
    try {
        // get model param from body
        let _body = ctx.request.body;
        if (!_body.model){
            throw new Error("request missing parameter: 'model'");
        }
        let _model = _body.model;

        let _id = ctx.params.id;

        // set request options
        let options = {
            uri: `${uri_head}/graph/${_id}`,
            method: 'PUT',
            body: {
                model: _model
            },
            resolveWithFullResponse: true,
            simple: false,
            json: true,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        } else if (res.statusCode >= 400) {
            ctx.body = {
                message: res.body.message,
                result: ""
            };
            ctx.status = res.statusCode;
        }
        else {
            ctx.status = 204;
        }
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteResponse (ctx, next) {

    try {
        // get params
        let _ID = ctx.params.id;

        ctx.body = { message: "", result: "" };

        // set request options
        let options = {
            uri: `${uri_head}/response/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.status = 404;
            ctx.body = {
                message: "Response not found",
                result: {
                    uri: `/audience/response/${res.body.result.id}`,
                    id: res.result.id
                }
            }
        } else {
            ctx.status = 204;
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
        ctx.body = {
            message: "error",
            result: ""
        };
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteDataset (ctx, next) {

    try {
        // get params
        let _ID = ctx.params.id;

        ctx.body = { message: "", result: "" };

        // set request options
        let options = {
            uri: `${uri_head}/dataset/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.status = 404;
            ctx.body = {
                message: "Dataset not found",
                result: {
                    uri: `/audience/dataset/${res.body.result.id}`,
                    id: res.result.id
                }
            }
        } else {
            ctx.status = 204;
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
        ctx.body = {
            message: "error",
            result: ""
        };
    }

    await next();
}

/**
 * @example curl -XDELETE "http://localhost:8080/id/3"
 */
async function deleteGraph (ctx, next) {

    try {
        // get params
        let _ID = ctx.params.id;

        ctx.body = { message: "", result: "" };

        // set request options
        let options = {
            uri: `${uri_head}/graph/${_ID}`,
            method: 'DELETE',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.status = 404;
            ctx.body = {
                message: "Graph not found",
                result: {
                    uri: `/audience/graph/${res.body.result.id}`,
                    id: res.result.id
                }
            }
        } else {
            ctx.status = 204;
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
        ctx.body = {
            message: "error",
            result: ""
        };
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/id/"
 */
async function listUsers (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/user/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Users not found",
                result: {
                    uri: `/id/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/user/")[1])
            })
            ctx.body = {
                message: `Users found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

/**
 * @example curl -XGET "http://localhost:8080/presentation/org/course/"
 */
async function listCourses (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/course/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Courses not found",
                result: {
                    uri: `/presentation/org/course/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/course/")[1])
            })
            ctx.body = {
                message: `Courses found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listQuestions (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/question/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Questions not found",
                result: {
                    uri: `/presentation/content/question/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/question/")[1])
            })
            ctx.body = {
                message: `Questions found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listSessions (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/session/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Sessions not found",
                result: {
                    uri: `/presentation/org/session/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/session/")[1])
            })
            ctx.body = {
                message: `Sessions found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listPresentations (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/presentation/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Presentations not found",
                result: {
                    uri: `/presentation/org/presentation/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/presentation/")[1])
            })
            ctx.body = {
                message: `Presentations found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listResponses (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/response/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Responses not found",
                result: {
                    uri: `/audience/response/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/response/")[1])
            })
            ctx.body = {
                message: `Responses found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listDatasets (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/dataset/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Datasets not found",
                result: {
                    uri: `/audience/dataset/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/dataset/")[1])
            })
            ctx.body = {
                message: `Datasets found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listGraphs (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/graph/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Graphs not found",
                result: {
                    uri: `/audience/graph/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/graph/")[1])
            })
            ctx.body = {
                message: `Graphs found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listUpvotes (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/upvote/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Upvotes not found",
                result: {
                    uri: `/audience/upvote/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/upvote/")[1])
            })
            ctx.body = {
                message: `Upvotes found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listReacts (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/react/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Reacts not found",
                result: {
                    uri: `/audience/react/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/react/")[1])
            })
            ctx.body = {
                message: `Reacts found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listStars (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/star/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Stars not found",
                result: {
                    uri: `/audience/star/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/star/")[1])
            })
            ctx.body = {
                message: `Stars found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

async function listTags (ctx, next) {
    try {
        // set request options
        let options = {
            uri: `${uri_head}/tag/`,
            method: 'GET',
            json: true,
            resolveWithFullResponse: true,
            simple: false,
            headers: {
                'Authorization': `Bearer ${api_conf.storage.token}`
            }
        };

        // make request to storage api
        const res = await rp(options);
        if (res.statusCode >= 500) {
            throw new Error("storage API error");
        }
        else if (res.statusCode == 404) {
            ctx.body = {
                message: "Tags not found",
                result: {
                    uri: `/audience/tag/`
                }
            }
            ctx.status = 404;
        } else {
            // strip ID from uri
            let _result = res.body.result;
            let _list = [];
            _result.forEach(_str => {
                _list.push(_str.split("/tag/")[1])
            })
            ctx.body = {
                message: `Tags found`,
                result: _list
            }
            ctx.status = 200
        }
        
    } catch (e) {
        console.error(e);
        ctx.status = 500;
    }

    await next();
}

module.exports = {
    // Identity API
    //login, logout, 
    readUserByEmail, createUser, readUser, updateUser, deleteUser, listUsers,

    // Presentation API
    createQuestion, readQuestion, updateQuestion, deleteQuestion, listQuestions,
    createCourse, readCourse, updateCourse, deleteCourse, listCourses,
    createSession, readSession, updateSession, deleteSession, listSessions,
    createPresentation, readPresentation, updatePresentation, deletePresentation, listPresentations,

    //// Live API
    createLiveSession, deleteLiveSession,
    //joinLiveSession,

    // Audience API
    createUpvote, readUpvote, updateUpvote, deleteUpvote, listUpvotes,
    createReact, readReact, updateReact, deleteReact, listReacts,
    createStar, readStar, updateStar, deleteStar, listStars,
    createTag, readTag, updateTag, deleteTag, listTags,
    createResponse, readResponse, updateResponse, deleteResponse, listResponses,
    createDataset, readDataset, updateDataset, deleteDataset, listDatasets,
    createGraph, readGraph, updateGraph, deleteGraph, listGraphs,
   };