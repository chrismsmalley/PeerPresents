const Router = require('koa-router'),
      KoaBody = require('koa-body'),
      {
       // Identity API
       //login, logout, 
       readUserByEmail, createUser, readUser, updateUser, deleteUser, listUsers,

       //// Presentation API
       createQuestion, readQuestion, updateQuestion, deleteQuestion, listQuestions,
       createCourse, readCourse, updateCourse, deleteCourse, listCourses,
       createSession, readSession, updateSession, deleteSession, listSessions, 
       createPresentation, readPresentation, updatePresentation, deletePresentation, listPresentations,
 
       //// Live API
       createLiveSession, deleteLiveSession,
       joinLiveSession,
 
       //// Audience API
       createUpvote, readUpvote, updateUpvote, deleteUpvote, listUpvotes,
       createReact, readReact, updateReact, deleteReact, listReacts,
       createStar, readStar, updateStar, deleteStar, listStars,
       createTag, readTag, updateTag, deleteTag, listTags,
       createResponse, readResponse, updateResponse, deleteResponse, listResponses,
       createDataset, readDataset, updateDataset, deleteDataset, listDatasets,
       createGraph, readGraph, updateGraph, deleteGraph, listGraphs,

      } = require('../controllers/storageController');

const router = new Router();

const uri_prefix = '/api';

// Identity API
//router.post('/id/login',   KoaBody(), login)
//router.post('/id/logout',  KoaBody(), logout)

router.post(uri_prefix+'/id/',         createUser);
router.get( uri_prefix+'/id/:userid',  readUser);
router.put( uri_prefix+'/id/:userid',  updateUser);
router.del( uri_prefix+'/id/:userid',  deleteUser);
router.get( uri_prefix+'/id/',         listUsers);
router.get( uri_prefix+'/email/:email', readUserByEmail);

// Presentation API
router.post(uri_prefix+'/presentation/content/question/',     createQuestion)
router.get( uri_prefix+'/presentation/content/question/:id',  readQuestion)
router.put( uri_prefix+'/presentation/content/question/:id',  updateQuestion)
router.del( uri_prefix+'/presentation/content/question/:id',  deleteQuestion)
router.get( uri_prefix+'/presentation/content/question/',     listQuestions)
router.post(uri_prefix+'/presentation/org/course/',           createCourse)
router.get( uri_prefix+'/presentation/org/course/:id',        readCourse)
router.put( uri_prefix+'/presentation/org/course/:id',        updateCourse)
router.del( uri_prefix+'/presentation/org/course/:id',        deleteCourse)
router.get( uri_prefix+'/presentation/org/course/',           listCourses)
router.post(uri_prefix+'/presentation/org/session/',          createSession)
router.get( uri_prefix+'/presentation/org/session/:id',       readSession)
router.put( uri_prefix+'/presentation/org/session/:id',       updateSession)
router.del( uri_prefix+'/presentation/org/session/:id',       deleteSession)
router.get( uri_prefix+'/presentation/org/session/',          listSessions)
router.post(uri_prefix+'/presentation/org/presentation/',      createPresentation)
router.get( uri_prefix+'/presentation/org/presentation/:id',  readPresentation)
router.put( uri_prefix+'/presentation/org/presentation/:id',  updatePresentation)
router.del( uri_prefix+'/presentation/org/presentation/:id',   deletePresentation)
router.get( uri_prefix+'/presentation/org/presentation/',     listPresentations)


// Live API
router.post(uri_prefix+'/live/:id', createLiveSession)
router.del( uri_prefix+'/live/:id', deleteLiveSession)
//router.get( '/live/:id', joinLiveSession)

// Audience API
router.post(uri_prefix+'/audience/response',      createResponse)
router.get( uri_prefix+'/audience/response/:id',  readResponse)
router.put( uri_prefix+'/audience/response/:id',  updateResponse)
router.del( uri_prefix+'/audience/response/:id',  deleteResponse)
router.get( uri_prefix+'/audience/response/',     listResponses)
router.post(uri_prefix+'/audience/dataset',       createDataset)
router.get( uri_prefix+'/audience/dataset/:id',   readDataset)
router.put( uri_prefix+'/audience/dataset/:id',   updateDataset)
router.del( uri_prefix+'/audience/dataset/:id',   deleteDataset)
router.get( uri_prefix+'/audience/dataset/',      listDatasets)
router.post(uri_prefix+'/audience/graph',         createGraph)
router.get( uri_prefix+'/audience/graph/:id',     readGraph)
router.put( uri_prefix+'/audience/graph/:id',     updateGraph)
router.del( uri_prefix+'/audience/graph/:id',     deleteGraph)
router.get( uri_prefix+'/audience/graph/',        listGraphs)
router.post(uri_prefix+'/audience/upvote',        createUpvote)
router.get( uri_prefix+'/audience/upvote/:id',    readUpvote)
router.put( uri_prefix+'/audience/upvote/:id',    updateUpvote)
router.del( uri_prefix+'/audience/upvote/:id',    deleteUpvote)
router.get( uri_prefix+'/audience/upvote/',       listUpvotes)
router.post(uri_prefix+'/audience/react',         createReact)
router.get( uri_prefix+'/audience/react/:id',     readReact)
router.put( uri_prefix+'/audience/react/:id',     updateReact)
router.del( uri_prefix+'/audience/react/:id',     deleteReact)
router.get( uri_prefix+'/audience/react/',        listReacts)
router.post(uri_prefix+'/audience/star',          createStar)
router.get( uri_prefix+'/audience/star/:id',      readStar)
router.put( uri_prefix+'/audience/star/:id',      updateStar)
router.del( uri_prefix+'/audience/star/:id',      deleteStar)
router.get( uri_prefix+'/audience/star/',         listStars)
router.post(uri_prefix+'/audience/tag',           createTag)
router.get( uri_prefix+'/audience/tag/:id',       readTag)
router.put( uri_prefix+'/audience/tag/:id',       updateTag)
router.del( uri_prefix+'/audience/tag/:id',       deleteTag)
router.get( uri_prefix+'/audience/tag/',          listTags)

// Study API

// Research API

module.exports = {
    routes () { return router.routes() },
    allowedMethods () { return router.allowedMethods() }
};
