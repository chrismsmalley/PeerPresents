#/usr/bin/sh
forever start --uid "worker" -a index.js > service.log 1>&1 &
